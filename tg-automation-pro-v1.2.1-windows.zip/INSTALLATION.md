# 📖 Telegram Automation Pro - Полное руководство по установке

Это пошаговое руководство проведёт вас через весь процесс установки и настройки системы от начала до конца.

## 📋 Требования

### Серверные требования

- **ОС**: Ubuntu 22.04 или новее (рекомендуется)
- **CPU**: Минимум 2 ядра (4+ рекомендуется для LLM)
- **RAM**: Минимум 4GB (8GB+ рекомендуется)
- **Диск**: 20GB свободного места (для Docker образов и логов)
- **Сеть**: Стабильное интернет-соединение

### Программное обеспечение

- Docker 20.10+
- Docker Compose 2.0+
- Git

### Telegram API

- Telegram API ID и API Hash (получить на [my.telegram.org](https://my.telegram.org))
- Минимум 1 Telegram аккаунт с активным номером телефона

## 🔧 Шаг 1: Подготовка сервера

### 1.1 Обновление системы

```bash
sudo apt update && sudo apt upgrade -y
```

### 1.2 Установка Docker

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
```

**Важно**: Выйдите и войдите снова, чтобы изменения вступили в силу.

### 1.3 Установка Docker Compose

```bash
sudo apt install docker-compose-plugin -y
```

### 1.4 Проверка установки

```bash
docker --version
docker compose version
```

## 📥 Шаг 2: Загрузка проекта

### 2.1 Клонирование репозитория

```bash
cd /opt
sudo git clone <your-repo-url> tg-automation-pro
sudo chown -R $USER:$USER tg-automation-pro
cd tg-automation-pro
```

### 2.2 Проверка структуры

```bash
ls -la
```

Вы должны увидеть:
- `backend/`
- `frontend/`
- `database/`
- `scripts/`
- `docker-compose.yml`
- `.env.example`

## ⚙️ Шаг 3: Конфигурация

### 3.1 Создание .env файла

```bash
cp .env.example .env
nano .env
```

### 3.2 Редактирование .env

Обязательные параметры для изменения:

```env
# Telegram API (получить на my.telegram.org)
TELEGRAM_API_ID=your_api_id
TELEGRAM_API_HASH=your_api_hash

# Database (смените пароль!)
POSTGRES_PASSWORD=your_secure_password_here

# Redis (смените пароль!)
REDIS_PASSWORD=your_redis_password_here

# Secret Key (сгенерируйте случайный)
SECRET_KEY=your_super_secret_key_here
```

**Генерация случайных ключей:**

```bash
# Secret Key
openssl rand -hex 32

# Пароли
openssl rand -hex 16
```

### 3.3 Опциональные параметры

```env
# LLM настройки
LLM_MODEL=llama3.1:8b
LLM_TEMPERATURE=0.7

# Лимиты
DAILY_INVITE_LIMIT_PER_ACCOUNT=30
MIN_DELAY_BETWEEN_INVITES=60
MAX_DELAY_BETWEEN_INVITES=300

# Логирование
LOG_LEVEL=INFO
```

## 🚀 Шаг 4: Развёртывание

### 4.1 Запуск автоматического развёртывания

```bash
chmod +x scripts/deploy.sh
./scripts/deploy.sh
```

Скрипт выполнит:
1. Проверку зависимостей
2. Создание директорий
3. Сборку Docker образов
4. Запуск всех сервисов
5. Инициализацию базы данных

### 4.2 Ручное развёртывание (альтернатива)

Если автоматический скрипт не работает:

```bash
# Создать директории
mkdir -p logs sessions backups

# Собрать образы
docker compose build

# Запустить сервисы
docker compose up -d

# Проверить статус
docker compose ps
```

### 4.3 Проверка логов

```bash
# Все сервисы
docker compose logs -f

# Конкретный сервис
docker compose logs -f backend
docker compose logs -f bot_worker
```

## 🗄️ Шаг 5: Инициализация базы данных

### 5.1 Проверка подключения

```bash
docker exec -it tg_automation_db psql -U postgres -d telegram_automation
```

### 5.2 Проверка таблиц

```sql
\dt
```

Вы должны увидеть все таблицы из `database/init.sql`.

### 5.3 Создание админ-пользователя

```sql
INSERT INTO admin_users (username, email, password_hash, is_active)
VALUES (
    'admin',
    'admin@example.com',
    '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5NU7TUQ9aqQ/i', -- admin123
    TRUE
);
```

**⚠️ ВАЖНО**: Это пароль по умолчанию (`admin123`). Смените его сразу после первого входа!

## 📱 Шаг 6: Добавление Telegram аккаунтов

### 6.1 Получение API credentials

1. Перейдите на [my.telegram.org](https://my.telegram.org)
2. Войдите с вашим номером телефона
3. Перейдите в "API development tools"
4. Создайте новое приложение
5. Сохраните **API ID** и **API Hash**

### 6.2 Создание сессии

```bash
./scripts/create_session.sh
```

Введите:
- API ID
- API Hash
- Номер телефона (с кодом страны, например: +79991234567)
- Код подтверждения из Telegram
- Пароль 2FA (если включен)

### 6.3 Добавление аккаунта в базу

Скрипт выведет SQL запрос. Выполните его:

```bash
docker exec -it tg_automation_db psql -U postgres -d telegram_automation
```

Вставьте SQL запрос:

```sql
INSERT INTO telegram_accounts (phone, api_id, api_hash, session_file, role, status)
VALUES ('+79991234567', 12345678, 'your_api_hash', '/app/sessions/+79991234567.session', 'parser', 'active');
```

### 6.4 Повторите для всех аккаунтов

Для мульти-аккаунтной системы повторите шаги 6.2-6.3 для каждого аккаунта.

**Рекомендации по ролям:**
- `parser` - для парсинга групп
- `inviter` - для инвайтинга пользователей
- `universal` - для обеих задач

## 🌐 Шаг 7: Доступ к веб-панели

### 7.1 Открытие панели

Откройте браузер и перейдите:

```
http://your-server-ip:3000
```

### 7.2 Вход в систему

- **Username**: `admin`
- **Password**: `admin123`

### 7.3 Смена пароля

1. Перейдите в настройки
2. Смените пароль на безопасный

## 🎯 Шаг 8: Первая кампания

### 8.1 Добавление целевых групп

1. В панели перейдите в "Groups"
2. Нажмите "Add Group"
3. Введите username группы (например: `@crypto_chat`) или Telegram ID
4. Сохраните

### 8.2 Создание кампании парсинга

1. Перейдите в "Campaigns"
2. Нажмите "Create Campaign"
3. Заполните:
   - **Name**: "Test Parsing Campaign"
   - **Type**: "Parsing"
   - **Target Groups**: Выберите добавленные группы
4. Нажмите "Create"

### 8.3 Запуск кампании

1. Найдите созданную кампанию
2. Нажмите "Start"
3. Мониторьте прогресс в реальном времени

### 8.4 Создание кампании инвайтинга

После парсинга:

1. Создайте новую кампанию
2. **Type**: "Inviting"
3. **Target Channel**: Ваш канал (например: `@your_channel`)
4. **Invite Message Template**: Шаблон сообщения или оставьте пустым для LLM-генерации
5. Запустите кампанию

## 🔧 Шаг 9: Настройка LLM (опционально)

### 9.1 Установка модели

```bash
docker exec -it tg_automation_llm ollama pull llama3.1:8b
```

Это загрузит ~4.7GB.

### 9.2 Проверка работы

```bash
docker exec -it tg_automation_llm ollama run llama3.1:8b "Hello"
```

### 9.3 Включение LLM-генерации

В веб-панели:
1. Перейдите в "Settings"
2. Найдите `enable_llm_generation`
3. Установите в `true`

## 🛡️ Шаг 10: Безопасность

### 10.1 Настройка firewall

```bash
sudo ufw allow 22/tcp
sudo ufw allow 3000/tcp
sudo ufw allow 5000/tcp
sudo ufw enable
```

### 10.2 Настройка прокси (рекомендуется)

Добавьте прокси в базу данных:

```sql
INSERT INTO proxies (type, host, port, username, password, country, status)
VALUES ('socks5', 'proxy.example.com', 1080, 'user', 'pass', 'US', 'active');
```

Привяжите прокси к аккаунту:

```sql
UPDATE telegram_accounts SET proxy_id = 1 WHERE id = 1;
```

### 10.3 Регулярные бэкапы

```bash
# Создать бэкап базы данных
docker exec tg_automation_db pg_dump -U postgres telegram_automation > backup_$(date +%Y%m%d).sql

# Настроить автоматический бэкап (cron)
crontab -e

# Добавить строку (бэкап каждый день в 3:00)
0 3 * * * docker exec tg_automation_db pg_dump -U postgres telegram_automation > /opt/tg-automation-pro/backups/backup_$(date +\%Y\%m\%d).sql
```

## 📊 Мониторинг и обслуживание

### Просмотр логов

```bash
# Backend API
docker compose logs -f backend

# Worker
docker compose logs -f bot_worker

# Database
docker compose logs -f db
```

### Перезапуск сервисов

```bash
# Все сервисы
docker compose restart

# Конкретный сервис
docker compose restart backend
```

### Обновление системы

```bash
git pull
docker compose build
docker compose up -d
```

## ❓ Решение проблем

### База данных не запускается

```bash
docker compose logs db
# Проверьте пароль в .env
```

### LLM не отвечает

```bash
docker exec -it tg_automation_llm ollama list
# Убедитесь, что модель установлена
```

### Аккаунт забанен

1. Проверьте логи: `SELECT * FROM invite_logs WHERE status = 'spam_ban';`
2. Уменьшите лимиты в настройках
3. Добавьте больше задержек
4. Используйте прокси

### Не могу войти в панель

```bash
# Сбросить пароль админа
docker exec -it tg_automation_db psql -U postgres -d telegram_automation -c "UPDATE admin_users SET password_hash = '\$2b\$12\$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5NU7TUQ9aqQ/i' WHERE username = 'admin';"
# Пароль сброшен на admin123
```

## 🎉 Готово!

Ваша система Telegram Automation Pro полностью настроена и готова к работе!

**Следующие шаги:**
- Добавьте больше аккаунтов для масштабирования
- Настройте прокси для каждого аккаунта
- Экспериментируйте с настройками лимитов
- Мониторьте логи и статистику

**Поддержка:**
- Документация: `/docs`
- Issues: `<your-repo-url>/issues`
