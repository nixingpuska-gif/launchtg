# 🤖 Telegram Automation Pro

> Production-ready система для автоматизации Telegram с мульти-аккаунтной архитектурой, stealth-инвайтингом и LLM интеграцией

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![Docker](https://img.shields.io/badge/docker-ready-brightgreen.svg)](https://www.docker.com/)

---

## 🚀 Установка за 2 шага

### Linux/macOS:
```bash
tar -xzf tg-automation-pro.tar.gz && cd tg-automation-pro
./install.sh
```

### Windows:
1. Распакуйте архив
2. Запустите `install.bat` **от имени администратора**

📖 [Подробная инструкция для Windows](WINDOWS_INSTALL.md)

**Автоматический установщик сделает всё за вас:**
- ✅ Определит вашу ОС и версию
- ✅ Установит Docker и Docker Compose
- ✅ Настроит окружение
- ✅ Сгенерирует ключи безопасности
- ✅ Развернет все сервисы
- ✅ Создаст администратора

**Поддерживаемые ОС:** Ubuntu 20.04+, Debian 11+, CentOS 8+, Windows 10/11

---

## 📋 Возможности

### 🔄 Мульти-аккаунтное управление
- Неограниченное количество Telegram аккаунтов
- Автоматическая ротация между аккаунтами
- Отслеживание статуса (active, cooling, banned)
- Индивидуальные лимиты для каждого аккаунта
- Поддержка прокси для каждого аккаунта

### 📊 Парсинг групп
- Извлечение до 5000 пользователей из группы
- Фильтрация ботов, удалённых аккаунтов
- Анализ активности пользователей
- Сохранение метаданных (username, имя, фото, last_seen)
- Дедупликация пользователей

### 🎯 Stealth-инвайтинг
- Случайные задержки (60-300 секунд)
- Персонализированные сообщения через LLM
- Обработка FloodWait, PeerFlood
- Автоматическое отключение забаненных аккаунтов
- Лимит 30 инвайтов/день на аккаунт (настраиваемо)

### 🤖 LLM интеграция
- Генерация персонализированных приглашений
- Анализ интересов пользователей
- Генерация контента для каналов
- Автоответы в группах
- Локальная модель LLaMA 3.1 8B

### 🌐 Веб-панель управления
- Современный интерфейс
- Real-time статистика
- Управление аккаунтами и кампаниями
- Просмотр логов
- Уведомления о критических событиях
- JWT-аутентификация

### 📝 Централизованное логирование
- Логи парсинга
- Логи инвайтов
- Системные логи
- Детальная статистика
- Экспорт данных

---

## 🛠️ Технологический стек

**Backend:**
- Python 3.11
- Flask (REST API)
- Telethon (Telegram API)
- PostgreSQL (база данных)
- Redis (кэширование)

**Frontend:**
- HTML5 + JavaScript
- WebSocket (real-time)
- Nginx

**AI/ML:**
- Ollama (LLM сервер)
- LLaMA 3.1 8B

**DevOps:**
- Docker
- Docker Compose

---

## 📦 Структура проекта

```
tg-automation-pro/
├── backend/              # Python backend
│   ├── core/
│   │   ├── database.py   # ORM и работа с БД
│   │   ├── telegram_bot.py # Telegram bot engine
│   │   └── llm_client.py # LLM интеграция
│   ├── app.py            # REST API
│   └── worker.py         # Background worker
├── frontend/             # Веб-панель
├── database/             # SQL схемы
├── scripts/              # Утилиты
├── docker-compose.yml    # Оркестрация
├── install.sh            # Автоматический установщик
└── docs/                 # Документация
```

---

## 🎯 Быстрый старт

### 1. Установка

```bash
# Распаковать архив
tar -xzf tg-automation-pro.tar.gz
cd tg-automation-pro

# Запустить автоматический установщик
chmod +x install.sh
./install.sh
```

### 2. Доступ к веб-панели

Откройте в браузере:
```
http://your-server-ip:3000
```

**Логин:** `admin`  
**Пароль:** `admin123`

⚠️ **Смените пароль после первого входа!**

### 3. Создание Telegram сессии

```bash
./scripts/create_session.sh
```

Следуйте инструкциям на экране.

### 4. Добавление аккаунта в базу

Выполните SQL запрос, который выведет скрипт:

```bash
docker exec -it tg_automation_db psql -U postgres -d telegram_automation
# Вставьте SQL запрос
```

### 5. Создание кампании

1. Откройте веб-панель
2. Добавьте целевые группы
3. Создайте кампанию парсинга
4. Запустите кампанию

---

## 📊 Системные требования

### Минимальные:
- **ОС:** Ubuntu 20.04+ / Debian 11+ / CentOS 8+
- **CPU:** 2 ядра
- **RAM:** 4 GB
- **Диск:** 20 GB

### Рекомендуемые:
- **CPU:** 4+ ядра
- **RAM:** 8+ GB
- **Диск:** 50+ GB

---

## 🔧 Управление системой

### Просмотр логов
```bash
docker compose logs -f
docker compose logs -f backend
```

### Остановка/запуск
```bash
docker compose down
docker compose up -d
```

### Перезапуск
```bash
docker compose restart
```

### Статус сервисов
```bash
docker compose ps
```

### Бэкап базы данных
```bash
docker exec tg_automation_db pg_dump -U postgres telegram_automation > backup.sql
```

---

## 📖 Документация

- **QUICKSTART.md** - Быстрый старт (2 шага)
- **INSTALLATION.md** - Подробное руководство
- **SUMMARY.md** - Техническая документация
- **README.md** - Этот файл

---

## 🛡️ Безопасность

### Реализованные меры:
- JWT-токены с истечением
- Bcrypt для паролей
- Параметризованные SQL запросы
- CORS защита
- Шифрование Telegram сессий
- Поддержка прокси

### Stealth-механики:
- Случайные задержки
- Адаптивные лимиты
- Детекция FloodWait
- Автоматический кулдаун
- Ротация аккаунтов

---

## 🔄 Обновление

```bash
cd tg-automation-pro
git pull  # Если используете git
docker compose build
docker compose up -d
```

---

## ❓ Решение проблем

### Docker не запускается
```bash
sudo systemctl start docker
```

### Нет прав на Docker
```bash
sudo usermod -aG docker $USER
newgrp docker
```

### База данных не запускается
```bash
docker compose logs db
```

### Порт уже занят
Измените порты в `docker-compose.yml`

---

## 📈 Производительность

- **Парсинг:** До 5000 пользователей за раз
- **Инвайтинг:** 30 инвайтов/день на аккаунт
- **Задержки:** 60-300 секунд между инвайтами
- **Масштабирование:** Неограниченное количество аккаунтов

---

## 🤝 Вклад в проект

Мы приветствуем вклад в проект! Пожалуйста:
1. Fork репозиторий
2. Создайте feature branch
3. Commit изменения
4. Push в branch
5. Создайте Pull Request

---

## 📄 Лицензия

MIT License - свободное использование и модификация

---

## 🎉 Готово!

Система полностью готова к использованию. Просто запустите `./install.sh` и начните автоматизацию!

**Поддержка:** [GitHub Issues](https://github.com/your-repo/issues)

---

**Made with ❤️ by Manus AI**
