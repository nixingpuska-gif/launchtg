"""
Telegram Automation Pro - Backend API Server
Минимальная рабочая версия с правильной CORS конфигурацией
"""

import os
import sys
from datetime import datetime, timedelta
from functools import wraps

from flask import Flask, request, jsonify
from flask_cors import CORS
import bcrypt
import jwt
import asyncpg
import asyncio

# Flask app
app = Flask(__name__, static_folder='../frontend', static_url_path='')
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'telegram_automation_secret_key_2024')

# CORS - правильная конфигурация
CORS(app, resources={
    r"/*": {
        "origins": ["http://localhost:8000", "http://127.0.0.1:8000"],
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"],
        "supports_credentials": True,
        "expose_headers": ["Content-Type", "Authorization"]
    }
})

# Database connection pool
db_pool = None

async def get_db_pool():
    """Get or create database connection pool"""
    global db_pool
    if db_pool is None:
        db_pool = await asyncpg.create_pool(
            host=os.getenv('DB_HOST', 'localhost'),
            port=int(os.getenv('DB_PORT', 5432)),
            user=os.getenv('DB_USER', 'postgres'),
            password=os.getenv('DB_PASSWORD', 'postgres'),
            database=os.getenv('DB_NAME', 'telegram_automation'),
            min_size=2,
            max_size=10
        )
    return db_pool

def async_route(f):
    """Decorator to run async functions in Flask routes"""
    @wraps(f)
    def wrapper(*args, **kwargs):
        return asyncio.run(f(*args, **kwargs))
    return wrapper

def token_required(f):
    """Decorator to require JWT token"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(' ')[1]
            except IndexError:
                return jsonify({'error': 'Invalid token format'}), 401
        
        if not token:
            return jsonify({'error': 'Token is missing'}), 401
        
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            request.user_id = data['user_id']
            request.username = data['username']
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token has expired'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Invalid token'}), 401
        
        return f(*args, **kwargs)
    
    return decorated

# ============================================
# AUTHENTICATION ROUTES
# ============================================

@app.route('/api/auth/login', methods=['POST', 'OPTIONS'])
@async_route
async def login():
    """User login endpoint"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'error': 'Username and password required'}), 400
        
        pool = await get_db_pool()
        async with pool.acquire() as conn:
            user = await conn.fetchrow(
                'SELECT id, username, password_hash, role FROM users WHERE username = $1',
                username
            )
            
            if not user:
                return jsonify({'error': 'Invalid credentials'}), 401
            
            # Verify password
            if not bcrypt.checkpw(password.encode('utf-8'), user['password_hash'].encode('utf-8')):
                return jsonify({'error': 'Invalid credentials'}), 401
            
            # Update last login
            await conn.execute(
                'UPDATE users SET last_login = $1 WHERE id = $2',
                datetime.now(), user['id']
            )
            
            # Generate JWT token
            token = jwt.encode({
                'user_id': user['id'],
                'username': user['username'],
                'role': user['role'],
                'exp': datetime.utcnow() + timedelta(days=7)
            }, app.config['SECRET_KEY'], algorithm='HS256')
            
            return jsonify({
                'token': token,
                'user': {
                    'id': user['id'],
                    'username': user['username'],
                    'role': user['role']
                }
            }), 200
            
    except Exception as e:
        print(f"Login error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/auth/me', methods=['GET'])
@token_required
@async_route
async def get_current_user():
    """Get current user info"""
    try:
        pool = await get_db_pool()
        async with pool.acquire() as conn:
            user = await conn.fetchrow(
                'SELECT id, username, email, role, created_at FROM users WHERE id = $1',
                request.user_id
            )
            
            if not user:
                return jsonify({'error': 'User not found'}), 404
            
            return jsonify({
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
                'role': user['role'],
                'created_at': user['created_at'].isoformat() if user['created_at'] else None
            }), 200
            
    except Exception as e:
        print(f"Get user error: {e}")
        return jsonify({'error': str(e)}), 500

# ============================================
# DASHBOARD ROUTES
# ============================================

@app.route('/api/dashboard/stats', methods=['GET'])
@token_required
@async_route
async def get_dashboard_stats():
    """Get dashboard statistics"""
    try:
        pool = await get_db_pool()
        async with pool.acquire() as conn:
            # Get counts from database
            accounts_count = await conn.fetchval('SELECT COUNT(*) FROM accounts WHERE user_id = $1', request.user_id) or 0
            groups_count = await conn.fetchval('SELECT COUNT(*) FROM groups WHERE user_id = $1', request.user_id) or 0
            users_count = await conn.fetchval('SELECT COUNT(*) FROM parsed_users WHERE user_id = $1', request.user_id) or 0
            campaigns_count = await conn.fetchval('SELECT COUNT(*) FROM campaigns WHERE user_id = $1', request.user_id) or 0
            
            return jsonify({
                'accounts': accounts_count,
                'groups': groups_count,
                'users': users_count,
                'campaigns': campaigns_count
            }), 200
            
    except Exception as e:
        print(f"Dashboard stats error: {e}")
        # Return zeros if tables don't exist yet
        return jsonify({
            'accounts': 0,
            'groups': 0,
            'users': 0,
            'campaigns': 0
        }), 200

# ============================================
# ACCOUNTS ROUTES
# ============================================

@app.route('/api/accounts', methods=['GET'])
@token_required
@async_route
async def get_accounts():
    """Get user's Telegram accounts"""
    try:
        pool = await get_db_pool()
        async with pool.acquire() as conn:
            accounts = await conn.fetch(
                'SELECT id, phone, name, status, created_at FROM accounts WHERE user_id = $1 ORDER BY created_at DESC',
                request.user_id
            )
            
            return jsonify([{
                'id': acc['id'],
                'phone': acc['phone'],
                'name': acc['name'],
                'status': acc['status'],
                'created_at': acc['created_at'].isoformat() if acc['created_at'] else None
            } for acc in accounts]), 200
            
    except Exception as e:
        print(f"Get accounts error: {e}")
        return jsonify([]), 200

# ============================================
# NOTIFICATIONS ROUTES
# ============================================

@app.route('/api/notifications', methods=['GET'])
@token_required
@async_route
async def get_notifications():
    """Get user notifications"""
    try:
        unread_only = request.args.get('unread', 'false').lower() == 'true'
        
        pool = await get_db_pool()
        async with pool.acquire() as conn:
            if unread_only:
                notifications = await conn.fetch(
                    'SELECT id, type, message, created_at FROM notifications WHERE user_id = $1 AND read = false ORDER BY created_at DESC LIMIT 10',
                    request.user_id
                )
            else:
                notifications = await conn.fetch(
                    'SELECT id, type, message, created_at FROM notifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50',
                    request.user_id
                )
            
            return jsonify([{
                'id': notif['id'],
                'type': notif['type'],
                'message': notif['message'],
                'created_at': notif['created_at'].isoformat() if notif['created_at'] else None
            } for notif in notifications]), 200
            
    except Exception as e:
        print(f"Get notifications error: {e}")
        return jsonify([]), 200

# ============================================
# FRONTEND ROUTES
# ============================================

@app.route('/')
def index():
    """Serve frontend index.html"""
    return app.send_static_file('index.html')

@app.route('/<path:path>')
def static_files(path):
    """Serve static files"""
    return app.send_static_file(path)

# ============================================
# MAIN
# ============================================

if __name__ == '__main__':
    print("=" * 60)
    print("  Telegram Automation Pro - Backend API")
    print("  Version: 4.0.0 (Fixed)")
    print("=" * 60)
    print(f"\nStarting server on http://127.0.0.1:8000")
    print(f"Frontend: http://127.0.0.1:8000/")
    print(f"API: http://127.0.0.1:8000/api/")
    print("\nPress CTRL+C to stop\n")
    
    app.run(host='0.0.0.0', port=8000, debug=True)
