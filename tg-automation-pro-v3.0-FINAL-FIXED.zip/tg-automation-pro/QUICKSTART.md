# 🚀 Быстрый старт - Telegram Automation Pro

## Установка за 2 шага

### Шаг 1: Распаковать архив

```bash
tar -xzf tg-automation-pro.tar.gz
cd tg-automation-pro
```

### Шаг 2: Запустить автоматический установщик

```bash
chmod +x install.sh
./install.sh
```

**Вот и всё!** 🎉

Установщик автоматически:
- ✅ Определит вашу ОС (Ubuntu/Debian/CentOS)
- ✅ Проверит системные требования
- ✅ Установит Docker и Docker Compose (если нужно)
- ✅ Настроит окружение
- ✅ Сгенерирует случайные ключи безопасности
- ✅ Соберет и запустит все сервисы
- ✅ Создаст администратора

---

## После установки

### 1. Откройте веб-панель

```
http://your-server-ip:3000
```

**Логин:** `admin`  
**Пароль:** `admin123`

⚠️ **ВАЖНО:** Смените пароль после первого входа!

### 2. Создайте Telegram сессию

```bash
./scripts/create_session.sh
```

Введите:
- API ID (получить на [my.telegram.org](https://my.telegram.org))
- API Hash
- Номер телефона
- Код подтверждения из Telegram

### 3. Добавьте аккаунт в базу данных

Скрипт выведет SQL запрос. Выполните его:

```bash
docker exec -it tg_automation_db psql -U postgres -d telegram_automation
```

Вставьте SQL запрос из вывода скрипта.

### 4. Создайте первую кампанию

1. Откройте веб-панель
2. Перейдите в раздел "Groups"
3. Добавьте целевые группы (username или ID)
4. Перейдите в "Campaigns"
5. Создайте кампанию парсинга
6. Запустите её

---

## Системные требования

### Минимальные:
- **ОС:** Ubuntu 20.04+ / Debian 11+ / CentOS 8+
- **CPU:** 2 ядра
- **RAM:** 4 GB
- **Диск:** 20 GB свободного места
- **Интернет:** Стабильное подключение

### Рекомендуемые:
- **CPU:** 4+ ядра
- **RAM:** 8+ GB
- **Диск:** 50+ GB

---

## Что установится автоматически

1. **Docker** - контейнеризация
2. **Docker Compose** - оркестрация
3. **PostgreSQL** - база данных
4. **Redis** - кэширование
5. **Backend API** - Flask сервер
6. **Frontend** - веб-панель
7. **Ollama** (опционально) - локальная LLM

---

## Полезные команды

### Просмотр логов
```bash
docker compose logs -f
docker compose logs -f backend
docker compose logs -f bot_worker
```

### Управление сервисами
```bash
# Остановить
docker compose down

# Запустить
docker compose up -d

# Перезапустить
docker compose restart

# Статус
docker compose ps
```

### Обновление системы
```bash
git pull
docker compose build
docker compose up -d
```

### Бэкап базы данных
```bash
docker exec tg_automation_db pg_dump -U postgres telegram_automation > backup.sql
```

### Восстановление из бэкапа
```bash
docker exec -i tg_automation_db psql -U postgres telegram_automation < backup.sql
```

---

## Решение проблем

### Docker не запускается

```bash
sudo systemctl start docker
sudo systemctl enable docker
```

### Нет прав на Docker

```bash
sudo usermod -aG docker $USER
newgrp docker
```

### База данных не запускается

```bash
docker compose logs db
# Проверьте пароль в .env файле
```

### Порт уже занят

Измените порты в `docker-compose.yml`:

```yaml
ports:
  - "3001:80"  # Вместо 3000
  - "5001:5000"  # Вместо 5000
```

---

## Дополнительная настройка

### Установка LLM (если пропустили при установке)

```bash
docker compose up -d ollama
docker exec tg_automation_llm ollama pull llama3.1:8b
```

### Настройка прокси

Добавьте прокси в базу данных:

```sql
INSERT INTO proxies (type, host, port, username, password, country, status)
VALUES ('socks5', 'proxy.example.com', 1080, 'user', 'pass', 'US', 'active');
```

Привяжите к аккаунту:

```sql
UPDATE telegram_accounts SET proxy_id = 1 WHERE id = 1;
```

### Настройка firewall

```bash
sudo ufw allow 22/tcp
sudo ufw allow 3000/tcp
sudo ufw allow 5000/tcp
sudo ufw enable
```

---

## Поддержка

- 📖 **Документация:** README.md, INSTALLATION.md, SUMMARY.md
- 🐛 **Issues:** GitHub Issues
- 💬 **Telegram:** @your_support_channel

---

## Лицензия

MIT License - свободное использование и модификация

---

**Готово! Теперь вы можете начать автоматизацию Telegram! 🚀**
