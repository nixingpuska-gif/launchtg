# ============================================
# Telegram Automation Pro - Windows Installer
# Автоматическая установка для Windows
# ============================================

# Требуется PowerShell 5.1+
#Requires -Version 5.1

# Запуск от имени администратора
if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Warning "Этот скрипт требует прав администратора!"
    Write-Host "Перезапуск с правами администратора..." -ForegroundColor Yellow
    Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# Цвета
function Write-Header {
    param([string]$Message)
    Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Blue
    Write-Host "║  $Message" -ForegroundColor Blue
    Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Blue
}

function Write-Success {
    param([string]$Message)
    Write-Host "✅ $Message" -ForegroundColor Green
}

function Write-Error-Custom {
    param([string]$Message)
    Write-Host "❌ $Message" -ForegroundColor Red
}

function Write-Warning-Custom {
    param([string]$Message)
    Write-Host "⚠️  $Message" -ForegroundColor Yellow
}

function Write-Info {
    param([string]$Message)
    Write-Host "ℹ️  $Message" -ForegroundColor Cyan
}

# ============================================
# STEP 0: Welcome
# ============================================

Clear-Host
Write-Header "🤖 Telegram Automation Pro - Автоматический установщик для Windows"

Write-Host "Этот скрипт автоматически:" -ForegroundColor Cyan
Write-Host "  1. Проверит вашу систему"
Write-Host "  2. Установит Docker Desktop (если нужно)"
Write-Host "  3. Установит WSL 2 (если нужно)"
Write-Host "  4. Развернет Telegram Automation Pro"
Write-Host ""
Write-Host "Поддерживаемые ОС: Windows 10/11 (64-bit)" -ForegroundColor Yellow
Write-Host ""

$continue = Read-Host "Продолжить установку? (y/n)"
if ($continue -ne 'y' -and $continue -ne 'Y') {
    Write-Error-Custom "Установка отменена"
    exit
}

# ============================================
# STEP 1: Check Windows Version
# ============================================

Write-Header "Проверка версии Windows"

$osInfo = Get-WmiObject -Class Win32_OperatingSystem
$osVersion = [System.Environment]::OSVersion.Version

Write-Info "ОС: $($osInfo.Caption)"
Write-Info "Версия: $($osVersion.Major).$($osVersion.Minor).$($osVersion.Build)"

# Check if Windows 10/11
if ($osVersion.Major -lt 10) {
    Write-Error-Custom "Требуется Windows 10 или новее"
    exit 1
}

# Check if 64-bit
if ([System.Environment]::Is64BitOperatingSystem) {
    Write-Success "64-bit система обнаружена"
} else {
    Write-Error-Custom "Требуется 64-bit версия Windows"
    exit 1
}

# ============================================
# STEP 2: Check System Requirements
# ============================================

Write-Header "Проверка системных требований"

# Check RAM
$ram = [math]::Round((Get-WmiObject -Class Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 2)
Write-Info "RAM: ${ram}GB"
if ($ram -lt 4) {
    Write-Warning-Custom "Рекомендуется минимум 4GB RAM (обнаружено: ${ram}GB)"
}

# Check CPU cores
$cores = (Get-WmiObject -Class Win32_Processor).NumberOfLogicalProcessors
Write-Info "CPU ядер: $cores"
if ($cores -lt 2) {
    Write-Warning-Custom "Рекомендуется минимум 2 CPU ядра (обнаружено: $cores)"
}

# Check disk space
$disk = Get-WmiObject -Class Win32_LogicalDisk -Filter "DeviceID='C:'"
$freeSpaceGB = [math]::Round($disk.FreeSpace / 1GB, 2)
Write-Info "Свободное место на диске C: ${freeSpaceGB}GB"
if ($freeSpaceGB -lt 20) {
    Write-Warning-Custom "Рекомендуется минимум 20GB свободного места (обнаружено: ${freeSpaceGB}GB)"
}

# ============================================
# STEP 3: Check Hyper-V and Virtualization
# ============================================

Write-Header "Проверка виртуализации"

# Check if virtualization is enabled
$hyperv = Get-WindowsOptionalFeature -FeatureName Microsoft-Hyper-V-All -Online
if ($hyperv.State -eq "Enabled") {
    Write-Success "Hyper-V включен"
} else {
    Write-Warning-Custom "Hyper-V не включен. Docker Desktop требует Hyper-V или WSL 2"
    Write-Info "Включение Hyper-V..."
    try {
        Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -All -NoRestart
        Write-Success "Hyper-V включен (требуется перезагрузка)"
        $needReboot = $true
    } catch {
        Write-Warning-Custom "Не удалось включить Hyper-V. Будет использован WSL 2"
    }
}

# ============================================
# STEP 4: Check WSL 2
# ============================================

Write-Header "Проверка WSL 2"

$wslVersion = wsl --version 2>$null
if ($LASTEXITCODE -eq 0) {
    Write-Success "WSL установлен"
} else {
    Write-Warning-Custom "WSL не установлен. Установка WSL 2..."
    try {
        wsl --install --no-distribution
        Write-Success "WSL 2 установлен (требуется перезагрузка)"
        $needReboot = $true
    } catch {
        Write-Error-Custom "Не удалось установить WSL 2"
        Write-Info "Установите WSL 2 вручную: https://docs.microsoft.com/en-us/windows/wsl/install"
    }
}

# ============================================
# STEP 5: Check Docker Desktop
# ============================================

Write-Header "Проверка Docker Desktop"

$dockerPath = "C:\Program Files\Docker\Docker\Docker Desktop.exe"
if (Test-Path $dockerPath) {
    Write-Success "Docker Desktop уже установлен"
    
    # Check if Docker is running
    $dockerProcess = Get-Process "Docker Desktop" -ErrorAction SilentlyContinue
    if ($dockerProcess) {
        Write-Success "Docker Desktop запущен"
    } else {
        Write-Info "Запуск Docker Desktop..."
        Start-Process $dockerPath
        Write-Info "Ожидание запуска Docker (30 секунд)..."
        Start-Sleep -Seconds 30
    }
} else {
    Write-Warning-Custom "Docker Desktop не найден"
    Write-Info "Скачивание Docker Desktop..."
    
    $dockerInstallerUrl = "https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe"
    $dockerInstallerPath = "$env:TEMP\DockerDesktopInstaller.exe"
    
    try {
        Invoke-WebRequest -Uri $dockerInstallerUrl -OutFile $dockerInstallerPath
        Write-Success "Docker Desktop скачан"
        
        Write-Info "Установка Docker Desktop (это может занять несколько минут)..."
        Start-Process -FilePath $dockerInstallerPath -ArgumentList "install --quiet" -Wait
        
        Write-Success "Docker Desktop установлен"
        Write-Warning-Custom "ВАЖНО: Перезагрузите компьютер и запустите этот скрипт снова"
        
        $reboot = Read-Host "Перезагрузить сейчас? (y/n)"
        if ($reboot -eq 'y' -or $reboot -eq 'Y') {
            Restart-Computer -Force
        }
        exit
    } catch {
        Write-Error-Custom "Не удалось скачать/установить Docker Desktop"
        Write-Info "Скачайте и установите вручную: https://www.docker.com/products/docker-desktop"
        exit 1
    }
}

# ============================================
# STEP 6: Check Docker Compose
# ============================================

Write-Header "Проверка Docker Compose"

try {
    $composeVersion = docker compose version
    Write-Success "Docker Compose установлен: $composeVersion"
} catch {
    Write-Error-Custom "Docker Compose не найден"
    Write-Info "Docker Compose должен быть установлен вместе с Docker Desktop"
    exit 1
}

# ============================================
# STEP 7: Setup Project
# ============================================

Write-Header "Настройка проекта"

$projectDir = Get-Location
Write-Info "Директория проекта: $projectDir"

# Create directories
Write-Info "Создание директорий..."
New-Item -ItemType Directory -Force -Path "logs" | Out-Null
New-Item -ItemType Directory -Force -Path "sessions" | Out-Null
New-Item -ItemType Directory -Force -Path "backups" | Out-Null
Write-Success "Директории созданы"

# ============================================
# STEP 8: Configure Environment
# ============================================

Write-Header "Настройка окружения"

if (Test-Path ".env") {
    Write-Warning-Custom ".env файл уже существует"
    $overwrite = Read-Host "Перезаписать? (y/n)"
    if ($overwrite -ne 'y' -and $overwrite -ne 'Y') {
        Write-Info "Используется существующий .env файл"
    } else {
        Copy-Item ".env.example" ".env" -Force
        Write-Success ".env файл создан из шаблона"
    }
} else {
    Copy-Item ".env.example" ".env" -Force
    Write-Success ".env файл создан из шаблона"
}

# Generate random secrets
Write-Info "Генерация случайных ключей безопасности..."

function Get-RandomHex {
    param([int]$Length)
    $bytes = New-Object byte[] ($Length / 2)
    $rng = [System.Security.Cryptography.RNGCryptoServiceProvider]::Create()
    $rng.GetBytes($bytes)
    return ($bytes | ForEach-Object { $_.ToString("x2") }) -join ''
}

$secretKey = Get-RandomHex -Length 64
$postgresPassword = Get-RandomHex -Length 32
$redisPassword = Get-RandomHex -Length 32

# Update .env file
$envContent = Get-Content ".env"
$envContent = $envContent -replace 'your_super_secret_key_change_this_in_production', $secretKey
$envContent = $envContent -replace 'secure_password_2024', $postgresPassword
$envContent = $envContent -replace 'redis_pass_2024', $redisPassword
$envContent | Set-Content ".env"

Write-Success "Случайные ключи сгенерированы и сохранены в .env"

# ============================================
# STEP 9: Configure Telegram API
# ============================================

Write-Header "Настройка Telegram API"

Write-Host "Для работы системы нужны Telegram API credentials" -ForegroundColor Cyan
Write-Host "Получить их можно на: https://my.telegram.org"
Write-Host ""

$configureTelegram = Read-Host "Хотите ввести API credentials сейчас? (y/n)"

if ($configureTelegram -eq 'y' -or $configureTelegram -eq 'Y') {
    $apiId = Read-Host "Введите API ID"
    $apiHash = Read-Host "Введите API Hash"
    
    $envContent = Get-Content ".env"
    $envContent = $envContent -replace 'TELEGRAM_API_ID=.*', "TELEGRAM_API_ID=$apiId"
    $envContent = $envContent -replace 'TELEGRAM_API_HASH=.*', "TELEGRAM_API_HASH=$apiHash"
    $envContent | Set-Content ".env"
    
    Write-Success "Telegram API credentials сохранены"
} else {
    Write-Warning-Custom "Не забудьте добавить Telegram API credentials в .env файл!"
}

# ============================================
# STEP 10: Build and Start
# ============================================

Write-Header "Сборка и запуск системы"

Write-Info "Сборка Docker образов (это может занять 5-10 минут)..."
docker compose build

if ($LASTEXITCODE -eq 0) {
    Write-Success "Образы собраны"
} else {
    Write-Error-Custom "Ошибка при сборке образов"
    exit 1
}

Write-Info "Запуск сервисов..."
docker compose up -d db redis backend frontend

if ($LASTEXITCODE -eq 0) {
    Write-Success "Сервисы запущены"
} else {
    Write-Error-Custom "Ошибка при запуске сервисов"
    exit 1
}

# Wait for database
Write-Info "Ожидание готовности базы данных..."
Start-Sleep -Seconds 15

# Check services
Write-Info "Проверка статуса сервисов..."
docker compose ps

# ============================================
# STEP 11: Optional LLM Installation
# ============================================

Write-Header "Установка LLM (опционально)"

Write-Host "LLM (LLaMA 3.1 8B) используется для генерации персонализированных сообщений" -ForegroundColor Cyan
Write-Host "Размер загрузки: ~4.7GB"
Write-Host ""

$installLLM = Read-Host "Установить LLM сейчас? (y/n)"

if ($installLLM -eq 'y' -or $installLLM -eq 'Y') {
    Write-Info "Запуск Ollama..."
    docker compose up -d ollama
    Start-Sleep -Seconds 10
    
    Write-Info "Загрузка модели LLaMA 3.1 8B (это займет 10-20 минут)..."
    docker exec tg_automation_llm ollama pull llama3.1:8b
    
    Write-Success "LLM установлен и готов к работе"
} else {
    Write-Warning-Custom "LLM не установлен. Система будет использовать шаблоны сообщений."
    Write-Info "Установить позже: docker compose up -d ollama && docker exec tg_automation_llm ollama pull llama3.1:8b"
}

# ============================================
# STEP 12: Create Admin User
# ============================================

Write-Header "Создание администратора"

Write-Info "Создание администратора в базе данных..."
Start-Sleep -Seconds 5

docker exec tg_automation_db psql -U postgres -d telegram_automation -c "INSERT INTO admin_users (username, email, password_hash, is_active) VALUES ('admin', 'admin@example.com', '\`$2b\`$12\`$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5NU7TUQ9aqQ/i', TRUE) ON CONFLICT (username) DO NOTHING;" 2>$null

Write-Success "Администратор создан"

# ============================================
# STEP 13: Final Steps
# ============================================

Write-Header "🎉 Установка завершена!"

Write-Host ""
Write-Host "╔════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║  Telegram Automation Pro успешно установлен!" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Write-Host "🌐 Доступ к системе:" -ForegroundColor Cyan
Write-Host "   Веб-панель: http://localhost:3000"
Write-Host "   API: http://localhost:5000"
Write-Host ""
Write-Host "🔑 Данные для входа:" -ForegroundColor Cyan
Write-Host "   Username: admin"
Write-Host "   Password: admin123"
Write-Host "   ⚠️  ОБЯЗАТЕЛЬНО СМЕНИТЕ ПАРОЛЬ ПОСЛЕ ПЕРВОГО ВХОДА!" -ForegroundColor Red
Write-Host ""
Write-Host "📝 Следующие шаги:" -ForegroundColor Cyan
Write-Host "   1. Откройте веб-панель в браузере"
Write-Host "   2. Войдите и смените пароль администратора"
Write-Host "   3. Создайте Telegram сессию (см. документацию)"
Write-Host "   4. Добавьте целевые группы через веб-панель"
Write-Host "   5. Создайте и запустите кампанию"
Write-Host ""
Write-Host "📊 Полезные команды:" -ForegroundColor Cyan
Write-Host "   Просмотр логов:     docker compose logs -f"
Write-Host "   Остановка:          docker compose down"
Write-Host "   Перезапуск:         docker compose restart"
Write-Host "   Статус сервисов:    docker compose ps"
Write-Host ""
Write-Success "Установка завершена успешно! 🚀"
Write-Host ""

# Open browser
$openBrowser = Read-Host "Открыть веб-панель в браузере? (y/n)"
if ($openBrowser -eq 'y' -or $openBrowser -eq 'Y') {
    Start-Process "http://localhost:3000"
}
