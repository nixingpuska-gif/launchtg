# 🚀 Быстрый старт - Telegram Automation Pro (Windows)

## ⚡ За 5 минут

### Шаг 1: Установите зависимости (один раз)

1. **Python 3.11:**
   - Скачайте: https://www.python.org/downloads/windows/
   - ✅ **ВАЖНО:** При установке поставьте галочку **"Add Python to PATH"**

2. **PostgreSQL 15:**
   - Скачайте: https://www.postgresql.org/download/windows/
   - Запомните пароль для пользователя `postgres`

3. **Ollama (для AI):**
   - Скачайте: https://ollama.ai/download/windows
   - После установки выполните:
     ```cmd
     ollama pull llama3.1:8b
     ```

### Шаг 2: Распакуйте проект

1. Распакуйте `tg-automation-pro-v3.0-windows-complete.zip`

2. Рекомендуемый путь:
   ```
   C:\TelegramAutomation
   ```

### Шаг 3: Установите проект

Откройте **Command Prompt от имени администратора** и выполните:

```cmd
cd C:\TelegramAutomation
install_windows.bat
```

⏱️ Установка займёт 5-10 минут.

### Шаг 4: Настройте конфигурацию

Отредактируйте файлы в папке `config`:

**1. config\database.env:**
```env
DATABASE_URL=postgresql://postgres:ВАШ_ПАРОЛЬ@localhost:5432/telegram_automation
```
Замените `ВАШ_ПАРОЛЬ` на пароль PostgreSQL.

**2. config\telegram.env:**
```env
TELEGRAM_API_ID=12345678
TELEGRAM_API_HASH=abcdef1234567890
TELEGRAM_PHONE=+79991234567
```
Получите API credentials на https://my.telegram.org

**3. config\ai.env:**
```env
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=llama3.1:8b
```
Обычно не требует изменений.

### Шаг 5: Инициализируйте базу данных

```cmd
cd C:\TelegramAutomation
python scripts\init_database_windows.py
```

Должно вывести: `✅ Все 20 таблиц успешно созданы!`

### Шаг 6: Запустите приложение

```cmd
cd C:\TelegramAutomation
run_windows.bat
```

### Шаг 7: Откройте в браузере

```
http://localhost:3000
```

---

## ✅ Готово!

Теперь вы можете:
- ✅ Добавить Telegram-аккаунты
- ✅ Найти конкурентов
- ✅ Парсить аудиторию
- ✅ Отправлять AI-инвайты
- ✅ Автоматизировать всё!

---

## 📚 Документация

- **Полная инструкция:** `WINDOWS_INSTALLATION_GUIDE.md`
- **Решение проблем:** `TROUBLESHOOTING_GUIDE.md`
- **Демонстрация Competitor Intelligence:** `COMPETITOR_INTELLIGENCE_DEMO_REPORT.md`

---

## 🆘 Проблемы?

### Частые ошибки:

**1. "Python не найден"**
- Переустановите Python с галочкой "Add Python to PATH"

**2. "Не удается подключиться к БД"**
- Проверьте, что PostgreSQL запущен (Win + R → `services.msc`)
- Проверьте пароль в `config/database.env`

**3. "Ollama не отвечает"**
- Запустите: `ollama serve`
- Проверьте, что модель скачана: `ollama list`

**4. "Порт 3000 занят"**
- Найдите процесс: `netstat -ano | findstr :3000`
- Убейте процесс: `taskkill /PID [номер] /F`

### Полное руководство по решению проблем:
**TROUBLESHOOTING_GUIDE.md** (20,000+ слов, все возможные проблемы)

---

## 📞 Поддержка

- **Форма:** https://help.manus.im
- **Email:** support@manus.im

---

**Версия:** 3.0.0  
**Платформа:** Windows 10/11 (64-bit)  
**Дата:** 2025-01-20
