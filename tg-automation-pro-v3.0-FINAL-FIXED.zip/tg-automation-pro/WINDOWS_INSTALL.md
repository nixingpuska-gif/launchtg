# 🪟 Установка на Windows - Telegram Automation Pro

## 🚀 Быстрая установка

### Способ 1: Автоматический (рекомендуется)

1. **Распакуйте архив**
   - Щёлкните правой кнопкой на `tg-automation-pro-v1.1.zip`
   - Выберите "Извлечь всё..."
   - Откройте папку `tg-automation-pro`

2. **Запустите установщик**
   - Щёлкните правой кнопкой на `install.bat`
   - Выберите **"Запуск от имени администратора"**
   - Следуйте инструкциям на экране

**Вот и всё!** Установщик сделает всё автоматически 🎉

---

## 📋 Что делает установщик

✅ Проверяет версию Windows (требуется Windows 10/11 64-bit)  
✅ Проверяет системные требования (RAM, CPU, диск)  
✅ Включает Hyper-V или устанавливает WSL 2  
✅ Скачивает и устанавливает Docker Desktop  
✅ Настраивает окружение  
✅ Генерирует ключи безопасности  
✅ Собирает и запускает все сервисы  
✅ Создаёт администратора  

---

## 🖥️ Системные требования

### Минимальные:
- **ОС:** Windows 10 64-bit (версия 2004+) или Windows 11
- **CPU:** 2 ядра
- **RAM:** 4 GB
- **Диск:** 20 GB свободного места
- **Виртуализация:** Включена в BIOS

### Рекомендуемые:
- **CPU:** 4+ ядра
- **RAM:** 8+ GB
- **Диск:** 50+ GB SSD

---

## ⚙️ Ручная установка (если автоматическая не работает)

### Шаг 1: Включение виртуализации в BIOS

1. Перезагрузите компьютер
2. Войдите в BIOS (обычно F2, F10, Del или Esc при загрузке)
3. Найдите настройку виртуализации:
   - Intel: **Intel VT-x** или **Intel Virtualization Technology**
   - AMD: **AMD-V** или **SVM Mode**
4. Включите её
5. Сохраните и выйдите

### Шаг 2: Установка WSL 2

Откройте **PowerShell от имени администратора** и выполните:

```powershell
wsl --install
```

Перезагрузите компьютер.

### Шаг 3: Установка Docker Desktop

1. Скачайте Docker Desktop:
   https://www.docker.com/products/docker-desktop

2. Запустите установщик

3. Следуйте инструкциям

4. Перезагрузите компьютер

5. Запустите Docker Desktop

### Шаг 4: Настройка проекта

Откройте **PowerShell** в папке проекта:

```powershell
# Создать директории
New-Item -ItemType Directory -Force logs, sessions, backups

# Скопировать .env
Copy-Item .env.example .env

# Отредактировать .env (откроется в Блокноте)
notepad .env
```

Измените в `.env`:
- `TELEGRAM_API_ID` - ваш API ID
- `TELEGRAM_API_HASH` - ваш API Hash
- `POSTGRES_PASSWORD` - придумайте пароль
- `REDIS_PASSWORD` - придумайте пароль
- `SECRET_KEY` - случайная строка

### Шаг 5: Запуск

```powershell
# Собрать образы
docker compose build

# Запустить сервисы
docker compose up -d

# Проверить статус
docker compose ps
```

### Шаг 6: Создание администратора

```powershell
docker exec tg_automation_db psql -U postgres -d telegram_automation -c "INSERT INTO admin_users (username, email, password_hash, is_active) VALUES ('admin', 'admin@example.com', '\`$2b\`$12\`$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5NU7TUQ9aqQ/i', TRUE);"
```

---

## 🌐 Доступ к системе

Откройте в браузере:
```
http://localhost:3000
```

**Логин:** `admin`  
**Пароль:** `admin123`

⚠️ **Смените пароль после первого входа!**

---

## 🔧 Управление системой

### Просмотр логов

```powershell
# Все сервисы
docker compose logs -f

# Конкретный сервис
docker compose logs -f backend
```

### Остановка

```powershell
docker compose down
```

### Запуск

```powershell
docker compose up -d
```

### Перезапуск

```powershell
docker compose restart
```

### Статус

```powershell
docker compose ps
```

---

## ❓ Решение проблем

### Ошибка "Virtualization is disabled"

**Решение:**
1. Войдите в BIOS
2. Включите Intel VT-x или AMD-V
3. Сохраните и перезагрузите

### Ошибка "WSL 2 installation is incomplete"

**Решение:**
```powershell
wsl --update
wsl --set-default-version 2
```

### Docker Desktop не запускается

**Решение:**
1. Откройте "Службы" (services.msc)
2. Найдите "Docker Desktop Service"
3. Щёлкните правой кнопкой → Запустить

### Порт 3000 уже занят

**Решение:**
Измените порт в `docker-compose.yml`:

```yaml
frontend:
  ports:
    - "3001:80"  # Вместо 3000
```

### "Access denied" при запуске

**Решение:**
Запустите PowerShell или install.bat **от имени администратора**

### Docker команды не работают

**Решение:**
1. Убедитесь, что Docker Desktop запущен
2. Перезапустите Docker Desktop
3. Перезагрузите компьютер

---

## 🔒 Firewall и антивирус

### Windows Defender

Docker Desktop может запросить разрешение в Firewall - **разрешите доступ**.

### Сторонний антивирус

Если антивирус блокирует Docker:
1. Добавьте Docker Desktop в исключения
2. Добавьте папку проекта в исключения

---

## 💡 Полезные советы

### Ускорение Docker на Windows

1. **Используйте WSL 2** (быстрее чем Hyper-V)
2. **Выделите больше ресурсов:**
   - Docker Desktop → Settings → Resources
   - Увеличьте CPU и Memory

### Где хранятся данные

- **База данных:** Docker volume `postgres_data`
- **Логи:** `./logs/`
- **Сессии:** `./sessions/`
- **Бэкапы:** `./backups/`

### Бэкап данных

```powershell
# Бэкап базы данных
docker exec tg_automation_db pg_dump -U postgres telegram_automation > backup.sql

# Бэкап сессий
Copy-Item -Recurse sessions backups\sessions_backup_$(Get-Date -Format 'yyyyMMdd')
```

---

## 🆘 Получить помощь

1. **Проверьте логи:**
   ```powershell
   docker compose logs -f
   ```

2. **Проверьте документацию:**
   - README.md
   - INSTALLATION.md
   - QUICKSTART.md

3. **GitHub Issues:**
   Создайте issue с описанием проблемы и логами

---

## ✅ Чек-лист после установки

- [ ] Docker Desktop установлен и запущен
- [ ] Все сервисы запущены (`docker compose ps`)
- [ ] Веб-панель открывается (http://localhost:3000)
- [ ] Вход выполнен успешно
- [ ] Пароль администратора изменён
- [ ] Telegram API credentials добавлены в .env
- [ ] Создана хотя бы одна Telegram сессия

---

## 🎉 Готово!

Теперь вы можете начать использовать Telegram Automation Pro на Windows!

**Следующие шаги:**
1. Создайте Telegram сессию (см. документацию)
2. Добавьте целевые группы
3. Запустите первую кампанию

---

**Версия:** 1.2.0  
**Платформа:** Windows 10/11  
**Дата:** 2024
