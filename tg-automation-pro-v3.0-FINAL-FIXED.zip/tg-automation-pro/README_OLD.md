# 🤖 Telegram Automation Pro

**Production-ready, self-hosted, multi-account Telegram automation system with a web-based control panel.**

This system provides a complete solution for parsing Telegram group members, running stealth-inviting campaigns, and managing multiple Telegram accounts with a focus on security, scalability, and performance.

![Dashboard Screenshot](https://i.imgur.com/your-screenshot.png)  <!-- Replace with actual screenshot -->

## ✨ Features

- **Multi-Account Architecture**: Manage hundreds of Telegram accounts with automatic rotation and cooldown.
- **Stealth Inviting**: Advanced inviting mechanism with random delays, adaptive limits, and personalized messages to minimize bans.
- **Powerful Parsing**: Efficiently parse thousands of members from any public group.
- **Web Control Panel**: Modern web interface (React/Flask) to manage campaigns, accounts, and view real-time statistics.
- **LLM Integration**: Generate personalized invite messages using a local LLM (Ollama/Llama 3.1).
- **Advanced Logging**: Centralized logging of every operation (invites, parses, errors) in a PostgreSQL database.
- **Real-time Monitoring**: WebSocket integration for live updates on campaign progress and system status.
- **Dockerized & Scalable**: Fully containerized with Docker Compose for easy deployment and scaling.
- **Secure**: JWT-based authentication for the API and web panel.

## 🚀 Quick Start

### Prerequisites

- A server with Ubuntu 22.04 or later
- Docker and Docker Compose installed
- Git

### 1. Clone the Repository

```bash
git clone <your-repo-url>
cd tg-automation-pro
```

### 2. Run the Deployment Script

This script will set up your environment, build Docker images, and start all services.

```bash
chmod +x scripts/deploy.sh
./scripts/deploy.sh
```

Follow the on-screen instructions. The script will:
1. Check for Docker and Docker Compose.
2. Create a `.env` file from the example. **You will be prompted to edit this file to add your Telegram API credentials.**
3. Build and start all Docker containers.
4. Optionally install the LLM model (`llama3.1:8b`).

### 3. Access the Web Panel

- **URL**: `http://<your-server-ip>:3000`
- **Default Username**: `admin`
- **Default Password**: `admin123`

**⚠️ IMPORTANT:** Change the default password immediately after your first login!

### 4. Create Your First Telegram Session

Run the session creation script to add your first Telegram account to the system.

```bash
./scripts/create_session.sh
```

This script will prompt you for your API ID, API Hash, and phone number. After you enter the verification code, it will generate a session file and provide you with an SQL query.

**Copy the generated SQL query and execute it in your PostgreSQL database** (e.g., using a tool like DBeaver or `psql`) to add the account to the system.

### 5. Start a Campaign

1. **Add Target Groups**: In the web panel, navigate to the "Groups" section and add the usernames or IDs of the groups you want to parse.
2. **Create a Campaign**: Go to the "Campaigns" section and create a new campaign. Choose the type (parsing, inviting, or combined), select your target groups, and configure the settings.
3. **Start the Campaign**: Click the "Start" button on your newly created campaign.

That's it! The background worker will pick up the campaign and start executing the tasks. You can monitor the progress in real-time on the dashboard.

## 🛠️ Architecture

The system is composed of several microservices, all managed by Docker Compose:

- **`frontend`**: Nginx server for the React-based web panel.
- **`backend`**: Flask/Gunicorn API server providing the REST API and WebSocket for the frontend.
- **`bot_worker`**: Python background worker that handles the heavy lifting (parsing and inviting).
- **`db`**: PostgreSQL database for all data storage.
- **`redis`**: Redis for caching and message queuing (future use).
- **`llm`**: Ollama service for running the local Large Language Model.

![Architecture Diagram](https://i.imgur.com/your-architecture-diagram.png) <!-- Replace with actual diagram -->

## ⚙️ Configuration

All configuration is managed through the `.env` file. Key variables include:

- `DATABASE_URL`: Connection string for the PostgreSQL database.
- `REDIS_URL`: Connection string for Redis.
- `LLM_API_URL`: URL for the Ollama API.
- `LLM_MODEL`: The LLM model to use (e.g., `llama3.1:8b`).
- `SECRET_KEY`: Secret key for signing JWT tokens.
- `CORS_ORIGINS`: Allowed origins for the API.

## 📦 Database Schema

The database schema is designed for performance and scalability. Key tables include:

- `telegram_accounts`: Stores all managed Telegram accounts and their status.
- `parsed_users`: Stores all users parsed from target groups.
- `target_groups`: List of groups to parse.
- `campaigns`: Configuration for parsing and inviting campaigns.
- `invite_logs`: Detailed log of every invite attempt.
- `parsing_logs`: Log of all parsing operations.
- `system_logs`: General system events and errors.
- `notifications`: Important system notifications for the admin.

See `database/init.sql` for the complete schema.

## API Endpoints

The backend provides a comprehensive REST API for managing the system. All endpoints are protected and require a JWT token.

- `POST /api/auth/login`: Authenticate and get a token.
- `GET /api/dashboard/stats`: Get dashboard statistics.
- `GET /api/accounts`: List all Telegram accounts.
- `POST /api/campaigns`: Create a new campaign.
- `POST /api/campaigns/<id>/start`: Start a campaign.

...and many more. See `backend/app.py` for the full list of routes.

## 📜 Scripts

- `scripts/deploy.sh`: Main deployment script.
- `scripts/create_session.sh`: Interactively create a new Telegram session file.
- `scripts/backup.sh` (TODO): Script for backing up the database.

## 🤝 Contributing

Contributions, issues, and feature requests are welcome! Feel free to check the [issues page](<your-repo-url>/issues).

## 📄 License

This project is licensed under the MIT License. See the `LICENSE` file for details.
