"""Network Graph Intelligence - анализ графа связей групп и пользователей"""
