"""Automated Retargeting - ретаргетинг пользователей"""
