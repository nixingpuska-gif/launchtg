"""
AI-Powered Content Generation Module
Генерирует персонализированные сообщения через локальную LLM
"""

import asyncio
import json
import logging
from typing import Dict, List, Optional
from datetime import datetime
import aiohttp
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class UserProfile:
    """Профиль пользователя для персонализации"""
    user_id: int
    username: Optional[str]
    first_name: Optional[str]
    last_name: Optional[str]
    bio: Optional[str]
    recent_messages: List[str]
    interests: List[str]
    language: str
    activity_score: float


@dataclass
class GroupContext:
    """Контекст группы для персонализации"""
    group_id: int
    group_name: str
    group_topic: str
    recent_topics: List[str]
    active_keywords: List[str]


class AIContentGenerator:
    """
    Генератор персонализированного контента через LLM
    
    Возможности:
    - Анализ профиля пользователя
    - Генерация уникальных сообщений
    - Адаптация под контекст группы
    - Множество стилей общения
    - Антиспам-проверка
    """
    
    def __init__(self, ollama_url: str = "http://localhost:11434", model: str = "llama3.1:8b"):
        self.ollama_url = ollama_url
        self.model = model
        self.session: Optional[aiohttp.ClientSession] = None
        
        # Шаблоны промптов для разных сценариев
        self.prompts = {
            "invite": """Ты - дружелюбный пользователь Telegram, который приглашает людей в группу.

ПРОФИЛЬ ПОЛЬЗОВАТЕЛЯ:
- Имя: {first_name}
- Username: @{username}
- Интересы: {interests}
- Последние сообщения: {recent_messages}

КОНТЕКСТ ГРУППЫ:
- Название: {group_name}
- Тема: {group_topic}
- Актуальные темы: {recent_topics}

ТВОЯ ЗАДАЧА:
Напиши короткое (2-3 предложения) персонализированное приглашение в группу "{target_group}".

ТРЕБОВАНИЯ:
1. Обращайся по имени
2. Упомяни что-то из его интересов или сообщений
3. Покажи, почему группа будет ему полезна
4. Пиши естественно, как живой человек
5. НЕ используй шаблонные фразы типа "Привет! Приглашаю в группу"
6. Будь дружелюбным, но не навязчивым

ПРИМЕРЫ ХОРОШИХ ПРИГЛАШЕНИЙ:
- "Эй, {first_name}! Видел твой коммент про {topic}, тоже интересуюсь. У нас в {group} как раз обсуждали это вчера, думаю тебе зайдёт!"
- "{first_name}, привет! Ты писал про {interest}? В {group} куча людей с такими же интересами, заходи пообщаться!"

Напиши ТОЛЬКО текст приглашения, без комментариев:""",

            "comment": """Ты - активный участник Telegram-группы, который оставляет комментарии.

КОНТЕКСТ ГРУППЫ:
- Название: {group_name}
- Тема: {group_topic}
- Последнее сообщение: {last_message}

ТВОЯ ЗАДАЧА:
Напиши естественный комментарий к последнему сообщению.

ТРЕБОВАНИЯ:
1. Будь релевантным к теме
2. Добавь ценность (инсайт, вопрос, мнение)
3. Пиши как живой человек
4. 1-2 предложения
5. Можешь использовать эмодзи (но умеренно)

Напиши ТОЛЬКО текст комментария:""",

            "dm": """Ты - пользователь Telegram, который пишет в личные сообщения.

ПРОФИЛЬ ПОЛУЧАТЕЛЯ:
- Имя: {first_name}
- Интересы: {interests}
- Откуда узнал: {source_group}

ЦЕЛЬ СООБЩЕНИЯ:
{goal}

ТВОЯ ЗАДАЧА:
Напиши короткое (2-3 предложения) персонализированное сообщение.

ТРЕБОВАНИЯ:
1. Представься естественно
2. Объясни, откуда ты
3. Предложи ценность
4. НЕ будь спамером
5. Пиши дружелюбно

Напиши ТОЛЬКО текст сообщения:"""
        }
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
    
    async def generate_invite_message(
        self,
        user_profile: UserProfile,
        group_context: GroupContext,
        target_group: str
    ) -> str:
        """
        Генерирует персонализированное приглашение
        
        Args:
            user_profile: Профиль пользователя
            group_context: Контекст текущей группы
            target_group: Название целевой группы
            
        Returns:
            Персонализированное сообщение-приглашение
        """
        prompt = self.prompts["invite"].format(
            first_name=user_profile.first_name or user_profile.username or "друг",
            username=user_profile.username or "пользователь",
            interests=", ".join(user_profile.interests[:3]) if user_profile.interests else "общение",
            recent_messages="; ".join(user_profile.recent_messages[:2]) if user_profile.recent_messages else "нет данных",
            group_name=group_context.group_name,
            group_topic=group_context.group_topic,
            recent_topics=", ".join(group_context.recent_topics[:3]) if group_context.recent_topics else "разные темы",
            target_group=target_group
        )
        
        message = await self._call_llm(prompt)
        
        # Проверка на спам-паттерны
        if self._is_spam_like(message):
            logger.warning(f"Сгенерированное сообщение похоже на спам, регенерация...")
            return await self.generate_invite_message(user_profile, group_context, target_group)
        
        return message
    
    async def generate_comment(
        self,
        group_context: GroupContext,
        last_message: str
    ) -> str:
        """
        Генерирует комментарий к сообщению в группе
        
        Args:
            group_context: Контекст группы
            last_message: Последнее сообщение для комментирования
            
        Returns:
            Естественный комментарий
        """
        prompt = self.prompts["comment"].format(
            group_name=group_context.group_name,
            group_topic=group_context.group_topic,
            last_message=last_message[:500]  # Ограничение длины
        )
        
        return await self._call_llm(prompt)
    
    async def generate_dm(
        self,
        user_profile: UserProfile,
        source_group: str,
        goal: str
    ) -> str:
        """
        Генерирует сообщение для личной переписки
        
        Args:
            user_profile: Профиль получателя
            source_group: Группа, где нашли пользователя
            goal: Цель сообщения
            
        Returns:
            Персонализированное DM
        """
        prompt = self.prompts["dm"].format(
            first_name=user_profile.first_name or user_profile.username or "друг",
            interests=", ".join(user_profile.interests[:3]) if user_profile.interests else "общение",
            source_group=source_group,
            goal=goal
        )
        
        return await self._call_llm(prompt)
    
    async def _call_llm(self, prompt: str, temperature: float = 0.8) -> str:
        """
        Вызов Ollama API для генерации текста
        
        Args:
            prompt: Промпт для LLM
            temperature: Температура генерации (0.0-1.0)
            
        Returns:
            Сгенерированный текст
        """
        if not self.session:
            self.session = aiohttp.ClientSession()
        
        try:
            payload = {
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": temperature,
                    "top_p": 0.9,
                    "top_k": 40,
                    "num_predict": 200  # Максимум токенов
                }
            }
            
            async with self.session.post(
                f"{self.ollama_url}/api/generate",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=60)
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    generated_text = data.get("response", "").strip()
                    logger.info(f"Сгенерирован текст: {generated_text[:100]}...")
                    return generated_text
                else:
                    error_text = await response.text()
                    logger.error(f"Ошибка Ollama API: {response.status} - {error_text}")
                    return self._get_fallback_message()
        
        except asyncio.TimeoutError:
            logger.error("Timeout при обращении к Ollama")
            return self._get_fallback_message()
        except Exception as e:
            logger.error(f"Ошибка при вызове LLM: {e}")
            return self._get_fallback_message()
    
    def _is_spam_like(self, message: str) -> bool:
        """
        Проверяет, похоже ли сообщение на спам
        
        Args:
            message: Текст сообщения
            
        Returns:
            True если похоже на спам
        """
        spam_indicators = [
            "кликни здесь",
            "переходи по ссылке",
            "100% гарантия",
            "заработок без вложений",
            "срочно",
            "только сегодня",
            "успей",
            "ограниченное предложение",
            "!!!",
            "💰💰💰"
        ]
        
        message_lower = message.lower()
        spam_count = sum(1 for indicator in spam_indicators if indicator in message_lower)
        
        # Если больше 2 спам-индикаторов - это спам
        return spam_count >= 2
    
    def _get_fallback_message(self) -> str:
        """Возвращает запасное сообщение при ошибке LLM"""
        fallbacks = [
            "Привет! Интересная группа, правда?",
            "Эй, как дела? Давно в этой теме?",
            "Привет! Тоже интересуюсь этой темой",
        ]
        import random
        return random.choice(fallbacks)
    
    def personalize_message(self, template: str, user_data: dict) -> str:
        """
        Персонализирует шаблон сообщения под пользователя
        
        Args:
            template: Шаблон с плейсхолдерами {name}, {interest} и т.д.
            user_data: Данные пользователя
            
        Returns:
            Персонализированное сообщение
        """
        replacements = {
            'name': user_data.get('first_name', user_data.get('username', 'друг')),
            'username': user_data.get('username', 'пользователь'),
            'interest': user_data.get('interests', ['общение'])[0] if user_data.get('interests') else 'общение',
            'bio': user_data.get('bio', ''),
        }
        
        message = template
        for key, value in replacements.items():
            message = message.replace(f'{{{key}}}', str(value))
        
        return message
    
    def analyze_user_profile(self, user_data: dict) -> dict:
        """
        Анализирует профиль пользователя для персонализации
        
        Args:
            user_data: Данные пользователя
            
        Returns:
            Анализ профиля с рекомендациями
        """
        analysis = {
            'engagement_level': 'high' if user_data.get('activity_score', 0) > 0.7 else 'medium' if user_data.get('activity_score', 0) > 0.4 else 'low',
            'interests_count': len(user_data.get('interests', [])),
            'has_bio': bool(user_data.get('bio')),
            'message_style': 'formal' if user_data.get('bio', '').find('CEO') != -1 or user_data.get('bio', '').find('Founder') != -1 else 'casual',
            'recommended_approach': 'direct' if user_data.get('activity_score', 0) > 0.7 else 'soft'
        }
        
        return analysis
    
    def generate_variations(self, base_message: str, count: int = 3) -> List[str]:
        """
        Генерирует вариации сообщения для A/B тестирования
        
        Args:
            base_message: Базовое сообщение
            count: Количество вариаций
            
        Returns:
            Список вариаций
        """
        variations = [base_message]
        
        # Вариация 1: Добавление эмодзи
        if count >= 2:
            emojis = ['👋', '🔥', '💡', '🚀', '✨']
            import random
            emoji = random.choice(emojis)
            variations.append(f"{emoji} {base_message}")
        
        # Вариация 2: Изменение начала
        if count >= 3:
            starters = ['Привет!', 'Эй,', 'Здравствуй,', 'Добрый день,']
            import random
            starter = random.choice(starters)
            if base_message.startswith(('Привет', 'Эй', 'Здравствуй')):
                parts = base_message.split(' ', 1)
                if len(parts) > 1:
                    variations.append(f"{starter} {parts[1]}")
            else:
                variations.append(f"{starter} {base_message}")
        
        # Вариация 3: Добавление вопроса
        if count >= 4:
            questions = ['Интересно?', 'Как думаешь?', 'Заинтересовало?']
            import random
            question = random.choice(questions)
            variations.append(f"{base_message} {question}")
        
        return variations[:count]
    
    async def batch_generate(
        self,
        users: List[UserProfile],
        group_context: GroupContext,
        target_group: str,
        max_concurrent: int = 3
    ) -> Dict[int, str]:
        """
        Генерирует сообщения для множества пользователей параллельно
        
        Args:
            users: Список профилей пользователей
            group_context: Контекст группы
            target_group: Целевая группа
            max_concurrent: Максимум параллельных запросов
            
        Returns:
            Словарь {user_id: message}
        """
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def generate_with_limit(user: UserProfile):
            async with semaphore:
                try:
                    message = await self.generate_invite_message(user, group_context, target_group)
                    return user.user_id, message
                except Exception as e:
                    logger.error(f"Ошибка генерации для {user.user_id}: {e}")
                    return user.user_id, self._get_fallback_message()
        
        results = await asyncio.gather(*[generate_with_limit(user) for user in users])
        return dict(results)


# Пример использования
async def main():
    """Тестовый пример"""
    
    # Создаём профиль пользователя
    user = UserProfile(
        user_id=123456789,
        username="cryptoking",
        first_name="Александр",
        last_name="Иванов",
        bio="Трейдер, интересуюсь криптой",
        recent_messages=[
            "SOL сегодня хорошо растёт",
            "Кто-нибудь следит за новостями по ETH?"
        ],
        interests=["криптовалюты", "трейдинг", "DeFi"],
        language="ru",
        activity_score=0.8
    )
    
    # Контекст группы
    group = GroupContext(
        group_id=-1001234567890,
        group_name="Crypto Talks",
        group_topic="Обсуждение криптовалют",
        recent_topics=["Solana", "Ethereum", "Bitcoin"],
        active_keywords=["SOL", "ETH", "BTC", "pump", "dump"]
    )
    
    # Генерируем приглашение
    async with AIContentGenerator() as generator:
        invite = await generator.generate_invite_message(user, group, "Crypto Insights")
        print(f"Приглашение: {invite}")
        
        comment = await generator.generate_comment(group, "SOL сегодня пробил $200!")
        print(f"Комментарий: {comment}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())
