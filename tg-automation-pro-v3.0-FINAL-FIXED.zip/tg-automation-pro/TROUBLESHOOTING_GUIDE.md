# 🔧 Решение проблем - Telegram Automation Pro (Windows)

## 📋 Содержание

1. [Проблемы с Python](#проблемы-с-python)
2. [Проблемы с базой данных](#проблемы-с-базой-данных)
3. [Проблемы с Telegram API](#проблемы-с-telegram-api)
4. [Проблемы с Ollama/AI](#проблемы-с-ollamaai)
5. [Проблемы с запуском](#проблемы-с-запуском)
6. [Проблемы с производительностью](#проблемы-с-производительностью)
7. [Проблемы с антивирусом](#проблемы-с-антивирусом)
8. [Общие ошибки](#общие-ошибки)

---

## 🐍 Проблемы с Python

### Ошибка: "Python не найден"

```
'python' is not recognized as an internal or external command
```

**Причина:** Python не установлен или не добавлен в PATH

**Решение 1: Переустановка с правильными настройками**

1. Удалите текущую версию Python:
   - Панель управления → Программы → Удалить программу
   - Найдите Python 3.11 → Удалить

2. Скачайте новую версию:
   ```
   https://www.python.org/downloads/windows/
   ```

3. При установке:
   - ✅ **ОБЯЗАТЕЛЬНО** поставьте галочку **"Add Python to PATH"**
   - Выберите "Customize installation"
   - Убедитесь, что выбраны: pip, py launcher, for all users

4. После установки перезагрузите Command Prompt

5. Проверьте:
   ```cmd
   python --version
   pip --version
   ```

**Решение 2: Добавление в PATH вручную**

1. Найдите путь к Python:
   ```
   C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\AppData\Local\Programs\Python\Python311
   ```

2. Добавьте в PATH:
   - Win + X → Система
   - Дополнительные параметры системы
   - Переменные среды
   - В разделе "Системные переменные" найдите "Path"
   - Нажмите "Изменить"
   - Добавьте две строки:
     ```
     C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\AppData\Local\Programs\Python\Python311
     C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\AppData\Local\Programs\Python\Python311\Scripts
     ```

3. Нажмите OK и перезагрузите Command Prompt

### Ошибка: "pip не найден"

```
'pip' is not recognized as an internal or external command
```

**Решение:**

```cmd
python -m ensurepip --upgrade
python -m pip install --upgrade pip
```

### Ошибка: Неправильная версия Python

```
Python 2.7.x detected, but Python 3.11+ required
```

**Решение:**

1. Проверьте версию:
   ```cmd
   python --version
   ```

2. Если версия < 3.11, установите Python 3.11:
   ```
   https://www.python.org/downloads/windows/
   ```

3. Используйте конкретную версию:
   ```cmd
   py -3.11 --version
   ```

---

## 🗄️ Проблемы с базой данных

### Ошибка: "Не удается подключиться к PostgreSQL"

```
psycopg2.OperationalError: could not connect to server: Connection refused
```

**Причина:** PostgreSQL не запущен

**Решение:**

1. Проверьте статус службы:
   - Win + R → `services.msc`
   - Найдите `postgresql-x64-15` (или похожее название)
   - Проверьте статус

2. Если служба остановлена:
   - Правый клик → Запустить
   - Правый клик → Свойства → Тип запуска: Автоматически

3. Если служба не найдена:
   - PostgreSQL не установлен
   - Установите PostgreSQL 15.x:
     ```
     https://www.postgresql.org/download/windows/
     ```

### Ошибка: "Неправильный пароль"

```
psycopg2.OperationalError: FATAL: password authentication failed for user "postgres"
```

**Решение:**

1. Откройте `config/database.env`

2. Проверьте пароль:
   ```env
   DATABASE_URL=postgresql://postgres:ВАШ_ПАРОЛЬ@localhost:5432/telegram_automation
   ```

3. Если забыли пароль, сбросьте его:
   - Откройте `C:\Program Files\PostgreSQL\15\data\pg_hba.conf`
   - Найдите строку:
     ```
     host    all             all             127.0.0.1/32            scram-sha-256
     ```
   - Замените на:
     ```
     host    all             all             127.0.0.1/32            trust
     ```
   - Перезапустите PostgreSQL
   - Подключитесь без пароля:
     ```cmd
     psql -U postgres
     ```
   - Смените пароль:
     ```sql
     ALTER USER postgres PASSWORD 'новый_пароль';
     ```
   - Верните `scram-sha-256` в `pg_hba.conf`
   - Перезапустите PostgreSQL

### Ошибка: "База данных не существует"

```
psycopg2.OperationalError: FATAL: database "telegram_automation" does not exist
```

**Решение:**

1. Создайте БД вручную:
   ```cmd
   psql -U postgres
   ```

2. В psql:
   ```sql
   CREATE DATABASE telegram_automation;
   \q
   ```

3. Или запустите скрипт инициализации:
   ```cmd
   python scripts\init_database_windows.py
   ```

### Ошибка: "Порт 5432 занят"

```
could not bind IPv4 address "127.0.0.1": Address already in use
```

**Решение:**

1. Найдите процесс:
   ```cmd
   netstat -ano | findstr :5432
   ```

2. Убейте процесс:
   ```cmd
   taskkill /PID [номер] /F
   ```

3. Или измените порт PostgreSQL:
   - Откройте `C:\Program Files\PostgreSQL\15\data\postgresql.conf`
   - Найдите `port = 5432`
   - Измените на `port = 5433`
   - Перезапустите PostgreSQL
   - Обновите `config/database.env`:
     ```env
     DATABASE_URL=postgresql://postgres:password@localhost:5433/telegram_automation
     ```

---

## 📱 Проблемы с Telegram API

### Ошибка: "API ID или Hash неверны"

```
telethon.errors.rpcerrorlist.ApiIdInvalidError: The api_id/api_hash combination is invalid
```

**Решение:**

1. Получите правильные credentials:
   - Перейдите на https://my.telegram.org
   - Войдите с вашим номером телефона
   - API development tools
   - Создайте новое приложение

2. Скопируйте `api_id` и `api_hash`

3. Откройте `config/telegram.env`:
   ```env
   TELEGRAM_API_ID=12345678
   TELEGRAM_API_HASH=abcdef1234567890abcdef1234567890
   TELEGRAM_PHONE=+79991234567
   ```

4. Убедитесь, что:
   - `api_id` - это число (без кавычек)
   - `api_hash` - это строка из 32 символов
   - `phone` - с кодом страны (+7, +1, и т.д.)

### Ошибка: "Неправильный код"

```
telethon.errors.rpcerrorlist.PhoneCodeInvalidError: The phone code entered was invalid
```

**Решение:**

1. Проверьте код из Telegram (должен прийти в течение 1 минуты)

2. Введите код **без пробелов и дефисов**:
   - ✅ Правильно: `12345`
   - ❌ Неправильно: `1-2-3-4-5` или `1 2 3 4 5`

3. Если код не пришёл:
   - Проверьте номер телефона
   - Запросите код повторно
   - Проверьте, что номер не заблокирован

### Ошибка: "FloodWaitError"

```
telethon.errors.rpcerrorlist.FloodWaitError: A wait of 86400 seconds is required
```

**Причина:** Telegram временно ограничил аккаунт из-за слишком частых запросов

**Решение:**

1. **Подождите указанное время** (в примере 86400 секунд = 24 часа)

2. Используйте другой аккаунт

3. В будущем:
   - Уменьшите количество запросов
   - Увеличьте задержки между действиями
   - Используйте Account Warming

### Ошибка: "AuthKeyUnregisteredError"

```
telethon.errors.rpcerrorlist.AuthKeyUnregisteredError: The key is not registered in the system
```

**Причина:** Сессия устарела или аккаунт разлогинился

**Решение:**

1. Удалите файл сессии:
   ```cmd
   del sessions\+79991234567.session
   ```

2. Авторизуйтесь заново через веб-панель

### Ошибка: "UserDeactivatedError"

```
telethon.errors.rpcerrorlist.UserDeactivatedError: The user has been deleted/deactivated
```

**Причина:** Аккаунт забанен или удалён

**Решение:**

1. Проверьте аккаунт в официальном Telegram

2. Если забанен:
   - Обратитесь в поддержку Telegram: @SpamBot
   - Используйте другой аккаунт

3. Если удалён:
   - Создайте новый аккаунт
   - Используйте Account Warming перед активными действиями

---

## 🤖 Проблемы с Ollama/AI

### Ошибка: "Ollama не отвечает"

```
ConnectionError: Could not connect to Ollama at http://localhost:11434
```

**Решение:**

1. Проверьте, что Ollama установлен:
   ```cmd
   ollama --version
   ```

2. Если не установлен:
   ```
   https://ollama.ai/download/windows
   ```

3. Запустите Ollama:
   ```cmd
   ollama serve
   ```

4. Проверьте, что сервер работает:
   ```cmd
   curl http://localhost:11434
   ```
   Должен вернуть: `Ollama is running`

### Ошибка: "Модель не найдена"

```
Error: model 'llama3.1:8b' not found
```

**Решение:**

1. Скачайте модель:
   ```cmd
   ollama pull llama3.1:8b
   ```
   ⏱️ Это займёт 10-15 минут (размер ~4.7 GB)

2. Проверьте список моделей:
   ```cmd
   ollama list
   ```

3. Если модель есть, но ошибка остаётся:
   - Проверьте `config/ai.env`:
     ```env
     OLLAMA_MODEL=llama3.1:8b
     ```

### Ошибка: "Недостаточно памяти для модели"

```
Error: failed to load model: insufficient memory
```

**Решение:**

1. Закройте другие приложения

2. Используйте меньшую модель:
   ```cmd
   ollama pull llama3.1:3b
   ```

3. Обновите `config/ai.env`:
   ```env
   OLLAMA_MODEL=llama3.1:3b
   ```

### Ошибка: "Ollama медленно генерирует"

**Решение:**

1. Используйте GPU (если есть):
   - Ollama автоматически использует NVIDIA GPU
   - Проверьте: `nvidia-smi`

2. Увеличьте RAM для Ollama:
   - Закройте другие приложения
   - Используйте 8+ GB RAM

3. Используйте меньшую модель:
   ```cmd
   ollama pull llama3.1:3b
   ```

---

## 🚀 Проблемы с запуском

### Ошибка: "Порт 3000 занят"

```
OSError: [WinError 10048] Only one usage of each socket address (protocol/network address/port) is normally permitted
```

**Решение 1: Освободить порт**

1. Найдите процесс:
   ```cmd
   netstat -ano | findstr :3000
   ```

2. Убейте процесс:
   ```cmd
   taskkill /PID [номер] /F
   ```

**Решение 2: Изменить порт**

1. Откройте `web/app.py`

2. Найдите строку:
   ```python
   app.run(host='0.0.0.0', port=3000)
   ```

3. Измените на:
   ```python
   app.run(host='0.0.0.0', port=3001)
   ```

4. Откройте в браузере:
   ```
   http://localhost:3001
   ```

### Ошибка: "Модуль не найден"

```
ModuleNotFoundError: No module named 'telethon'
```

**Решение:**

1. Активируйте виртуальное окружение:
   ```cmd
   venv\Scripts\activate
   ```

2. Установите зависимости:
   ```cmd
   pip install -r requirements.txt
   ```

3. Если не помогает, установите вручную:
   ```cmd
   pip install telethon pyrogram flask sqlalchemy psycopg2-binary
   ```

### Ошибка: "Конфигурация не найдена"

```
FileNotFoundError: config/database.env not found
```

**Решение:**

1. Создайте файл `config/database.env`:
   ```env
   DATABASE_URL=postgresql://postgres:password@localhost:5432/telegram_automation
   ```

2. Создайте файл `config/telegram.env`:
   ```env
   TELEGRAM_API_ID=12345678
   TELEGRAM_API_HASH=abcdef1234567890
   TELEGRAM_PHONE=+79991234567
   ```

3. Создайте файл `config/ai.env`:
   ```env
   OLLAMA_HOST=http://localhost:11434
   OLLAMA_MODEL=llama3.1:8b
   ```

---

## ⚡ Проблемы с производительностью

### Проблема: "Приложение медленно работает"

**Решение:**

1. **Увеличьте RAM:**
   - Закройте другие приложения
   - Используйте минимум 8 GB RAM

2. **Используйте SSD:**
   - Перенесите проект на SSD
   - Это ускорит работу БД

3. **Оптимизируйте PostgreSQL:**
   - Откройте `postgresql.conf`
   - Увеличьте `shared_buffers`:
     ```
     shared_buffers = 256MB
     ```
   - Увеличьте `work_mem`:
     ```
     work_mem = 16MB
     ```

4. **Уменьшите нагрузку:**
   - Уменьшите количество одновременных задач
   - Увеличьте задержки между запросами

### Проблема: "Высокое использование CPU"

**Решение:**

1. Проверьте процессы:
   ```cmd
   tasklist | findstr python
   ```

2. Уменьшите количество воркеров в `web/app.py`:
   ```python
   app.run(host='0.0.0.0', port=3000, threaded=False)
   ```

3. Используйте меньшую модель Ollama:
   ```cmd
   ollama pull llama3.1:3b
   ```

### Проблема: "База данных переполнена"

**Решение:**

1. Очистите старые данные:
   ```sql
   DELETE FROM activity_logs WHERE created_at < NOW() - INTERVAL '30 days';
   DELETE FROM ban_metrics WHERE recorded_at < NOW() - INTERVAL '30 days';
   ```

2. Включите автоочистку в PostgreSQL:
   ```sql
   ALTER TABLE activity_logs SET (autovacuum_enabled = true);
   ```

---

## 🛡️ Проблемы с антивирусом

### Проблема: "Файлы удаляются или блокируются"

**Решение:**

1. **Добавьте в исключения Windows Defender:**
   - Безопасность Windows
   - Защита от вирусов и угроз
   - Управление параметрами
   - Исключения → Добавить исключение
   - Папка → Выберите `C:\TelegramAutomation`

2. **Отключите защиту в реальном времени (временно):**
   - Безопасность Windows
   - Защита от вирусов и угроз
   - Управление параметрами
   - Защита в реальном времени → Отключить

3. **Для других антивирусов:**
   - Avast: Настройки → Исключения
   - Kaspersky: Настройки → Дополнительно → Угрозы и исключения
   - Norton: Настройки → Антивирус → Сканирование и риски → Исключения

### Проблема: "Брандмауэр блокирует соединения"

**Решение:**

1. Откройте Брандмауэр Windows:
   - Win + R → `firewall.cpl`

2. Разрешающие правила для входящих подключений:
   - Правила для входящих подключений → Создать правило
   - Тип: Программа
   - Путь: `C:\TelegramAutomation\venv\Scripts\python.exe`
   - Действие: Разрешить подключение
   - Профили: Все
   - Имя: Telegram Automation Pro

3. То же для исходящих подключений

---

## 🔍 Общие ошибки

### Ошибка: "Permission denied"

```
PermissionError: [WinError 5] Access is denied
```

**Решение:**

1. Запустите Command Prompt от имени администратора:
   - Win + X
   - Терминал (Администратор)

2. Или измените права на папку:
   - Правый клик на `C:\TelegramAutomation`
   - Свойства → Безопасность
   - Изменить → Добавить → Все
   - Полный доступ → OK

### Ошибка: "SSL Certificate Error"

```
SSLError: [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed
```

**Решение:**

1. Обновите certifi:
   ```cmd
   pip install --upgrade certifi
   ```

2. Или отключите проверку SSL (не рекомендуется):
   ```python
   import ssl
   ssl._create_default_https_context = ssl._create_unverified_context
   ```

### Ошибка: "Encoding Error"

```
UnicodeDecodeError: 'charmap' codec can't decode byte
```

**Решение:**

1. Установите кодировку UTF-8:
   ```cmd
   chcp 65001
   ```

2. Или добавьте в начало скрипта:
   ```python
   # -*- coding: utf-8 -*-
   ```

---

## 📞 Если ничего не помогло

### Соберите диагностическую информацию:

1. **Версии:**
   ```cmd
   python --version
   pip --version
   psql --version
   ollama --version
   ```

2. **Логи:**
   ```
   C:\TelegramAutomation\logs\app.log
   ```

3. **Конфигурация:**
   ```
   config\database.env
   config\telegram.env
   config\ai.env
   ```

4. **Скриншот ошибки**

### Обратитесь в поддержку:

- **Форма:** https://help.manus.im
- **Email:** support@manus.im
- **Telegram:** @your_support_channel

Укажите:
- Версию Windows
- Версию Python
- Текст ошибки
- Что вы уже пробовали
- Скриншоты

---

## ✅ Чек-лист диагностики

Перед обращением в поддержку проверьте:

- [ ] Python 3.11+ установлен и в PATH
- [ ] pip работает
- [ ] PostgreSQL установлен и запущен
- [ ] Ollama установлен и модель скачана
- [ ] Все зависимости установлены (`pip list`)
- [ ] Конфигурационные файлы созданы и заполнены
- [ ] База данных инициализирована
- [ ] Порты 3000, 5432, 11434 свободны
- [ ] Антивирус не блокирует файлы
- [ ] Брандмауэр разрешает соединения
- [ ] Логи проверены (`logs/app.log`)

---

**Версия:** 1.0.0  
**Дата:** 2025-01-20  
**Платформа:** Windows 10/11
