-- ============================================
-- Telegram Automation Pro v2.0
-- Database Schema with Projects & Channels
-- ============================================

-- Projects table
CREATE TABLE IF NOT EXISTS projects (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    color VARCHAR(7) DEFAULT '#667eea',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_projects_active ON projects(is_active);

-- Telegram accounts (updated with project_id)
CREATE TABLE IF NOT EXISTS telegram_accounts (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    phone VARCHAR(20) UNIQUE NOT NULL,
    username VARCHAR(100),
    api_id VARCHAR(50) NOT NULL,
    api_hash VARCHAR(100) NOT NULL,
    session_string TEXT,
    proxy_host VARCHAR(255),
    proxy_port INTEGER,
    proxy_username VARCHAR(100),
    proxy_password VARCHAR(100),
    status VARCHAR(20) DEFAULT 'active',
    daily_invite_limit INTEGER DEFAULT 30,
    invites_today INTEGER DEFAULT 0,
    last_invite_at TIMESTAMP,
    cooldown_until TIMESTAMP,
    ban_count INTEGER DEFAULT 0,
    last_ban_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_accounts_project ON telegram_accounts(project_id);
CREATE INDEX idx_accounts_status ON telegram_accounts(status);
CREATE INDEX idx_accounts_phone ON telegram_accounts(phone);

-- Target groups (updated with project_id)
CREATE TABLE IF NOT EXISTS target_groups (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    group_id BIGINT,
    username VARCHAR(100),
    title VARCHAR(255),
    member_count INTEGER,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    last_parsed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_groups_project ON target_groups(project_id);
CREATE INDEX idx_groups_username ON target_groups(username);
CREATE INDEX idx_groups_active ON target_groups(is_active);

-- Channels table (NEW)
CREATE TABLE IF NOT EXISTS channels (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    channel_id BIGINT,
    username VARCHAR(100),
    title VARCHAR(255),
    description TEXT,
    subscriber_count INTEGER DEFAULT 0,
    post_count INTEGER DEFAULT 0,
    avg_views_per_post INTEGER DEFAULT 0,
    auto_posting_enabled BOOLEAN DEFAULT FALSE,
    posting_interval VARCHAR(50),
    last_post_at TIMESTAMP,
    next_post_at TIMESTAMP,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_channels_project ON channels(project_id);
CREATE INDEX idx_channels_username ON channels(username);
CREATE INDEX idx_channels_status ON channels(status);
CREATE INDEX idx_channels_auto_posting ON channels(auto_posting_enabled);

-- Channel posts (NEW)
CREATE TABLE IF NOT EXISTS channel_posts (
    id SERIAL PRIMARY KEY,
    channel_id INTEGER REFERENCES channels(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    media_url TEXT,
    views INTEGER DEFAULT 0,
    reactions INTEGER DEFAULT 0,
    scheduled_for TIMESTAMP,
    posted_at TIMESTAMP,
    status VARCHAR(20) DEFAULT 'draft',
    generated_by_llm BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_posts_channel ON channel_posts(channel_id);
CREATE INDEX idx_posts_status ON channel_posts(status);
CREATE INDEX idx_posts_scheduled ON channel_posts(scheduled_for);

-- Parsed users
CREATE TABLE IF NOT EXISTS parsed_users (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    group_id INTEGER REFERENCES target_groups(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL,
    username VARCHAR(100),
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    phone VARCHAR(20),
    is_bot BOOLEAN DEFAULT FALSE,
    is_premium BOOLEAN DEFAULT FALSE,
    last_seen TIMESTAMP,
    message_count INTEGER DEFAULT 0,
    activity_score FLOAT DEFAULT 0.0,
    parsed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(project_id, user_id, group_id)
);

CREATE INDEX idx_parsed_users_project ON parsed_users(project_id);
CREATE INDEX idx_parsed_users_group ON parsed_users(group_id);
CREATE INDEX idx_parsed_users_user_id ON parsed_users(user_id);
CREATE INDEX idx_parsed_users_activity ON parsed_users(activity_score);

-- Campaigns (updated with project_id)
CREATE TABLE IF NOT EXISTS campaigns (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    status VARCHAR(20) DEFAULT 'draft',
    target_count INTEGER,
    completed_count INTEGER DEFAULT 0,
    success_count INTEGER DEFAULT 0,
    error_count INTEGER DEFAULT 0,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    config JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_campaigns_project ON campaigns(project_id);
CREATE INDEX idx_campaigns_status ON campaigns(status);
CREATE INDEX idx_campaigns_type ON campaigns(type);

-- Campaign accounts (junction table)
CREATE TABLE IF NOT EXISTS campaign_accounts (
    campaign_id INTEGER REFERENCES campaigns(id) ON DELETE CASCADE,
    account_id INTEGER REFERENCES telegram_accounts(id) ON DELETE CASCADE,
    PRIMARY KEY (campaign_id, account_id)
);

-- Campaign groups (junction table)
CREATE TABLE IF NOT EXISTS campaign_groups (
    campaign_id INTEGER REFERENCES campaigns(id) ON DELETE CASCADE,
    group_id INTEGER REFERENCES target_groups(id) ON DELETE CASCADE,
    PRIMARY KEY (campaign_id, group_id)
);

-- Invite history
CREATE TABLE IF NOT EXISTS invite_history (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    campaign_id INTEGER REFERENCES campaigns(id) ON DELETE SET NULL,
    account_id INTEGER REFERENCES telegram_accounts(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL,
    target_group_id INTEGER REFERENCES target_groups(id) ON DELETE SET NULL,
    status VARCHAR(20) NOT NULL,
    message_sent TEXT,
    error_message TEXT,
    invited_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_invite_history_project ON invite_history(project_id);
CREATE INDEX idx_invite_history_campaign ON invite_history(campaign_id);
CREATE INDEX idx_invite_history_account ON invite_history(account_id);
CREATE INDEX idx_invite_history_status ON invite_history(status);
CREATE INDEX idx_invite_history_date ON invite_history(invited_at);

-- System logs
CREATE TABLE IF NOT EXISTS system_logs (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
    level VARCHAR(20) NOT NULL,
    category VARCHAR(50),
    message TEXT NOT NULL,
    details JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_logs_project ON system_logs(project_id);
CREATE INDEX idx_logs_level ON system_logs(level);
CREATE INDEX idx_logs_category ON system_logs(category);
CREATE INDEX idx_logs_date ON system_logs(created_at);

-- Admin users
CREATE TABLE IF NOT EXISTS admin_users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_login_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    severity VARCHAR(20) DEFAULT 'info',
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notifications_project ON notifications(project_id);
CREATE INDEX idx_notifications_read ON notifications(is_read);
CREATE INDEX idx_notifications_date ON notifications(created_at);

-- Channel content sources (NEW)
CREATE TABLE IF NOT EXISTS channel_content_sources (
    id SERIAL PRIMARY KEY,
    channel_id INTEGER REFERENCES channels(id) ON DELETE CASCADE,
    source_type VARCHAR(50) NOT NULL,
    source_url TEXT,
    api_key TEXT,
    config JSONB,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_content_sources_channel ON channel_content_sources(channel_id);

-- ============================================
-- Functions and Triggers
-- ============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for updated_at
CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON projects
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_accounts_updated_at BEFORE UPDATE ON telegram_accounts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_groups_updated_at BEFORE UPDATE ON target_groups
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_channels_updated_at BEFORE UPDATE ON channels
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_campaigns_updated_at BEFORE UPDATE ON campaigns
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to reset daily invite counts
CREATE OR REPLACE FUNCTION reset_daily_invite_counts()
RETURNS void AS $$
BEGIN
    UPDATE telegram_accounts SET invites_today = 0;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- Views for Analytics
-- ============================================

-- Project statistics view
CREATE OR REPLACE VIEW project_stats AS
SELECT 
    p.id as project_id,
    p.name as project_name,
    COUNT(DISTINCT ta.id) as account_count,
    COUNT(DISTINCT tg.id) as group_count,
    COUNT(DISTINCT c.id) as channel_count,
    COUNT(DISTINCT cam.id) as campaign_count,
    SUM(CASE WHEN ih.invited_at >= CURRENT_DATE THEN 1 ELSE 0 END) as invites_today,
    SUM(CASE WHEN pu.parsed_at >= CURRENT_DATE THEN 1 ELSE 0 END) as parsed_today
FROM projects p
LEFT JOIN telegram_accounts ta ON p.id = ta.project_id
LEFT JOIN target_groups tg ON p.id = tg.project_id
LEFT JOIN channels c ON p.id = c.project_id
LEFT JOIN campaigns cam ON p.id = cam.project_id
LEFT JOIN invite_history ih ON p.id = ih.project_id
LEFT JOIN parsed_users pu ON p.id = pu.project_id
WHERE p.is_active = TRUE
GROUP BY p.id, p.name;

-- Campaign performance view
CREATE OR REPLACE VIEW campaign_performance AS
SELECT 
    c.id as campaign_id,
    c.name as campaign_name,
    p.name as project_name,
    c.type,
    c.status,
    c.target_count,
    c.completed_count,
    c.success_count,
    c.error_count,
    CASE 
        WHEN c.target_count > 0 THEN 
            ROUND((c.completed_count::FLOAT / c.target_count * 100), 2)
        ELSE 0 
    END as progress_percent,
    CASE 
        WHEN c.completed_count > 0 THEN 
            ROUND((c.success_count::FLOAT / c.completed_count * 100), 2)
        ELSE 0 
    END as success_rate,
    c.started_at,
    c.completed_at
FROM campaigns c
JOIN projects p ON c.project_id = p.id;

-- Channel performance view
CREATE OR REPLACE VIEW channel_performance AS
SELECT 
    ch.id as channel_id,
    ch.title as channel_name,
    ch.username,
    p.name as project_name,
    ch.subscriber_count,
    ch.post_count,
    ch.avg_views_per_post,
    ch.auto_posting_enabled,
    ch.status,
    COUNT(cp.id) as total_posts,
    SUM(cp.views) as total_views,
    SUM(cp.reactions) as total_reactions,
    CASE 
        WHEN COUNT(cp.id) > 0 THEN 
            ROUND(AVG(cp.views), 0)
        ELSE 0 
    END as avg_views,
    ch.last_post_at,
    ch.next_post_at
FROM channels ch
JOIN projects p ON ch.project_id = p.id
LEFT JOIN channel_posts cp ON ch.id = cp.channel_id AND cp.status = 'published'
GROUP BY ch.id, ch.title, ch.username, p.name, ch.subscriber_count, 
         ch.post_count, ch.avg_views_per_post, ch.auto_posting_enabled, 
         ch.status, ch.last_post_at, ch.next_post_at;

-- ============================================
-- Sample Data for Demo
-- ============================================

-- Insert demo projects
INSERT INTO projects (name, description, color) VALUES
('Крипто-проект', 'Парсинг и инвайтинг в крипто-сообщества', '#667eea'),
('NFT-проект', 'Продвижение NFT коллекций', '#f5576c'),
('Стартап-проект', 'Поиск инвесторов и партнёров', '#00f2fe')
ON CONFLICT DO NOTHING;

-- Insert demo admin
INSERT INTO admin_users (username, email, password_hash) VALUES
('admin', 'admin@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5NU7TUQ9aqQ/i')
ON CONFLICT (username) DO NOTHING;

COMMENT ON DATABASE telegram_automation IS 'Telegram Automation Pro v2.0 - Multi-project automation system';
