-- ============================================
-- Telegram Automation Pro - Database Schema
-- PostgreSQL 15+
-- ============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- USERS TABLE (Admin users for web panel)
-- ============================================
CREATE TABLE IF NOT EXISTS admin_users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    last_login TIMESTAMP
);

-- ============================================
-- PROXIES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS proxies (
    id SERIAL PRIMARY KEY,
    type VARCHAR(20) NOT NULL CHECK (type IN ('http', 'socks4', 'socks5')),
    host VARCHAR(255) NOT NULL,
    port INTEGER NOT NULL CHECK (port > 0 AND port < 65536),
    username VARCHAR(100),
    password VARCHAR(100),
    country VARCHAR(10),
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'banned', 'slow', 'inactive')),
    last_checked TIMESTAMP,
    response_time_ms INTEGER,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_proxies_status ON proxies(status);
CREATE INDEX idx_proxies_country ON proxies(country);

-- ============================================
-- TELEGRAM ACCOUNTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS telegram_accounts (
    id SERIAL PRIMARY KEY,
    phone VARCHAR(20) UNIQUE NOT NULL,
    api_id INTEGER NOT NULL,
    api_hash VARCHAR(100) NOT NULL,
    session_file TEXT NOT NULL,
    proxy_id INTEGER REFERENCES proxies(id) ON DELETE SET NULL,
    
    -- Account metadata
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    username VARCHAR(100),
    
    -- Role and status
    role VARCHAR(20) NOT NULL DEFAULT 'parser' CHECK (role IN ('parser', 'inviter', 'communicator', 'universal')),
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'cooling', 'banned', 'inactive', 'warmup')),
    
    -- Limits and counters
    daily_invite_count INTEGER DEFAULT 0,
    total_invites INTEGER DEFAULT 0,
    daily_parse_count INTEGER DEFAULT 0,
    total_parses INTEGER DEFAULT 0,
    
    -- Warmup tracking
    warmup_started TIMESTAMP,
    warmup_completed BOOLEAN DEFAULT FALSE,
    warmup_stage INTEGER DEFAULT 0,
    
    -- Activity tracking
    last_activity TIMESTAMP,
    last_invite_at TIMESTAMP,
    last_parse_at TIMESTAMP,
    
    -- Device fingerprint
    device_model VARCHAR(100),
    system_version VARCHAR(50),
    app_version VARCHAR(50),
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_accounts_role_status ON telegram_accounts(role, status);
CREATE INDEX idx_accounts_phone ON telegram_accounts(phone);
CREATE INDEX idx_accounts_last_activity ON telegram_accounts(last_activity);

-- ============================================
-- TARGET GROUPS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS target_groups (
    id SERIAL PRIMARY KEY,
    telegram_id BIGINT UNIQUE NOT NULL,
    title VARCHAR(255),
    username VARCHAR(100),
    description TEXT,
    
    -- Group metrics
    member_count INTEGER DEFAULT 0,
    online_count INTEGER DEFAULT 0,
    messages_per_day FLOAT DEFAULT 0,
    bot_percentage FLOAT DEFAULT 0,
    
    -- Scoring
    relevance_score FLOAT DEFAULT 0.5 CHECK (relevance_score >= 0 AND relevance_score <= 1),
    quality_score FLOAT DEFAULT 0.5 CHECK (quality_score >= 0 AND quality_score <= 1),
    
    -- Classification
    category VARCHAR(100),
    tags TEXT[],
    language VARCHAR(10),
    
    -- Parsing history
    last_parsed TIMESTAMP,
    parse_count INTEGER DEFAULT 0,
    total_users_parsed INTEGER DEFAULT 0,
    
    -- Status
    is_active BOOLEAN DEFAULT TRUE,
    is_public BOOLEAN DEFAULT TRUE,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_target_groups_telegram_id ON target_groups(telegram_id);
CREATE INDEX idx_target_groups_relevance ON target_groups(relevance_score DESC);
CREATE INDEX idx_target_groups_active ON target_groups(is_active);
CREATE INDEX idx_target_groups_category ON target_groups(category);

-- ============================================
-- PARSED USERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS parsed_users (
    id SERIAL PRIMARY KEY,
    telegram_id BIGINT UNIQUE NOT NULL,
    username VARCHAR(100),
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    phone VARCHAR(20),
    bio TEXT,
    
    -- Source tracking
    source_group_id INTEGER REFERENCES target_groups(id) ON DELETE SET NULL,
    discovered_by_account_id INTEGER REFERENCES telegram_accounts(id) ON DELETE SET NULL,
    
    -- User analysis
    activity_score FLOAT DEFAULT 0.5 CHECK (activity_score >= 0 AND activity_score <= 1),
    engagement_score FLOAT DEFAULT 0.5,
    sentiment VARCHAR(50) DEFAULT 'neutral' CHECK (sentiment IN ('positive', 'neutral', 'negative')),
    interests TEXT[],
    language VARCHAR(10),
    
    -- User flags
    is_bot BOOLEAN DEFAULT FALSE,
    is_premium BOOLEAN DEFAULT FALSE,
    is_verified BOOLEAN DEFAULT FALSE,
    is_scam BOOLEAN DEFAULT FALSE,
    is_fake BOOLEAN DEFAULT FALSE,
    
    -- Privacy
    is_private BOOLEAN DEFAULT FALSE,
    has_photo BOOLEAN DEFAULT TRUE,
    
    -- Invite tracking
    is_invited BOOLEAN DEFAULT FALSE,
    invited_at TIMESTAMP,
    invite_accepted BOOLEAN DEFAULT FALSE,
    invite_rejected BOOLEAN DEFAULT FALSE,
    
    -- Ban tracking
    is_banned BOOLEAN DEFAULT FALSE,
    ban_reason TEXT,
    
    -- Activity tracking
    last_seen TIMESTAMP,
    last_message_at TIMESTAMP,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_parsed_users_telegram_id ON parsed_users(telegram_id);
CREATE INDEX idx_parsed_users_username ON parsed_users(username);
CREATE INDEX idx_parsed_users_invited ON parsed_users(is_invited);
CREATE INDEX idx_parsed_users_activity_score ON parsed_users(activity_score DESC);
CREATE INDEX idx_parsed_users_source_group ON parsed_users(source_group_id);
CREATE INDEX idx_parsed_users_is_bot ON parsed_users(is_bot);

-- ============================================
-- INVITE LOGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS invite_logs (
    id SERIAL PRIMARY KEY,
    account_id INTEGER REFERENCES telegram_accounts(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES parsed_users(id) ON DELETE CASCADE,
    target_channel VARCHAR(100),
    
    -- Invite details
    invite_message TEXT,
    status VARCHAR(50) NOT NULL CHECK (status IN (
        'success', 'pending', 'failed',
        'flood_wait', 'privacy_error', 'user_banned',
        'spam_ban', 'peer_flood', 'channel_private',
        'user_not_mutual', 'user_channels_too_much',
        'bot_groups_blocked', 'user_privacy_restricted'
    )),
    
    -- Error tracking
    error_code VARCHAR(50),
    error_message TEXT,
    flood_wait_seconds INTEGER,
    
    -- Timing
    response_time_ms INTEGER,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_invite_logs_account ON invite_logs(account_id);
CREATE INDEX idx_invite_logs_user ON invite_logs(user_id);
CREATE INDEX idx_invite_logs_status ON invite_logs(status);
CREATE INDEX idx_invite_logs_created ON invite_logs(created_at DESC);

-- ============================================
-- PARSING LOGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS parsing_logs (
    id SERIAL PRIMARY KEY,
    account_id INTEGER REFERENCES telegram_accounts(id) ON DELETE CASCADE,
    group_id INTEGER REFERENCES target_groups(id) ON DELETE CASCADE,
    
    -- Parsing results
    users_found INTEGER DEFAULT 0,
    users_saved INTEGER DEFAULT 0,
    users_filtered INTEGER DEFAULT 0,
    
    -- Performance
    duration_seconds INTEGER,
    status VARCHAR(50) NOT NULL CHECK (status IN ('success', 'partial', 'failed', 'interrupted')),
    
    -- Error tracking
    error_type VARCHAR(100),
    error_message TEXT,
    
    -- Timestamps
    started_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP
);

CREATE INDEX idx_parsing_logs_account ON parsing_logs(account_id);
CREATE INDEX idx_parsing_logs_group ON parsing_logs(group_id);
CREATE INDEX idx_parsing_logs_status ON parsing_logs(status);
CREATE INDEX idx_parsing_logs_started ON parsing_logs(started_at DESC);

-- ============================================
-- CAMPAIGNS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS campaigns (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL CHECK (type IN ('parsing', 'inviting', 'combined')),
    
    -- Campaign configuration
    target_groups INTEGER[],
    target_channel VARCHAR(100),
    invite_message_template TEXT,
    
    -- Filters
    min_activity_score FLOAT DEFAULT 0.3,
    max_users INTEGER,
    exclude_bots BOOLEAN DEFAULT TRUE,
    exclude_private BOOLEAN DEFAULT TRUE,
    
    -- Scheduling
    scheduled_at TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    
    -- Status
    status VARCHAR(50) DEFAULT 'draft' CHECK (status IN (
        'draft', 'scheduled', 'running', 'paused',
        'completed', 'failed', 'cancelled'
    )),
    
    -- Progress tracking
    total_users_target INTEGER DEFAULT 0,
    users_processed INTEGER DEFAULT 0,
    users_invited INTEGER DEFAULT 0,
    users_failed INTEGER DEFAULT 0,
    
    -- Created by
    created_by_user_id INTEGER REFERENCES admin_users(id),
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_campaigns_status ON campaigns(status);
CREATE INDEX idx_campaigns_type ON campaigns(type);
CREATE INDEX idx_campaigns_created ON campaigns(created_at DESC);

-- ============================================
-- SYSTEM LOGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS system_logs (
    id SERIAL PRIMARY KEY,
    level VARCHAR(20) NOT NULL CHECK (level IN ('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL')),
    module VARCHAR(100),
    message TEXT NOT NULL,
    details JSONB,
    
    -- Context
    account_id INTEGER REFERENCES telegram_accounts(id) ON DELETE SET NULL,
    user_id INTEGER REFERENCES admin_users(id) ON DELETE SET NULL,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_system_logs_level ON system_logs(level);
CREATE INDEX idx_system_logs_module ON system_logs(module);
CREATE INDEX idx_system_logs_created ON system_logs(created_at DESC);

-- ============================================
-- NOTIFICATIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS notifications (
    id SERIAL PRIMARY KEY,
    level VARCHAR(20) NOT NULL CHECK (level IN ('INFO', 'WARNING', 'CRITICAL')),
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    
    -- Notification details
    type VARCHAR(50) CHECK (type IN ('account_ban', 'flood_wait', 'campaign_complete', 'error', 'system')),
    related_account_id INTEGER REFERENCES telegram_accounts(id) ON DELETE SET NULL,
    related_campaign_id INTEGER REFERENCES campaigns(id) ON DELETE SET NULL,
    
    -- Status
    is_read BOOLEAN DEFAULT FALSE,
    is_sent_telegram BOOLEAN DEFAULT FALSE,
    sent_at TIMESTAMP,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_notifications_level ON notifications(level);
CREATE INDEX idx_notifications_read ON notifications(is_read);
CREATE INDEX idx_notifications_created ON notifications(created_at DESC);

-- ============================================
-- SETTINGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS settings (
    id SERIAL PRIMARY KEY,
    key VARCHAR(100) UNIQUE NOT NULL,
    value TEXT,
    value_type VARCHAR(20) DEFAULT 'string' CHECK (value_type IN ('string', 'integer', 'float', 'boolean', 'json')),
    description TEXT,
    is_public BOOLEAN DEFAULT FALSE,
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Insert default settings
INSERT INTO settings (key, value, value_type, description, is_public) VALUES
    ('daily_invite_limit_per_account', '30', 'integer', 'Maximum invites per account per day', true),
    ('min_delay_between_invites', '60', 'integer', 'Minimum seconds between invites', true),
    ('max_delay_between_invites', '300', 'integer', 'Maximum seconds between invites', true),
    ('parsing_batch_size', '100', 'integer', 'Number of users to fetch per batch', true),
    ('max_parsing_limit', '5000', 'integer', 'Maximum users to parse from one group', true),
    ('automation_mode', 'semi', 'string', 'Automation mode: full, semi, manual', true),
    ('enable_llm_generation', 'true', 'boolean', 'Enable LLM for message generation', true),
    ('llm_temperature', '0.7', 'float', 'LLM temperature for generation', true),
    ('enable_notifications', 'true', 'boolean', 'Enable Telegram notifications', true),
    ('warmup_duration_days', '14', 'integer', 'Account warmup period in days', true)
ON CONFLICT (key) DO NOTHING;

-- ============================================
-- ANALYTICS VIEWS
-- ============================================

-- Daily statistics view
CREATE OR REPLACE VIEW v_daily_stats AS
SELECT 
    DATE(created_at) as date,
    COUNT(*) FILTER (WHERE status = 'success') as successful_invites,
    COUNT(*) FILTER (WHERE status = 'failed') as failed_invites,
    COUNT(*) FILTER (WHERE status = 'flood_wait') as flood_waits,
    COUNT(*) FILTER (WHERE status = 'spam_ban') as spam_bans,
    ROUND(AVG(response_time_ms)) as avg_response_time_ms
FROM invite_logs
WHERE created_at > CURRENT_DATE - INTERVAL '30 days'
GROUP BY DATE(created_at)
ORDER BY date DESC;

-- Account performance view
CREATE OR REPLACE VIEW v_account_performance AS
SELECT 
    ta.id,
    ta.phone,
    ta.role,
    ta.status,
    ta.daily_invite_count,
    ta.total_invites,
    COUNT(il.id) FILTER (WHERE il.status = 'success') as successful_invites_today,
    COUNT(il.id) FILTER (WHERE il.status = 'spam_ban') as spam_bans,
    ta.last_activity
FROM telegram_accounts ta
LEFT JOIN invite_logs il ON il.account_id = ta.id AND DATE(il.created_at) = CURRENT_DATE
GROUP BY ta.id
ORDER BY ta.total_invites DESC;

-- Top groups by quality
CREATE OR REPLACE VIEW v_top_groups AS
SELECT 
    tg.id,
    tg.title,
    tg.username,
    tg.member_count,
    tg.relevance_score,
    tg.quality_score,
    COUNT(pu.id) as users_parsed,
    COUNT(pu.id) FILTER (WHERE pu.is_invited = true) as users_invited
FROM target_groups tg
LEFT JOIN parsed_users pu ON pu.source_group_id = tg.id
WHERE tg.is_active = true
GROUP BY tg.id
ORDER BY tg.relevance_score DESC, tg.quality_score DESC
LIMIT 100;

-- ============================================
-- FUNCTIONS
-- ============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for updated_at
CREATE TRIGGER update_telegram_accounts_updated_at BEFORE UPDATE ON telegram_accounts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_target_groups_updated_at BEFORE UPDATE ON target_groups
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_parsed_users_updated_at BEFORE UPDATE ON parsed_users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_campaigns_updated_at BEFORE UPDATE ON campaigns
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to reset daily counters
CREATE OR REPLACE FUNCTION reset_daily_counters()
RETURNS void AS $$
BEGIN
    UPDATE telegram_accounts 
    SET daily_invite_count = 0, daily_parse_count = 0
    WHERE status IN ('active', 'cooling');
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- INITIAL ADMIN USER
-- ============================================
-- Password: admin123 (bcrypt hashed)
INSERT INTO admin_users (username, password_hash, email, is_active)
VALUES ('admin', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5NU7667l.aDRm', 'admin@localhost', true)
ON CONFLICT (username) DO NOTHING;
