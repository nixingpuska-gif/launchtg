#!/usr/bin/env python3
"""
Telegram Automation Pro - Python Installer
Version: 3.0.0
Platform: Windows/Linux/macOS
"""

import subprocess
import sys
import os
from pathlib import Path

def print_header():
    print("=" * 60)
    print("  Telegram Automation Pro - Installation")
    print("  Version: 3.0.0")
    print("=" * 60)
    print()

def check_python():
    """Check Python version"""
    print("[1/6] Checking Python version...")
    version = sys.version_info
    
    if version.major < 3 or (version.major == 3 and version.minor < 11):
        print(f"[ERROR] Python 3.11+ required")
        print(f"[ERROR] Found: Python {version.major}.{version.minor}.{version.micro}")
        print()
        print("Download Python 3.11+:")
        print("https://www.python.org/downloads/")
        sys.exit(1)
    
    print(f"[OK] Python {version.major}.{version.minor}.{version.micro} found")
    print()

def create_venv():
    """Create virtual environment"""
    print("[2/6] Creating virtual environment...")
    
    venv_path = Path("venv")
    if venv_path.exists():
        print("[WARNING] Virtual environment already exists")
        response = input("Recreate? (y/n): ").lower()
        if response == 'y':
            import shutil
            shutil.rmtree(venv_path)
            print("[INFO] Removed old environment")
        else:
            print("[INFO] Using existing environment")
            print()
            return
    
    try:
        subprocess.run([sys.executable, "-m", "venv", "venv"], check=True)
        print("[OK] Virtual environment created")
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] Failed to create virtual environment: {e}")
        sys.exit(1)
    print()

def get_pip_path():
    """Get pip executable path"""
    if sys.platform == "win32":
        return Path("venv/Scripts/pip.exe")
    else:
        return Path("venv/bin/pip")

def get_python_path():
    """Get python executable path in venv"""
    if sys.platform == "win32":
        return Path("venv/Scripts/python.exe")
    else:
        return Path("venv/bin/python")

def install_dependencies():
    """Install Python dependencies"""
    print("[3/6] Installing dependencies...")
    print("[INFO] This may take 5-10 minutes...")
    print()
    
    pip_path = get_pip_path()
    
    if not pip_path.exists():
        print(f"[ERROR] pip not found at {pip_path}")
        sys.exit(1)
    
    # Upgrade pip first
    print("Upgrading pip...")
    subprocess.run([str(pip_path), "install", "--upgrade", "pip"], 
                   check=True, stdout=subprocess.DEVNULL)
    
    # Install from requirements.txt
    requirements_file = Path("requirements.txt")
    if requirements_file.exists():
        print("Installing from requirements.txt...")
        subprocess.run([str(pip_path), "install", "-r", "requirements.txt"], 
                       check=True)
    else:
        # Install essential packages manually
        print("Installing essential packages...")
        packages = [
            "telethon",
            "pyrogram",
            "flask",
            "sqlalchemy",
            "psycopg2-binary",
            "python-dotenv",
            "requests",
            "beautifulsoup4",
            "scikit-learn",
            "pandas",
            "numpy"
        ]
        for package in packages:
            print(f"Installing {package}...")
            subprocess.run([str(pip_path), "install", package], 
                          check=True, stdout=subprocess.DEVNULL)
    
    print("[OK] All dependencies installed")
    print()

def create_directories():
    """Create necessary directories"""
    print("[4/6] Creating directories...")
    
    directories = ["logs", "sessions", "data", "exports", "config"]
    for dir_name in directories:
        dir_path = Path(dir_name)
        dir_path.mkdir(exist_ok=True)
        print(f"[OK] {dir_name}/")
    
    print()

def create_config_templates():
    """Create configuration file templates"""
    print("[5/6] Creating configuration templates...")
    
    config_dir = Path("config")
    config_dir.mkdir(exist_ok=True)
    
    # database.env
    db_config = config_dir / "database.env"
    if not db_config.exists():
        with open(db_config, "w") as f:
            f.write("# Database Configuration\n")
            f.write("DATABASE_URL=postgresql://postgres:password@localhost:5432/telegram_automation\n")
            f.write("\n")
            f.write("# Replace 'password' with your PostgreSQL password\n")
        print("[OK] config/database.env created")
        print("[IMPORTANT] Edit this file and set correct database password")
    else:
        print("[INFO] config/database.env already exists")
    
    # telegram.env
    tg_config = config_dir / "telegram.env"
    if not tg_config.exists():
        with open(tg_config, "w") as f:
            f.write("# Telegram API Configuration\n")
            f.write("TELEGRAM_API_ID=your_api_id\n")
            f.write("TELEGRAM_API_HASH=your_api_hash\n")
            f.write("TELEGRAM_PHONE=+79991234567\n")
            f.write("\n")
            f.write("# Get API credentials at https://my.telegram.org\n")
        print("[OK] config/telegram.env created")
        print("[IMPORTANT] Edit this file and set your Telegram API credentials")
    else:
        print("[INFO] config/telegram.env already exists")
    
    # ai.env
    ai_config = config_dir / "ai.env"
    if not ai_config.exists():
        with open(ai_config, "w") as f:
            f.write("# AI Configuration\n")
            f.write("OLLAMA_HOST=http://localhost:11434\n")
            f.write("OLLAMA_MODEL=llama3.1:8b\n")
        print("[OK] config/ai.env created")
    else:
        print("[INFO] config/ai.env already exists")
    
    print()

def print_next_steps():
    """Print next steps"""
    print("[6/6] Installation completed!")
    print()
    print("=" * 60)
    print("  INSTALLATION COMPLETED!")
    print("=" * 60)
    print()
    print("NEXT STEPS:")
    print()
    print("1. Edit configuration files in 'config' folder:")
    print("   - config/database.env (set PostgreSQL password)")
    print("   - config/telegram.env (set Telegram API credentials)")
    print()
    print("2. Initialize database:")
    if sys.platform == "win32":
        print("   venv\\Scripts\\python.exe scripts\\init_database_windows.py")
    else:
        print("   venv/bin/python scripts/init_database_windows.py")
    print()
    print("3. Run application:")
    if sys.platform == "win32":
        print("   venv\\Scripts\\python.exe web\\app.py")
    else:
        print("   venv/bin/python web/app.py")
    print()
    print("4. Open in browser:")
    print("   http://localhost:3000")
    print()
    print("=" * 60)
    print()
    print("Full documentation: WINDOWS_INSTALLATION_GUIDE.md")
    print("Support: https://help.manus.im")
    print()

def main():
    """Main installation function"""
    try:
        print_header()
        check_python()
        create_venv()
        install_dependencies()
        create_directories()
        create_config_templates()
        print_next_steps()
        
    except KeyboardInterrupt:
        print("\n\n[WARNING] Installation interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] Installation failed: {e}")
        print("\nFor help, see:")
        print("- TROUBLESHOOTING_GUIDE.md")
        print("- https://help.manus.im")
        sys.exit(1)

if __name__ == "__main__":
    main()
