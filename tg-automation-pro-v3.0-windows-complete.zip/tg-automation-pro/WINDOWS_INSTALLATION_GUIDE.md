# 🪟 Установка Telegram Automation Pro на Windows

## 📋 Содержание

1. [Системные требования](#системные-требования)
2. [Подготовка системы](#подготовка-системы)
3. [Установка зависимостей](#установка-зависимостей)
4. [Установка Telegram Automation Pro](#установка-telegram-automation-pro)
5. [Настройка](#настройка)
6. [Запуск](#запуск)
7. [Решение проблем](#решение-проблем)

---

## 🖥️ Системные требования

### Минимальные:
- **ОС:** Windows 10/11 (64-bit)
- **Процессор:** Intel Core i3 / AMD Ryzen 3
- **ОЗУ:** 4 GB
- **Диск:** 10 GB свободного места
- **Интернет:** Стабильное подключение

### Рекомендуемые:
- **ОС:** Windows 11 (64-bit)
- **Процессор:** Intel Core i5 / AMD Ryzen 5
- **ОЗУ:** 8 GB+
- **Диск:** 20 GB+ SSD
- **Интернет:** Высокоскоростное подключение

---

## 🔧 Подготовка системы

### Шаг 1: Включение режима разработчика (опционально)

1. Откройте **Параметры Windows** (Win + I)
2. Перейдите в **Конфиденциальность и безопасность** → **Для разработчиков**
3. Включите **Режим разработчика**

### Шаг 2: Отключение антивируса (временно)

⚠️ **Важно:** Некоторые антивирусы могут блокировать установку. Временно отключите Windows Defender или другой антивирус.

1. Откройте **Безопасность Windows**
2. Перейдите в **Защита от вирусов и угроз**
3. Управление параметрами → Отключите **Защиту в реальном времени** (временно)

---

## 📦 Установка зависимостей

### Шаг 1: Установка Python 3.11

#### Вариант A: Через официальный сайт (рекомендуется)

1. Скачайте Python 3.11.x с официального сайта:
   ```
   https://www.python.org/downloads/windows/
   ```

2. Запустите установщик `python-3.11.x-amd64.exe`

3. ✅ **ВАЖНО:** Поставьте галочку **"Add Python to PATH"**

4. Выберите **"Customize installation"**

5. Убедитесь, что выбраны:
   - ✅ pip
   - ✅ py launcher
   - ✅ for all users (install for all users)

6. Нажмите **Install**

7. После установки откройте **Command Prompt** (cmd) и проверьте:
   ```cmd
   python --version
   ```
   Должно вывести: `Python 3.11.x`

   ```cmd
   pip --version
   ```
   Должно вывести версию pip

#### Вариант B: Через Microsoft Store

1. Откройте **Microsoft Store**
2. Найдите **"Python 3.11"**
3. Нажмите **Установить**

### Шаг 2: Установка Git

1. Скачайте Git для Windows:
   ```
   https://git-scm.com/download/win
   ```

2. Запустите установщик `Git-x.xx.x-64-bit.exe`

3. Используйте настройки по умолчанию (просто нажимайте Next)

4. После установки откройте **Command Prompt** и проверьте:
   ```cmd
   git --version
   ```

### Шаг 3: Установка PostgreSQL

#### Вариант A: Локальная установка

1. Скачайте PostgreSQL 15.x:
   ```
   https://www.postgresql.org/download/windows/
   ```

2. Запустите установщик

3. Запомните пароль для пользователя `postgres`

4. Порт по умолчанию: `5432`

5. После установки проверьте в **Services** (Win + R → `services.msc`):
   - Служба **postgresql-x64-15** должна быть запущена

#### Вариант B: Использование Supabase (облачная БД)

Если не хотите устанавливать PostgreSQL локально:

1. Зарегистрируйтесь на https://supabase.com (бесплатно)
2. Создайте новый проект
3. Скопируйте Connection String (будет нужен позже)

### Шаг 4: Установка Ollama (для AI)

1. Скачайте Ollama для Windows:
   ```
   https://ollama.ai/download/windows
   ```

2. Запустите установщик `OllamaSetup.exe`

3. После установки откройте **Command Prompt** и скачайте модель:
   ```cmd
   ollama pull llama3.1:8b
   ```
   ⏱️ Это займёт 10-15 минут (размер ~4.7 GB)

4. Проверьте, что Ollama работает:
   ```cmd
   ollama list
   ```
   Должна появиться модель `llama3.1:8b`

---

## 🚀 Установка Telegram Automation Pro

### Шаг 1: Скачивание архива

У вас уже должен быть файл:
```
tg-automation-pro-v3.0-final-windows.zip
```

Если нет, скачайте его из демо-панели или с сервера.

### Шаг 2: Распаковка

1. Создайте папку для проекта:
   ```
   C:\TelegramAutomation
   ```

2. Распакуйте `tg-automation-pro-v3.0-final-windows.zip` в эту папку

3. Структура должна быть:
   ```
   C:\TelegramAutomation\
   ├── services\
   ├── web\
   ├── config\
   ├── requirements.txt
   ├── install.bat
   ├── run.bat
   └── README.md
   ```

### Шаг 3: Установка Python-зависимостей

1. Откройте **Command Prompt** от имени администратора:
   - Нажмите Win + X
   - Выберите **"Терминал (Администратор)"** или **"Command Prompt (Admin)"**

2. Перейдите в папку проекта:
   ```cmd
   cd C:\TelegramAutomation
   ```

3. Запустите установочный скрипт:
   ```cmd
   install.bat
   ```

   Скрипт автоматически:
   - Создаст виртуальное окружение
   - Установит все зависимости из `requirements.txt`
   - Проверит подключение к БД

4. Дождитесь завершения (5-10 минут)

---

## ⚙️ Настройка

### Шаг 1: Настройка базы данных

Откройте файл `config/database.env`:

```env
# Для локальной PostgreSQL:
DATABASE_URL=postgresql://postgres:ВАШ_ПАРОЛЬ@localhost:5432/telegram_automation

# Или для Supabase:
DATABASE_URL=postgresql://postgres:[PASSWORD]@[HOST]:[PORT]/postgres
```

Замените:
- `ВАШ_ПАРОЛЬ` - пароль, который вы указали при установке PostgreSQL
- Или вставьте Connection String из Supabase

### Шаг 2: Настройка Telegram API

1. Получите API credentials:
   - Перейдите на https://my.telegram.org
   - Войдите с вашим номером телефона
   - Перейдите в **API development tools**
   - Создайте новое приложение
   - Скопируйте **api_id** и **api_hash**

2. Откройте файл `config/telegram.env`:

```env
TELEGRAM_API_ID=ваш_api_id
TELEGRAM_API_HASH=ваш_api_hash
TELEGRAM_PHONE=+79991234567
```

Замените на ваши данные.

### Шаг 3: Настройка Ollama

Откройте файл `config/ai.env`:

```env
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=llama3.1:8b
```

Обычно не требует изменений.

### Шаг 4: Инициализация базы данных

Запустите скрипт создания таблиц:

```cmd
cd C:\TelegramAutomation
python scripts\init_database.py
```

Должно вывести:
```
✅ База данных инициализирована
✅ Создано 20 таблиц
```

---

## 🎯 Запуск

### Вариант 1: Через BAT-файл (простой способ)

1. Откройте **Command Prompt**

2. Перейдите в папку проекта:
   ```cmd
   cd C:\TelegramAutomation
   ```

3. Запустите:
   ```cmd
   run.bat
   ```

4. Откройте браузер и перейдите на:
   ```
   http://localhost:3000
   ```

### Вариант 2: Ручной запуск (для продвинутых)

1. Откройте **Command Prompt**

2. Активируйте виртуальное окружение:
   ```cmd
   cd C:\TelegramAutomation
   venv\Scripts\activate
   ```

3. Запустите веб-сервер:
   ```cmd
   python web\app.py
   ```

4. В другом окне Command Prompt запустите фоновые задачи:
   ```cmd
   cd C:\TelegramAutomation
   venv\Scripts\activate
   python services\task_scheduler.py
   ```

5. Откройте браузер:
   ```
   http://localhost:3000
   ```

### Вариант 3: Через Docker (если установлен)

Если у вас установлен Docker Desktop:

```cmd
cd C:\TelegramAutomation
docker-compose up -d
```

---

## 🔐 Первый запуск

### Шаг 1: Авторизация Telegram-аккаунта

1. Откройте веб-панель: http://localhost:3000

2. Перейдите в **"Аккаунты"** → **"Добавить аккаунт"**

3. Введите номер телефона (с кодом страны, например +79991234567)

4. Нажмите **"Отправить код"**

5. Введите код из Telegram

6. Если включена 2FA - введите пароль

7. ✅ Аккаунт добавлен!

### Шаг 2: Тестовый запуск

1. Перейдите в **"Competitor Intelligence"**

2. Введите ключевые слова (например: `криптовалюты, трейдинг`)

3. Нажмите **"Найти конкурентов"**

4. Дождитесь результатов (30-60 секунд)

5. ✅ Если появились конкуренты - всё работает!

---

## 🛠️ Решение проблем

### Проблема 1: "Python не найден"

**Ошибка:**
```
'python' is not recognized as an internal or external command
```

**Решение:**
1. Переустановите Python с галочкой **"Add Python to PATH"**
2. Или добавьте Python в PATH вручную:
   - Win + X → Система → Дополнительные параметры системы
   - Переменные среды → Path → Добавить:
     ```
     C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\AppData\Local\Programs\Python\Python311
     C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\AppData\Local\Programs\Python\Python311\Scripts
     ```

### Проблема 2: "Не удается подключиться к БД"

**Ошибка:**
```
psycopg2.OperationalError: could not connect to server
```

**Решение:**
1. Проверьте, что PostgreSQL запущен:
   - Win + R → `services.msc`
   - Найдите `postgresql-x64-15`
   - Статус должен быть "Запущено"
   - Если нет - нажмите "Запустить"

2. Проверьте пароль в `config/database.env`

3. Попробуйте подключиться через pgAdmin:
   - Откройте pgAdmin 4
   - Создайте новое подключение
   - Host: localhost, Port: 5432
   - User: postgres, Password: ваш_пароль

### Проблема 3: "Ollama не отвечает"

**Ошибка:**
```
ConnectionError: Could not connect to Ollama
```

**Решение:**
1. Проверьте, что Ollama запущен:
   ```cmd
   ollama list
   ```

2. Если не запущен, запустите вручную:
   ```cmd
   ollama serve
   ```

3. Проверьте, что модель скачана:
   ```cmd
   ollama pull llama3.1:8b
   ```

### Проблема 4: "Порт 3000 уже занят"

**Ошибка:**
```
OSError: [WinError 10048] Only one usage of each socket address
```

**Решение:**
1. Найдите процесс, занимающий порт:
   ```cmd
   netstat -ano | findstr :3000
   ```

2. Убейте процесс:
   ```cmd
   taskkill /PID [номер_процесса] /F
   ```

3. Или измените порт в `web/app.py`:
   ```python
   app.run(host='0.0.0.0', port=3001)  # Вместо 3000
   ```

### Проблема 5: "Telegram API ошибка"

**Ошибка:**
```
AuthKeyUnregisteredError / FloodWaitError
```

**Решение:**
1. **AuthKeyUnregisteredError:**
   - Удалите файл сессии: `sessions/ваш_номер.session`
   - Авторизуйтесь заново

2. **FloodWaitError:**
   - Telegram временно ограничил аккаунт
   - Подождите указанное время (обычно 1-24 часа)
   - Используйте другой аккаунт

### Проблема 6: "Антивирус блокирует"

**Ошибка:**
Файлы удаляются или не запускаются

**Решение:**
1. Добавьте папку в исключения Windows Defender:
   - Безопасность Windows → Защита от вирусов и угроз
   - Управление параметрами → Исключения
   - Добавить исключение → Папка
   - Выберите `C:\TelegramAutomation`

2. Или временно отключите антивирус

### Проблема 7: "Медленная работа"

**Решение:**
1. Увеличьте RAM для Python:
   - Закройте другие приложения
   - Используйте 64-bit версию Python

2. Используйте SSD вместо HDD

3. Уменьшите количество одновременных задач в настройках

### Проблема 8: "Не устанавливаются зависимости"

**Ошибка:**
```
ERROR: Could not install packages
```

**Решение:**
1. Обновите pip:
   ```cmd
   python -m pip install --upgrade pip
   ```

2. Установите зависимости по одной:
   ```cmd
   pip install telethon
   pip install pyrogram
   pip install flask
   pip install psycopg2-binary
   pip install sqlalchemy
   ```

3. Если не помогает, используйте conda:
   ```cmd
   conda install -c conda-forge telethon pyrogram flask
   ```

---

## 📞 Поддержка

### Если проблема не решена:

1. **Проверьте логи:**
   ```
   C:\TelegramAutomation\logs\app.log
   ```

2. **Соберите информацию:**
   - Версия Windows
   - Версия Python
   - Текст ошибки
   - Скриншот

3. **Обратитесь в поддержку:**
   - https://help.manus.im
   - Telegram: @your_support_channel

---

## ✅ Чек-лист успешной установки

- [ ] Python 3.11 установлен и в PATH
- [ ] Git установлен
- [ ] PostgreSQL установлен и запущен
- [ ] Ollama установлен и модель скачана
- [ ] Проект распакован в `C:\TelegramAutomation`
- [ ] Зависимости установлены (`install.bat` выполнен)
- [ ] База данных настроена (`database.env`)
- [ ] Telegram API настроен (`telegram.env`)
- [ ] База данных инициализирована (`init_database.py`)
- [ ] Веб-панель запускается (`run.bat`)
- [ ] Веб-панель открывается в браузере (http://localhost:3000)
- [ ] Telegram-аккаунт авторизован
- [ ] Тестовый поиск конкурентов работает

---

## 🎉 Готово!

Если все пункты чек-листа выполнены - **поздравляю, установка завершена!**

Теперь вы можете:
- ✅ Парсить конкурентов
- ✅ Инвайтить подписчиков
- ✅ Генерировать AI-контент
- ✅ Автоматизировать коммуникации
- ✅ И многое другое!

**Приятного использования!** 🚀

---

**Версия гайда:** 1.0.0  
**Дата:** 2025-01-20  
**Платформа:** Windows 10/11 (64-bit)
