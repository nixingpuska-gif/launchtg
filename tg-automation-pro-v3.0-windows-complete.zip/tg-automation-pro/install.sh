#!/bin/bash

# ============================================
# Telegram Automation Pro - Automatic Installer
# Автоматическая установка всех зависимостей
# ============================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Functions
print_header() {
    echo ""
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC}  $1"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${CYAN}ℹ️  $1${NC}"
}

# ============================================
# STEP 0: Welcome
# ============================================

clear
print_header "🤖 Telegram Automation Pro - Автоматический установщик"

echo -e "${CYAN}Этот скрипт автоматически:${NC}"
echo "  1. Проверит вашу систему"
echo "  2. Установит все необходимые зависимости"
echo "  3. Развернет Telegram Automation Pro"
echo ""
echo -e "${YELLOW}Поддерживаемые ОС: Ubuntu 20.04+, Debian 11+, CentOS 8+${NC}"
echo ""
read -p "Продолжить установку? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    print_error "Установка отменена"
    exit 1
fi

# ============================================
# STEP 1: Detect OS
# ============================================

print_header "Определение операционной системы"

if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    OS_VERSION=$VERSION_ID
    print_success "Обнаружена ОС: $PRETTY_NAME"
else
    print_error "Не удалось определить ОС"
    exit 1
fi

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    print_warning "Скрипт запущен от root. Рекомендуется запускать от обычного пользователя с sudo."
    SUDO=""
else
    SUDO="sudo"
fi

# ============================================
# STEP 2: Check System Requirements
# ============================================

print_header "Проверка системных требований"

# Check CPU cores
CPU_CORES=$(nproc)
print_info "CPU ядер: $CPU_CORES"
if [ "$CPU_CORES" -lt 2 ]; then
    print_warning "Рекомендуется минимум 2 CPU ядра (обнаружено: $CPU_CORES)"
fi

# Check RAM
TOTAL_RAM=$(free -m | awk '/^Mem:/{print $2}')
print_info "RAM: ${TOTAL_RAM}MB"
if [ "$TOTAL_RAM" -lt 4000 ]; then
    print_warning "Рекомендуется минимум 4GB RAM (обнаружено: ${TOTAL_RAM}MB)"
fi

# Check disk space
DISK_SPACE=$(df -BG / | awk 'NR==2 {print $4}' | sed 's/G//')
print_info "Свободное место на диске: ${DISK_SPACE}GB"
if [ "$DISK_SPACE" -lt 20 ]; then
    print_warning "Рекомендуется минимум 20GB свободного места (обнаружено: ${DISK_SPACE}GB)"
fi

# ============================================
# STEP 3: Update System
# ============================================

print_header "Обновление системы"

case "$OS" in
    ubuntu|debian)
        print_info "Обновление пакетов (это может занять несколько минут)..."
        $SUDO apt-get update -qq
        $SUDO apt-get upgrade -y -qq
        print_success "Система обновлена"
        ;;
    centos|rhel|fedora)
        print_info "Обновление пакетов..."
        $SUDO yum update -y -q
        print_success "Система обновлена"
        ;;
    *)
        print_warning "Автоматическое обновление не поддерживается для $OS"
        ;;
esac

# ============================================
# STEP 4: Install Dependencies
# ============================================

print_header "Установка базовых зависимостей"

case "$OS" in
    ubuntu|debian)
        PACKAGES="curl wget git ca-certificates gnupg lsb-release apt-transport-https software-properties-common"
        print_info "Установка: $PACKAGES"
        $SUDO apt-get install -y -qq $PACKAGES
        print_success "Базовые пакеты установлены"
        ;;
    centos|rhel|fedora)
        PACKAGES="curl wget git ca-certificates"
        print_info "Установка: $PACKAGES"
        $SUDO yum install -y -q $PACKAGES
        print_success "Базовые пакеты установлены"
        ;;
esac

# ============================================
# STEP 5: Install Docker
# ============================================

print_header "Проверка Docker"

if command -v docker &> /dev/null; then
    DOCKER_VERSION=$(docker --version | awk '{print $3}' | sed 's/,//')
    print_success "Docker уже установлен (версия: $DOCKER_VERSION)"
else
    print_warning "Docker не найден. Начинаю установку..."
    
    case "$OS" in
        ubuntu|debian)
            # Remove old versions
            $SUDO apt-get remove -y docker docker-engine docker.io containerd runc 2>/dev/null || true
            
            # Add Docker's official GPG key
            $SUDO mkdir -p /etc/apt/keyrings
            curl -fsSL https://download.docker.com/linux/$OS/gpg | $SUDO gpg --dearmor -o /etc/apt/keyrings/docker.gpg
            
            # Set up repository
            echo \
              "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/$OS \
              $(lsb_release -cs) stable" | $SUDO tee /etc/apt/sources.list.d/docker.list > /dev/null
            
            # Install Docker
            $SUDO apt-get update -qq
            $SUDO apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
            
            print_success "Docker установлен"
            ;;
        
        centos|rhel|fedora)
            # Remove old versions
            $SUDO yum remove -y docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-engine 2>/dev/null || true
            
            # Set up repository
            $SUDO yum install -y yum-utils
            $SUDO yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
            
            # Install Docker
            $SUDO yum install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
            
            print_success "Docker установлен"
            ;;
        
        *)
            print_error "Автоматическая установка Docker не поддерживается для $OS"
            echo "Установите Docker вручную: https://docs.docker.com/engine/install/"
            exit 1
            ;;
    esac
    
    # Start Docker
    $SUDO systemctl start docker
    $SUDO systemctl enable docker
    
    # Add current user to docker group
    if [ "$EUID" -ne 0 ]; then
        $SUDO usermod -aG docker $USER
        print_warning "Пользователь $USER добавлен в группу docker"
        print_warning "Выйдите и войдите снова, чтобы изменения вступили в силу"
        print_warning "Или выполните: newgrp docker"
    fi
fi

# ============================================
# STEP 6: Check Docker Compose
# ============================================

print_header "Проверка Docker Compose"

if docker compose version &> /dev/null; then
    COMPOSE_VERSION=$(docker compose version --short)
    print_success "Docker Compose уже установлен (версия: $COMPOSE_VERSION)"
else
    print_error "Docker Compose не найден"
    print_info "Docker Compose должен быть установлен вместе с Docker"
    exit 1
fi

# ============================================
# STEP 7: Setup Project
# ============================================

print_header "Настройка проекта"

# Get current directory
PROJECT_DIR=$(pwd)
print_info "Директория проекта: $PROJECT_DIR"

# Create necessary directories
print_info "Создание директорий..."
mkdir -p logs sessions backups
print_success "Директории созданы"

# ============================================
# STEP 8: Configure Environment
# ============================================

print_header "Настройка окружения"

if [ -f .env ]; then
    print_warning ".env файл уже существует"
    read -p "Перезаписать? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_info "Используется существующий .env файл"
    else
        cp .env.example .env
        print_success ".env файл создан из шаблона"
    fi
else
    cp .env.example .env
    print_success ".env файл создан из шаблона"
fi

# Generate random secrets
print_info "Генерация случайных ключей безопасности..."

if command -v openssl &> /dev/null; then
    SECRET_KEY=$(openssl rand -hex 32)
    POSTGRES_PASSWORD=$(openssl rand -hex 16)
    REDIS_PASSWORD=$(openssl rand -hex 16)
    
    # Update .env file
    sed -i "s/your_super_secret_key_change_this_in_production/$SECRET_KEY/" .env
    sed -i "s/secure_password_2024/$POSTGRES_PASSWORD/" .env
    sed -i "s/redis_pass_2024/$REDIS_PASSWORD/" .env
    
    print_success "Случайные ключи сгенерированы и сохранены в .env"
else
    print_warning "OpenSSL не найден. Используются ключи по умолчанию."
    print_warning "ВАЖНО: Смените их вручную в файле .env!"
fi

# ============================================
# STEP 9: Configure Telegram API
# ============================================

print_header "Настройка Telegram API"

echo -e "${CYAN}Для работы системы нужны Telegram API credentials${NC}"
echo "Получить их можно на: https://my.telegram.org"
echo ""
read -p "Хотите ввести API credentials сейчас? (y/n) " -n 1 -r
echo

if [[ $REPLY =~ ^[Yy]$ ]]; then
    read -p "Введите API ID: " API_ID
    read -p "Введите API Hash: " API_HASH
    
    sed -i "s/TELEGRAM_API_ID=.*/TELEGRAM_API_ID=$API_ID/" .env
    sed -i "s/TELEGRAM_API_HASH=.*/TELEGRAM_API_HASH=$API_HASH/" .env
    
    print_success "Telegram API credentials сохранены"
else
    print_warning "Не забудьте добавить Telegram API credentials в .env файл!"
fi

# ============================================
# STEP 10: Build and Start
# ============================================

print_header "Сборка и запуск системы"

print_info "Сборка Docker образов (это может занять 5-10 минут)..."
docker compose build

print_success "Образы собраны"

print_info "Запуск сервисов..."
docker compose up -d db redis backend frontend

print_success "Сервисы запущены"

# Wait for database
print_info "Ожидание готовности базы данных..."
sleep 15

# Check services
print_info "Проверка статуса сервисов..."
docker compose ps

# ============================================
# STEP 11: Optional LLM Installation
# ============================================

print_header "Установка LLM (опционально)"

echo -e "${CYAN}LLM (LLaMA 3.1 8B) используется для генерации персонализированных сообщений${NC}"
echo "Размер загрузки: ~4.7GB"
echo ""
read -p "Установить LLM сейчас? (y/n) " -n 1 -r
echo

if [[ $REPLY =~ ^[Yy]$ ]]; then
    print_info "Запуск Ollama..."
    docker compose up -d ollama
    sleep 10
    
    print_info "Загрузка модели LLaMA 3.1 8B (это займет 10-20 минут)..."
    docker exec tg_automation_llm ollama pull llama3.1:8b
    
    print_success "LLM установлен и готов к работе"
else
    print_warning "LLM не установлен. Система будет использовать шаблоны сообщений."
    print_info "Установить позже: docker compose up -d ollama && docker exec tg_automation_llm ollama pull llama3.1:8b"
fi

# ============================================
# STEP 12: Create Admin User
# ============================================

print_header "Создание администратора"

print_info "Создание администратора в базе данных..."

# Wait a bit more for DB
sleep 5

# Create admin user (password: admin123)
docker exec tg_automation_db psql -U postgres -d telegram_automation -c \
  "INSERT INTO admin_users (username, email, password_hash, is_active) 
   VALUES ('admin', 'admin@example.com', '\$2b\$12\$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5NU7TUQ9aqQ/i', TRUE) 
   ON CONFLICT (username) DO NOTHING;" 2>/dev/null || true

print_success "Администратор создан"

# ============================================
# STEP 13: Final Steps
# ============================================

print_header "🎉 Установка завершена!"

echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║${NC}  Telegram Automation Pro успешно установлен!"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}🌐 Доступ к системе:${NC}"
echo "   Веб-панель: http://$(hostname -I | awk '{print $1}'):3000"
echo "   API: http://$(hostname -I | awk '{print $1}'):5000"
echo ""
echo -e "${CYAN}🔑 Данные для входа:${NC}"
echo "   Username: admin"
echo "   Password: admin123"
echo -e "   ${RED}⚠️  ОБЯЗАТЕЛЬНО СМЕНИТЕ ПАРОЛЬ ПОСЛЕ ПЕРВОГО ВХОДА!${NC}"
echo ""
echo -e "${CYAN}📝 Следующие шаги:${NC}"
echo "   1. Откройте веб-панель в браузере"
echo "   2. Войдите и смените пароль администратора"
echo "   3. Создайте Telegram сессию: ./scripts/create_session.sh"
echo "   4. Добавьте целевые группы через веб-панель"
echo "   5. Создайте и запустите кампанию"
echo ""
echo -e "${CYAN}📊 Полезные команды:${NC}"
echo "   Просмотр логов:     docker compose logs -f"
echo "   Остановка:          docker compose down"
echo "   Перезапуск:         docker compose restart"
echo "   Статус сервисов:    docker compose ps"
echo ""
echo -e "${CYAN}📖 Документация:${NC}"
echo "   README.md - Обзор системы"
echo "   INSTALLATION.md - Подробное руководство"
echo "   SUMMARY.md - Техническая документация"
echo ""
print_success "Установка завершена успешно! 🚀"
echo ""
