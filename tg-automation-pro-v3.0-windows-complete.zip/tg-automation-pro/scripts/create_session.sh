#!/bin/bash

# ============================================
# Create Telegram Session Script
# ============================================

echo "🤖 Telegram Session Creator"
echo "================================"
echo ""

# Get API credentials
read -p "Enter API ID: " API_ID
read -p "Enter API Hash: " API_HASH
read -p "Enter phone number (with +): " PHONE

# Create Python script
cat > /tmp/create_session.py << EOF
import asyncio
from telethon import TelegramClient

async def main():
    client = TelegramClient('/app/sessions/${PHONE}.session', ${API_ID}, '${API_HASH}')
    
    await client.start(phone='${PHONE}')
    
    me = await client.get_me()
    print(f"\n✅ Session created successfully!")
    print(f"👤 Logged in as: {me.first_name} {me.last_name or ''}")
    print(f"🆔 User ID: {me.id}")
    print(f"📞 Phone: {me.phone}")
    
    await client.disconnect()
    
    print(f"\n📋 Add this account to database:")
    print(f"""
INSERT INTO telegram_accounts (phone, api_id, api_hash, session_file, role)
VALUES ('${PHONE}', ${API_ID}, '${API_HASH}', '/app/sessions/${PHONE}.session', 'parser');
    """)

asyncio.run(main())
EOF

# Run in Docker container
docker run --rm -it \
    -v $(pwd)/sessions:/app/sessions \
    --network tg-automation-pro_tg_network \
    python:3.11-slim \
    bash -c "pip install telethon && python /tmp/create_session.py"

# Cleanup
rm /tmp/create_session.py

echo ""
echo "✅ Session created! Copy the SQL query above to add account to database."
