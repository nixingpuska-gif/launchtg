#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Скрипт инициализации базы данных для Windows
Создаёт все необходимые таблицы для Telegram Automation Pro
"""

import os
import sys
from pathlib import Path

# Добавляем корневую директорию в путь
ROOT_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT_DIR))

try:
    import psycopg2
    from psycopg2 import sql
    from dotenv import load_dotenv
except ImportError as e:
    print(f"❌ Ошибка импорта: {e}")
    print("\nУстановите зависимости:")
    print("pip install psycopg2-binary python-dotenv")
    sys.exit(1)


def load_config():
    """Загрузка конфигурации из .env файлов"""
    config_dir = ROOT_DIR / "config"
    
    # Загружаем database.env
    db_env = config_dir / "database.env"
    if not db_env.exists():
        print(f"❌ Файл {db_env} не найден!")
        print("\nСоздайте файл config/database.env с содержимым:")
        print("DATABASE_URL=postgresql://postgres:password@localhost:5432/telegram_automation")
        sys.exit(1)
    
    load_dotenv(db_env)
    
    database_url = os.getenv("DATABASE_URL")
    if not database_url:
        print("❌ DATABASE_URL не найден в config/database.env")
        sys.exit(1)
    
    return database_url


def parse_database_url(url):
    """Парсинг DATABASE_URL"""
    # postgresql://user:password@host:port/database
    try:
        url = url.replace("postgresql://", "")
        
        # Разделяем user:password и host:port/database
        auth, location = url.split("@")
        user, password = auth.split(":")
        
        # Разделяем host:port и database
        host_port, database = location.split("/")
        host, port = host_port.split(":")
        
        return {
            "user": user,
            "password": password,
            "host": host,
            "port": int(port),
            "database": database
        }
    except Exception as e:
        print(f"❌ Ошибка парсинга DATABASE_URL: {e}")
        print("\nФормат должен быть:")
        print("postgresql://user:password@host:port/database")
        sys.exit(1)


def create_database(conn_params):
    """Создание базы данных если не существует"""
    db_name = conn_params.pop("database")
    
    try:
        # Подключаемся к postgres (системная БД)
        conn_params["database"] = "postgres"
        conn = psycopg2.connect(**conn_params)
        conn.autocommit = True
        cursor = conn.cursor()
        
        # Проверяем существование БД
        cursor.execute(
            "SELECT 1 FROM pg_database WHERE datname = %s",
            (db_name,)
        )
        
        if cursor.fetchone():
            print(f"ℹ️ База данных '{db_name}' уже существует")
        else:
            # Создаём БД
            cursor.execute(
                sql.SQL("CREATE DATABASE {}").format(
                    sql.Identifier(db_name)
                )
            )
            print(f"✅ База данных '{db_name}' создана")
        
        cursor.close()
        conn.close()
        
        # Возвращаем имя БД обратно
        conn_params["database"] = db_name
        
    except psycopg2.Error as e:
        print(f"❌ Ошибка при создании БД: {e}")
        sys.exit(1)


def create_tables(conn_params):
    """Создание всех таблиц"""
    
    tables = [
        # 1. Таблица аккаунтов
        """
        CREATE TABLE IF NOT EXISTS accounts (
            id SERIAL PRIMARY KEY,
            phone VARCHAR(20) UNIQUE NOT NULL,
            api_id INTEGER NOT NULL,
            api_hash VARCHAR(100) NOT NULL,
            session_string TEXT,
            status VARCHAR(20) DEFAULT 'active',
            is_warming BOOLEAN DEFAULT FALSE,
            warming_stage INTEGER DEFAULT 0,
            warming_started_at TIMESTAMP,
            ban_risk_score FLOAT DEFAULT 0.0,
            last_activity TIMESTAMP,
            total_invites INTEGER DEFAULT 0,
            total_messages INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 2. Таблица проектов
        """
        CREATE TABLE IF NOT EXISTS projects (
            id SERIAL PRIMARY KEY,
            name VARCHAR(200) NOT NULL,
            description TEXT,
            target_audience TEXT,
            keywords TEXT[],
            status VARCHAR(20) DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 3. Таблица конкурентов
        """
        CREATE TABLE IF NOT EXISTS competitors (
            id SERIAL PRIMARY KEY,
            project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
            channel_id BIGINT NOT NULL,
            username VARCHAR(100),
            title VARCHAR(200),
            subscribers_count INTEGER,
            posts_per_week FLOAT,
            engagement_rate FLOAT,
            relevance_score FLOAT,
            last_monitored TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(project_id, channel_id)
        )
        """,
        
        # 4. Таблица постов конкурентов
        """
        CREATE TABLE IF NOT EXISTS competitor_posts (
            id SERIAL PRIMARY KEY,
            competitor_id INTEGER REFERENCES competitors(id) ON DELETE CASCADE,
            post_id BIGINT NOT NULL,
            text TEXT,
            views INTEGER,
            reactions INTEGER,
            comments_count INTEGER,
            posted_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(competitor_id, post_id)
        )
        """,
        
        # 5. Таблица целевой аудитории
        """
        CREATE TABLE IF NOT EXISTS target_users (
            id SERIAL PRIMARY KEY,
            project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
            user_id BIGINT NOT NULL,
            username VARCHAR(100),
            first_name VARCHAR(100),
            last_name VARCHAR(100),
            activity_score FLOAT,
            comments_count INTEGER DEFAULT 0,
            last_seen TIMESTAMP,
            source_competitor_id INTEGER REFERENCES competitors(id),
            is_invited BOOLEAN DEFAULT FALSE,
            invite_status VARCHAR(20),
            invited_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(project_id, user_id)
        )
        """,
        
        # 6. Таблица инвайтов
        """
        CREATE TABLE IF NOT EXISTS invites (
            id SERIAL PRIMARY KEY,
            account_id INTEGER REFERENCES accounts(id) ON DELETE CASCADE,
            target_user_id INTEGER REFERENCES target_users(id) ON DELETE CASCADE,
            message TEXT,
            status VARCHAR(20) DEFAULT 'pending',
            sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            accepted_at TIMESTAMP,
            error_message TEXT
        )
        """,
        
        # 7. Таблица AI-контента
        """
        CREATE TABLE IF NOT EXISTS ai_content (
            id SERIAL PRIMARY KEY,
            project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
            content_type VARCHAR(50),
            prompt TEXT,
            generated_text TEXT,
            model_used VARCHAR(50),
            quality_score FLOAT,
            is_used BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 8. Таблица метрик банов
        """
        CREATE TABLE IF NOT EXISTS ban_metrics (
            id SERIAL PRIMARY KEY,
            account_id INTEGER REFERENCES accounts(id) ON DELETE CASCADE,
            metric_name VARCHAR(100),
            metric_value FLOAT,
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 9. Таблица предсказаний банов
        """
        CREATE TABLE IF NOT EXISTS ban_predictions (
            id SERIAL PRIMARY KEY,
            account_id INTEGER REFERENCES accounts(id) ON DELETE CASCADE,
            risk_score FLOAT,
            risk_level VARCHAR(20),
            contributing_factors JSONB,
            recommended_actions TEXT[],
            predicted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 10. Таблица сетевого графа
        """
        CREATE TABLE IF NOT EXISTS network_graph (
            id SERIAL PRIMARY KEY,
            user_id BIGINT NOT NULL,
            connected_user_id BIGINT NOT NULL,
            connection_type VARCHAR(50),
            strength FLOAT,
            last_interaction TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(user_id, connected_user_id)
        )
        """,
        
        # 11. Таблица sentiment анализа
        """
        CREATE TABLE IF NOT EXISTS sentiment_analysis (
            id SERIAL PRIMARY KEY,
            user_id BIGINT NOT NULL,
            text TEXT,
            sentiment VARCHAR(20),
            sentiment_score FLOAT,
            analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 12. Таблица A/B тестов
        """
        CREATE TABLE IF NOT EXISTS ab_tests (
            id SERIAL PRIMARY KEY,
            project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
            test_name VARCHAR(200),
            variant_a TEXT,
            variant_b TEXT,
            variant_a_conversions INTEGER DEFAULT 0,
            variant_b_conversions INTEGER DEFAULT 0,
            variant_a_sends INTEGER DEFAULT 0,
            variant_b_sends INTEGER DEFAULT 0,
            status VARCHAR(20) DEFAULT 'active',
            started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            ended_at TIMESTAMP
        )
        """,
        
        # 13. Таблица голосовых сообщений
        """
        CREATE TABLE IF NOT EXISTS voice_messages (
            id SERIAL PRIMARY KEY,
            project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
            text TEXT,
            audio_file_path VARCHAR(500),
            duration INTEGER,
            voice_type VARCHAR(50),
            is_used BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 14. Таблица geo-таргетинга
        """
        CREATE TABLE IF NOT EXISTS geo_targets (
            id SERIAL PRIMARY KEY,
            user_id BIGINT NOT NULL,
            country VARCHAR(100),
            city VARCHAR(100),
            latitude FLOAT,
            longitude FLOAT,
            detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 15. Таблица инфлюенсеров
        """
        CREATE TABLE IF NOT EXISTS influencers (
            id SERIAL PRIMARY KEY,
            user_id BIGINT UNIQUE NOT NULL,
            username VARCHAR(100),
            followers_count INTEGER,
            engagement_rate FLOAT,
            niche VARCHAR(100),
            influence_score FLOAT,
            last_analyzed TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 16. Таблица ретаргетинга
        """
        CREATE TABLE IF NOT EXISTS retargeting (
            id SERIAL PRIMARY KEY,
            user_id BIGINT NOT NULL,
            interaction_type VARCHAR(50),
            interaction_count INTEGER DEFAULT 1,
            last_interaction TIMESTAMP,
            retarget_priority FLOAT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 17. Таблица контента конкурентов
        """
        CREATE TABLE IF NOT EXISTS scraped_content (
            id SERIAL PRIMARY KEY,
            competitor_id INTEGER REFERENCES competitors(id) ON DELETE CASCADE,
            content_type VARCHAR(50),
            content TEXT,
            media_urls TEXT[],
            scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 18. Таблица вебхуков
        """
        CREATE TABLE IF NOT EXISTS webhooks (
            id SERIAL PRIMARY KEY,
            project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
            event_type VARCHAR(100),
            webhook_url VARCHAR(500),
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 19. Таблица блокчейн верификации
        """
        CREATE TABLE IF NOT EXISTS blockchain_verifications (
            id SERIAL PRIMARY KEY,
            user_id BIGINT NOT NULL,
            wallet_address VARCHAR(200),
            blockchain VARCHAR(50),
            verification_status VARCHAR(20),
            verified_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # 20. Таблица логов
        """
        CREATE TABLE IF NOT EXISTS activity_logs (
            id SERIAL PRIMARY KEY,
            account_id INTEGER REFERENCES accounts(id) ON DELETE CASCADE,
            action_type VARCHAR(100),
            details JSONB,
            status VARCHAR(20),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    ]
    
    try:
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()
        
        print("\n📊 Создание таблиц...")
        
        for i, table_sql in enumerate(tables, 1):
            cursor.execute(table_sql)
            print(f"✅ Таблица {i}/20 создана")
        
        conn.commit()
        cursor.close()
        conn.close()
        
        print(f"\n✅ Все 20 таблиц успешно созданы!")
        
    except psycopg2.Error as e:
        print(f"\n❌ Ошибка при создании таблиц: {e}")
        sys.exit(1)


def main():
    """Главная функция"""
    print("=" * 60)
    print("  Telegram Automation Pro - Инициализация БД")
    print("  Версия: 3.0.0")
    print("=" * 60)
    print()
    
    # Загружаем конфигурацию
    print("[1/3] Загрузка конфигурации...")
    database_url = load_config()
    conn_params = parse_database_url(database_url)
    print(f"✅ Подключение к {conn_params['host']}:{conn_params['port']}")
    print()
    
    # Создаём БД
    print("[2/3] Создание базы данных...")
    create_database(conn_params)
    print()
    
    # Создаём таблицы
    print("[3/3] Создание таблиц...")
    create_tables(conn_params)
    print()
    
    print("=" * 60)
    print("  ✅ ИНИЦИАЛИЗАЦИЯ ЗАВЕРШЕНА!")
    print("=" * 60)
    print()
    print("Теперь вы можете запустить приложение:")
    print("  run_windows.bat")
    print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️ Прервано пользователем")
        sys.exit(0)
    except Exception as e:
        print(f"\n\n❌ Неожиданная ошибка: {e}")
        sys.exit(1)
