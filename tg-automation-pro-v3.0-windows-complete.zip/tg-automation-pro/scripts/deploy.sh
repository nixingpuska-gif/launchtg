#!/bin/bash

# ============================================
# Telegram Automation Pro - Deployment Script
# ============================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
print_header() {
    echo -e "${BLUE}================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}================================${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    print_error "Please do not run this script as root"
    exit 1
fi

# ============================================
# STEP 1: Check Prerequisites
# ============================================

print_header "Checking Prerequisites"

# Check Docker
if ! command -v docker &> /dev/null; then
    print_error "Docker is not installed"
    echo "Install Docker: curl -fsSL https://get.docker.com | sh"
    exit 1
fi
print_success "Docker installed"

# Check Docker Compose
if ! command -v docker compose &> /dev/null; then
    print_error "Docker Compose is not installed"
    exit 1
fi
print_success "Docker Compose installed"

# ============================================
# STEP 2: Setup Environment
# ============================================

print_header "Setting up Environment"

if [ ! -f .env ]; then
    print_warning ".env file not found, creating from .env.example"
    cp .env.example .env
    
    # Generate random secrets
    SECRET_KEY=$(openssl rand -hex 32)
    POSTGRES_PASSWORD=$(openssl rand -hex 16)
    REDIS_PASSWORD=$(openssl rand -hex 16)
    
    # Update .env
    sed -i "s/your_super_secret_key_change_this_in_production/$SECRET_KEY/" .env
    sed -i "s/secure_password_2024/$POSTGRES_PASSWORD/" .env
    sed -i "s/redis_pass_2024/$REDIS_PASSWORD/" .env
    
    print_success ".env file created with random secrets"
    print_warning "Please edit .env and add your Telegram API credentials!"
    
    read -p "Press Enter to continue after editing .env..."
else
    print_success ".env file exists"
fi

# Create necessary directories
mkdir -p logs sessions backups
print_success "Directories created"

# ============================================
# STEP 3: Build Docker Images
# ============================================

print_header "Building Docker Images"

docker compose build
print_success "Docker images built"

# ============================================
# STEP 4: Start Services
# ============================================

print_header "Starting Services"

docker compose up -d
print_success "Services started"

# Wait for database
print_warning "Waiting for database to be ready..."
sleep 10

# ============================================
# STEP 5: Check Services Health
# ============================================

print_header "Checking Services Health"

# Check PostgreSQL
if docker exec tg_automation_db pg_isready -U postgres > /dev/null 2>&1; then
    print_success "PostgreSQL is healthy"
else
    print_error "PostgreSQL is not healthy"
fi

# Check Redis
if docker exec tg_automation_redis redis-cli --raw incr ping > /dev/null 2>&1; then
    print_success "Redis is healthy"
else
    print_error "Redis is not healthy"
fi

# ============================================
# STEP 6: Install LLM Model
# ============================================

print_header "Installing LLM Model"

print_warning "This will download ~4.7GB. Continue? (y/n)"
read -p "" -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    docker exec tg_automation_llm ollama pull llama3.1:8b
    print_success "LLM model installed"
else
    print_warning "Skipping LLM installation"
fi

# ============================================
# STEP 7: Display Access Information
# ============================================

print_header "Deployment Complete!"

echo ""
echo "🌐 Access URLs:"
echo "   Web Panel: http://localhost:3000"
echo "   API: http://localhost:5000"
echo "   Database: localhost:5432"
echo ""
echo "🔑 Default Credentials:"
echo "   Username: admin"
echo "   Password: admin123"
echo "   ⚠️  CHANGE THIS IMMEDIATELY!"
echo ""
echo "📝 Next Steps:"
echo "   1. Access web panel and change admin password"
echo "   2. Create Telegram session: ./scripts/create_session.sh"
echo "   3. Add target groups via web panel"
echo "   4. Create and start campaign"
echo ""
echo "📊 View logs:"
echo "   docker compose logs -f backend"
echo "   docker compose logs -f bot_worker"
echo ""
echo "🛑 Stop services:"
echo "   docker compose down"
echo ""

print_success "Deployment successful! 🎉"
