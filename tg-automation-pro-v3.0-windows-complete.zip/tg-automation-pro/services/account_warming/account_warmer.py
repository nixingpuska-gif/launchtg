"""
Smart Account Warming System
Автоматический прогрев аккаунтов для минимизации банов
"""

import asyncio
import random
import logging
from typing import List, Dict, Optional
from datetime import datetime, timedelta
from enum import Enum
from dataclasses import dataclass
from telethon import TelegramClient
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import SendReactionRequest
from telethon.errors import FloodWaitError, UserBannedInChannelError

logger = logging.getLogger(__name__)


class WarmingStage(Enum):
    """Стадии прогрева аккаунта"""
    SETUP = "setup"  # День 1-3: Базовая настройка
    PASSIVE = "passive"  # День 4-7: Пассивное взаимодействие
    ACTIVE = "active"  # День 8-11: Активное общение
    READY = "ready"  # День 12-14: Готов к работе


@dataclass
class WarmingConfig:
    """Конфигурация прогрева"""
    # Длительность каждой стадии (дни)
    setup_days: int = 3
    passive_days: int = 4
    active_days: int = 4
    
    # Лимиты действий по стадиям
    setup_groups_per_day: int = 3
    passive_groups_per_day: int = 5
    active_groups_per_day: int = 7
    
    setup_reactions_per_day: int = 5
    passive_reactions_per_day: int = 15
    active_reactions_per_day: int = 30
    
    setup_messages_per_day: int = 0
    passive_messages_per_day: int = 2
    active_messages_per_day: int = 10
    
    # Задержки между действиями (секунды)
    min_delay: int = 120  # 2 минуты
    max_delay: int = 600  # 10 минут
    
    # Рабочие часы (UTC)
    work_hours_start: int = 8
    work_hours_end: int = 23


@dataclass
class WarmingProgress:
    """Прогресс прогрева аккаунта"""
    account_id: int
    phone: str
    current_stage: WarmingStage
    start_date: datetime
    groups_joined: int
    reactions_sent: int
    messages_sent: int
    comments_sent: int
    last_activity: datetime
    is_complete: bool


class AccountWarmer:
    """
    Система прогрева Telegram аккаунтов
    
    Процесс прогрева (14 дней):
    
    День 1-3 (SETUP):
    - Настройка профиля (фото, био, username)
    - Вступление в 3-5 популярных групп
    - Просмотр сообщений (без активности)
    - 5 реакций в день
    
    День 4-7 (PASSIVE):
    - Вступление в 5-7 групп по теме
    - 15 реакций в день
    - 2-3 коротких комментария
    - Просмотр профилей других пользователей
    
    День 8-11 (ACTIVE):
    - Вступление в 7-10 групп
    - 30 реакций в день
    - 10 сообщений/комментариев
    - Начало диалогов (1-2 в день)
    
    День 12-14 (READY):
    - Первые инвайты (5-10 в день)
    - Продолжение активности
    - Готов к полноценной работе
    """
    
    def __init__(self, config: WarmingConfig = None):
        self.config = config or WarmingConfig()
        self.warming_groups = [
            # Популярные безопасные группы для прогрева
            "@telegram",
            "@durov",
            "@TelegramTips",
        ]
    
    async def start_warming(
        self,
        client: TelegramClient,
        account_id: int,
        phone: str
    ) -> WarmingProgress:
        """
        Запускает процесс прогрева аккаунта
        
        Args:
            client: Telegram клиент
            account_id: ID аккаунта в БД
            phone: Номер телефона
            
        Returns:
            Прогресс прогрева
        """
        logger.info(f"Начинаем прогрев аккаунта {phone}")
        
        progress = WarmingProgress(
            account_id=account_id,
            phone=phone,
            current_stage=WarmingStage.SETUP,
            start_date=datetime.utcnow(),
            groups_joined=0,
            reactions_sent=0,
            messages_sent=0,
            comments_sent=0,
            last_activity=datetime.utcnow(),
            is_complete=False
        )
        
        # Запускаем прогрев
        await self._run_warming_cycle(client, progress)
        
        return progress
    
    async def _run_warming_cycle(
        self,
        client: TelegramClient,
        progress: WarmingProgress
    ):
        """Основной цикл прогрева"""
        
        while not progress.is_complete:
            # Определяем текущую стадию
            days_passed = (datetime.utcnow() - progress.start_date).days
            progress.current_stage = self._get_current_stage(days_passed)
            
            logger.info(f"День {days_passed + 1}, стадия: {progress.current_stage.value}")
            
            # Проверяем рабочие часы
            if not self._is_working_hours():
                logger.info("Вне рабочих часов, спим...")
                await asyncio.sleep(3600)  # Спим час
                continue
            
            # Выполняем действия по стадии
            if progress.current_stage == WarmingStage.SETUP:
                await self._setup_stage(client, progress)
            elif progress.current_stage == WarmingStage.PASSIVE:
                await self._passive_stage(client, progress)
            elif progress.current_stage == WarmingStage.ACTIVE:
                await self._active_stage(client, progress)
            elif progress.current_stage == WarmingStage.READY:
                await self._ready_stage(client, progress)
                progress.is_complete = True
            
            # Обновляем время последней активности
            progress.last_activity = datetime.utcnow()
            
            # Случайная пауза между циклами
            await self._random_sleep(3600, 7200)  # 1-2 часа
    
    async def _setup_stage(self, client: TelegramClient, progress: WarmingProgress):
        """Стадия 1: Базовая настройка"""
        logger.info("Стадия SETUP: Базовая настройка")
        
        # Вступаем в группы
        groups_to_join = self.config.setup_groups_per_day - progress.groups_joined
        if groups_to_join > 0:
            await self._join_groups(client, groups_to_join, progress)
        
        # Отправляем реакции
        reactions_to_send = self.config.setup_reactions_per_day - progress.reactions_sent
        if reactions_to_send > 0:
            await self._send_reactions(client, reactions_to_send, progress)
    
    async def _passive_stage(self, client: TelegramClient, progress: WarmingProgress):
        """Стадия 2: Пассивное взаимодействие"""
        logger.info("Стадия PASSIVE: Пассивное взаимодействие")
        
        # Вступаем в группы
        await self._join_groups(client, self.config.passive_groups_per_day, progress)
        
        # Отправляем реакции
        await self._send_reactions(client, self.config.passive_reactions_per_day, progress)
        
        # Отправляем короткие комментарии
        await self._send_comments(client, self.config.passive_messages_per_day, progress)
    
    async def _active_stage(self, client: TelegramClient, progress: WarmingProgress):
        """Стадия 3: Активное общение"""
        logger.info("Стадия ACTIVE: Активное общение")
        
        # Вступаем в группы
        await self._join_groups(client, self.config.active_groups_per_day, progress)
        
        # Отправляем реакции
        await self._send_reactions(client, self.config.active_reactions_per_day, progress)
        
        # Отправляем сообщения
        await self._send_comments(client, self.config.active_messages_per_day, progress)
    
    async def _ready_stage(self, client: TelegramClient, progress: WarmingProgress):
        """Стадия 4: Готов к работе"""
        logger.info("Стадия READY: Аккаунт прогрет и готов к работе!")
        
        # Последние действия перед завершением
        await self._send_reactions(client, 10, progress)
        await self._send_comments(client, 5, progress)
    
    async def _join_groups(
        self,
        client: TelegramClient,
        count: int,
        progress: WarmingProgress
    ):
        """Вступление в группы"""
        logger.info(f"Вступаем в {count} групп...")
        
        for i in range(count):
            try:
                # Выбираем случайную группу
                group = random.choice(self.warming_groups)
                
                # Вступаем
                await client(JoinChannelRequest(group))
                progress.groups_joined += 1
                logger.info(f"Вступили в {group}")
                
                # Случайная пауза
                await self._random_sleep()
                
            except FloodWaitError as e:
                logger.warning(f"FloodWait: ждём {e.seconds} секунд")
                await asyncio.sleep(e.seconds)
            except UserBannedInChannelError:
                logger.error("Аккаунт забанен в группе!")
                break
            except Exception as e:
                logger.error(f"Ошибка при вступлении в группу: {e}")
    
    async def _send_reactions(
        self,
        client: TelegramClient,
        count: int,
        progress: WarmingProgress
    ):
        """Отправка реакций на сообщения"""
        logger.info(f"Отправляем {count} реакций...")
        
        reactions = ["👍", "❤️", "🔥", "👏", "😊"]
        
        for i in range(count):
            try:
                # Получаем случайную группу
                group = random.choice(self.warming_groups)
                
                # Получаем последние сообщения
                messages = await client.get_messages(group, limit=20)
                
                if messages:
                    # Выбираем случайное сообщение
                    message = random.choice(messages)
                    reaction = random.choice(reactions)
                    
                    # Отправляем реакцию
                    await client(SendReactionRequest(
                        peer=group,
                        msg_id=message.id,
                        reaction=[reaction]
                    ))
                    
                    progress.reactions_sent += 1
                    logger.info(f"Отправили реакцию {reaction}")
                
                # Случайная пауза
                await self._random_sleep()
                
            except Exception as e:
                logger.error(f"Ошибка при отправке реакции: {e}")
    
    async def _send_comments(
        self,
        client: TelegramClient,
        count: int,
        progress: WarmingProgress
    ):
        """Отправка комментариев"""
        logger.info(f"Отправляем {count} комментариев...")
        
        # Простые безопасные комментарии
        comments = [
            "Интересно!",
            "Спасибо за информацию",
            "Полезно",
            "Согласен",
            "Хорошая мысль",
            "👍",
            "Спасибо!",
            "Круто",
        ]
        
        for i in range(count):
            try:
                group = random.choice(self.warming_groups)
                messages = await client.get_messages(group, limit=20)
                
                if messages:
                    message = random.choice(messages)
                    comment = random.choice(comments)
                    
                    # Отправляем комментарий
                    await client.send_message(group, comment, reply_to=message.id)
                    progress.messages_sent += 1
                    logger.info(f"Отправили комментарий: {comment}")
                
                await self._random_sleep()
                
            except Exception as e:
                logger.error(f"Ошибка при отправке комментария: {e}")
    
    def _get_current_stage(self, days_passed: int) -> WarmingStage:
        """Определяет текущую стадию прогрева"""
        if days_passed < self.config.setup_days:
            return WarmingStage.SETUP
        elif days_passed < self.config.setup_days + self.config.passive_days:
            return WarmingStage.PASSIVE
        elif days_passed < self.config.setup_days + self.config.passive_days + self.config.active_days:
            return WarmingStage.ACTIVE
        else:
            return WarmingStage.READY
    
    def _is_working_hours(self) -> bool:
        """Проверяет, сейчас рабочие часы"""
        current_hour = datetime.utcnow().hour
        return self.config.work_hours_start <= current_hour < self.config.work_hours_end
    
    async def _random_sleep(self, min_seconds: int = None, max_seconds: int = None):
        """Случайная пауза"""
        min_s = min_seconds or self.config.min_delay
        max_s = max_seconds or self.config.max_delay
        sleep_time = random.randint(min_s, max_s)
        logger.debug(f"Спим {sleep_time} секунд...")
        await asyncio.sleep(sleep_time)


# Пример использования
async def main():
    """Тестовый пример"""
    from telethon import TelegramClient
    
    # Создаём клиент (замените на свои данные)
    api_id = 12345
    api_hash = "your_api_hash"
    phone = "+1234567890"
    
    client = TelegramClient(f"sessions/{phone}", api_id, api_hash)
    await client.start(phone=phone)
    
    # Запускаем прогрев
    warmer = AccountWarmer()
    progress = await warmer.start_warming(client, account_id=1, phone=phone)
    
    print(f"Прогрев завершён!")
    print(f"Групп вступлено: {progress.groups_joined}")
    print(f"Реакций отправлено: {progress.reactions_sent}")
    print(f"Сообщений отправлено: {progress.messages_sent}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())

    def simulate_human_activity(self, account_data: dict) -> dict:
        """
        Генерирует расписание человекоподобной активности
        
        Args:
            account_data: Данные аккаунта
            
        Returns:
            Расписание активности
        """
        schedule = {
            'morning': {
                'time_range': (8, 11),
                'actions': ['read_messages', 'send_reactions', 'join_group'],
                'probability': 0.7
            },
            'afternoon': {
                'time_range': (12, 17),
                'actions': ['send_messages', 'send_reactions', 'read_messages'],
                'probability': 0.5
            },
            'evening': {
                'time_range': (18, 23),
                'actions': ['send_messages', 'send_reactions', 'join_group', 'comment'],
                'probability': 0.8
            },
            'night': {
                'time_range': (0, 7),
                'actions': [],
                'probability': 0.1
            }
        }
        
        return schedule
    
    def check_warming_status(self, account_id: int, start_date: datetime) -> dict:
        """
        Проверяет статус прогрева аккаунта
        
        Args:
            account_id: ID аккаунта
            start_date: Дата начала прогрева
            
        Returns:
            Статус прогрева
        """
        days_passed = (datetime.utcnow() - start_date).days
        current_stage = self._get_current_stage(days_passed)
        
        total_days = (self.config.setup_days + 
                     self.config.passive_days + 
                     self.config.active_days)
        
        progress_percentage = min(100, (days_passed / total_days) * 100)
        
        status = {
            'account_id': account_id,
            'days_passed': days_passed,
            'current_stage': current_stage.value,
            'progress_percentage': round(progress_percentage, 1),
            'is_complete': days_passed >= total_days,
            'estimated_completion': start_date + timedelta(days=total_days),
            'next_stage': self._get_next_stage(current_stage),
            'recommendations': self._get_stage_recommendations(current_stage)
        }
        
        return status
    
    def get_warming_schedule(self, start_date: datetime) -> dict:
        """
        Возвращает полное расписание прогрева
        
        Args:
            start_date: Дата начала прогрева
            
        Returns:
            Детальное расписание по дням
        """
        schedule = {
            'start_date': start_date.isoformat(),
            'total_days': (self.config.setup_days + 
                          self.config.passive_days + 
                          self.config.active_days),
            'stages': []
        }
        
        current_day = 0
        
        # SETUP stage
        schedule['stages'].append({
            'name': 'SETUP',
            'days': f'{current_day + 1}-{current_day + self.config.setup_days}',
            'duration': self.config.setup_days,
            'activities': {
                'groups_per_day': self.config.setup_groups_per_day,
                'reactions_per_day': self.config.setup_reactions_per_day,
                'messages_per_day': self.config.setup_messages_per_day
            },
            'goals': [
                'Настройка профиля',
                'Вступление в популярные группы',
                'Минимальная активность'
            ]
        })
        current_day += self.config.setup_days
        
        # PASSIVE stage
        schedule['stages'].append({
            'name': 'PASSIVE',
            'days': f'{current_day + 1}-{current_day + self.config.passive_days}',
            'duration': self.config.passive_days,
            'activities': {
                'groups_per_day': self.config.passive_groups_per_day,
                'reactions_per_day': self.config.passive_reactions_per_day,
                'messages_per_day': self.config.passive_messages_per_day
            },
            'goals': [
                'Увеличение активности',
                'Первые комментарии',
                'Реакции на сообщения'
            ]
        })
        current_day += self.config.passive_days
        
        # ACTIVE stage
        schedule['stages'].append({
            'name': 'ACTIVE',
            'days': f'{current_day + 1}-{current_day + self.config.active_days}',
            'duration': self.config.active_days,
            'activities': {
                'groups_per_day': self.config.active_groups_per_day,
                'reactions_per_day': self.config.active_reactions_per_day,
                'messages_per_day': self.config.active_messages_per_day
            },
            'goals': [
                'Активное общение',
                'Начало диалогов',
                'Подготовка к инвайтам'
            ]
        })
        
        schedule['completion_date'] = (start_date + timedelta(days=schedule['total_days'])).isoformat()
        
        return schedule
    
    def _get_next_stage(self, current_stage: WarmingStage) -> Optional[str]:
        """Возвращает следующую стадию"""
        stages = [WarmingStage.SETUP, WarmingStage.PASSIVE, WarmingStage.ACTIVE, WarmingStage.READY]
        try:
            current_index = stages.index(current_stage)
            if current_index < len(stages) - 1:
                return stages[current_index + 1].value
        except ValueError:
            pass
        return None
    
    def _get_stage_recommendations(self, stage: WarmingStage) -> List[str]:
        """Возвращает рекомендации для текущей стадии"""
        recommendations = {
            WarmingStage.SETUP: [
                'Заполните профиль (фото, био)',
                'Вступайте только в популярные группы',
                'Не отправляйте сообщения',
                'Ставьте реакции на интересные посты'
            ],
            WarmingStage.PASSIVE: [
                'Увеличьте количество реакций',
                'Начните оставлять короткие комментарии',
                'Вступайте в тематические группы',
                'Читайте сообщения в группах'
            ],
            WarmingStage.ACTIVE: [
                'Активно общайтесь в группах',
                'Начните диалоги с пользователями',
                'Отправляйте 10+ сообщений в день',
                'Подготовьтесь к инвайтам'
            ],
            WarmingStage.READY: [
                'Начните отправлять инвайты (5-10/день)',
                'Продолжайте активность в группах',
                'Следите за лимитами',
                'Используйте прокси'
            ]
        }
        return recommendations.get(stage, [])
