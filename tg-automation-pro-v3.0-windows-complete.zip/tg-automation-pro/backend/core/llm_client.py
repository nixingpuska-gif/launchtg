"""
LLM Client - Integration with Ollama/Tabby/OpenAI-compatible APIs
"""
import os
import logging
import requests
import json
from typing import List, Dict, Optional
import random

logger = logging.getLogger(__name__)

class LLMClient:
    """Client for LLM API (Ollama, Tabby, or OpenAI-compatible)"""
    
    def __init__(self, api_url: str = None, api_key: str = None, model: str = None):
        self.api_url = api_url or os.getenv('LLM_API_URL', 'http://ollama:11434')
        self.api_key = api_key or os.getenv('LLM_API_KEY')
        self.model = model or os.getenv('LLM_MODEL', 'llama3.1:8b')
        self.temperature = float(os.getenv('LLM_TEMPERATURE', '0.7'))
        
        # Detect API type
        if 'ollama' in self.api_url:
            self.api_type = 'ollama'
        elif self.api_key:
            self.api_type = 'openai'
        else:
            self.api_type = 'ollama'
        
        logger.info(f"LLM Client initialized (type={self.api_type}, model={self.model})")
    
    def generate(self, prompt: str, max_tokens: int = 200, temperature: float = None) -> str:
        """Generate text from prompt"""
        temp = temperature if temperature is not None else self.temperature
        
        try:
            if self.api_type == 'ollama':
                return self._generate_ollama(prompt, max_tokens, temp)
            else:
                return self._generate_openai(prompt, max_tokens, temp)
        except Exception as e:
            logger.error(f"LLM generation failed: {e}")
            return self._fallback_generation(prompt)
    
    def _generate_ollama(self, prompt: str, max_tokens: int, temperature: float) -> str:
        """Generate using Ollama API"""
        url = f"{self.api_url}/api/generate"
        
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens
            }
        }
        
        response = requests.post(url, json=payload, timeout=30)
        response.raise_for_status()
        
        result = response.json()
        return result.get('response', '').strip()
    
    def _generate_openai(self, prompt: str, max_tokens: int, temperature: float) -> str:
        """Generate using OpenAI-compatible API"""
        url = f"{self.api_url}/v1/chat/completions"
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        
        response = requests.post(url, json=payload, headers=headers, timeout=30)
        response.raise_for_status()
        
        result = response.json()
        return result['choices'][0]['message']['content'].strip()
    
    def _fallback_generation(self, prompt: str) -> str:
        """Fallback generation when LLM is unavailable"""
        logger.warning("Using fallback generation")
        
        # Simple template-based fallback
        templates = [
            "Привет! Я заметил, что вы интересуетесь этой темой. Приглашаю вас в наш канал!",
            "Здравствуйте! У нас есть интересный канал по этой теме. Будем рады видеть вас!",
            "Добрый день! Думаю, вам будет интересен наш канал. Присоединяйтесь!",
            "Приветствую! Мы собрали сообщество по этой теме. Заходите к нам!",
        ]
        
        return random.choice(templates)
    
    # ============================================
    # SPECIALIZED GENERATION METHODS
    # ============================================
    
    def generate_invite_message(self, user_info: Dict, channel_info: Dict, 
                                context: str = None) -> str:
        """Generate personalized invite message"""
        
        first_name = user_info.get('first_name', 'друг')
        interests = user_info.get('interests', [])
        channel_name = channel_info.get('name', 'наш канал')
        channel_description = channel_info.get('description', 'интересный контент')
        
        prompt = f"""Сгенерируй короткое (2-3 предложения) персонализированное приглашение в Telegram-канал.

Информация о пользователе:
- Имя: {first_name}
- Интересы: {', '.join(interests) if interests else 'не указаны'}

Информация о канале:
- Название: {channel_name}
- Описание: {channel_description}

Требования:
- Дружелюбный тон
- Не использовать спам-слова
- Упомянуть релевантность для пользователя
- Максимум 200 символов
- Без эмодзи

Сгенерируй только текст сообщения, без дополнительных комментариев."""

        return self.generate(prompt, max_tokens=150, temperature=0.8)
    
    def generate_comment_reply(self, original_message: str, context: str = None) -> str:
        """Generate reply to comment"""
        
        prompt = f"""Сгенерируй естественный ответ на сообщение в Telegram-группе.

Исходное сообщение: "{original_message}"

Требования:
- Естественный разговорный стиль
- Релевантный ответ
- 1-2 предложения
- Без спама и рекламы
- Дружелюбный тон

Сгенерируй только текст ответа."""

        return self.generate(prompt, max_tokens=100, temperature=0.7)
    
    def generate_channel_post(self, topic: str, style: str = 'professional', 
                             length: str = 'medium') -> str:
        """Generate channel post"""
        
        length_map = {
            'short': '1-2 абзаца',
            'medium': '3-4 абзаца',
            'long': '5-7 абзацев'
        }
        
        prompt = f"""Напиши пост для Telegram-канала.

Тема: {topic}
Стиль: {style}
Длина: {length_map.get(length, 'medium')}

Требования:
- Структурированный текст
- Информативность
- Вовлекающий контент
- Без эмодзи (или минимум)

Сгенерируй только текст поста."""

        max_tokens_map = {'short': 200, 'medium': 400, 'long': 600}
        
        return self.generate(prompt, max_tokens=max_tokens_map.get(length, 400), temperature=0.7)
    
    def analyze_user_interests(self, user_messages: List[str]) -> List[str]:
        """Analyze user interests from messages"""
        
        if not user_messages:
            return []
        
        messages_text = '\n'.join(user_messages[:10])  # Limit to 10 messages
        
        prompt = f"""Проанализируй сообщения пользователя и определи его интересы.

Сообщения:
{messages_text}

Выведи список из 3-5 ключевых интересов (по одному слову/фразе на строку).
Только список, без нумерации и дополнительного текста."""

        result = self.generate(prompt, max_tokens=100, temperature=0.5)
        
        # Parse interests
        interests = [line.strip() for line in result.split('\n') if line.strip()]
        return interests[:5]
    
    def classify_message_sentiment(self, message: str) -> str:
        """Classify message sentiment"""
        
        prompt = f"""Определи тональность сообщения: positive, neutral, или negative.

Сообщение: "{message}"

Ответь одним словом: positive, neutral или negative."""

        result = self.generate(prompt, max_tokens=10, temperature=0.3)
        
        # Normalize result
        result_lower = result.lower().strip()
        
        if 'positive' in result_lower or 'позитив' in result_lower:
            return 'positive'
        elif 'negative' in result_lower or 'негатив' in result_lower:
            return 'negative'
        else:
            return 'neutral'
    
    def generate_group_description(self, group_name: str, sample_messages: List[str]) -> str:
        """Generate group description based on sample messages"""
        
        messages_text = '\n'.join(sample_messages[:20])
        
        prompt = f"""Проанализируй сообщения из Telegram-группы "{group_name}" и составь краткое описание (2-3 предложения) о чём эта группа.

Примеры сообщений:
{messages_text}

Сгенерируй только описание группы."""

        return self.generate(prompt, max_tokens=150, temperature=0.5)
    
    def check_health(self) -> bool:
        """Check if LLM service is available"""
        try:
            if self.api_type == 'ollama':
                response = requests.get(f"{self.api_url}/api/tags", timeout=5)
                return response.status_code == 200
            else:
                # For OpenAI-compatible APIs, try a simple generation
                self.generate("test", max_tokens=10)
                return True
        except Exception as e:
            logger.error(f"LLM health check failed: {e}")
            return False
