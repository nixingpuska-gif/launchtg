"""
Background Worker - Handles parsing and inviting tasks
"""
import os
import sys
import logging
import asyncio
import random
from datetime import datetime, timedelta
from typing import List, Dict

# Add parent directory to path
sys.path.insert(0, os.path.dirname(__file__))

from core.database import Database
from core.telegram_bot import TelegramBotEngine
from core.llm_client import LLMClient

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/app/logs/worker.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

class TelegramWorker:
    """Background worker for Telegram automation tasks"""
    
    def __init__(self):
        self.db = Database()
        self.llm = LLMClient()
        self.running = False
        
        # Load settings
        self.daily_invite_limit = self.db.get_setting('daily_invite_limit_per_account', 30)
        self.min_delay = self.db.get_setting('min_delay_between_invites', 60)
        self.max_delay = self.db.get_setting('max_delay_between_invites', 300)
        self.parsing_limit = self.db.get_setting('max_parsing_limit', 5000)
        
        logger.info("Worker initialized")
    
    async def run(self):
        """Main worker loop"""
        self.running = True
        logger.info("🚀 Worker started")
        
        while self.running:
            try:
                # Check for active campaigns
                campaigns = self.db.get_active_campaigns()
                
                for campaign in campaigns:
                    await self.process_campaign(campaign)
                
                # Sleep before next iteration
                await asyncio.sleep(60)  # Check every minute
                
            except KeyboardInterrupt:
                logger.info("Worker stopped by user")
                self.running = False
            except Exception as e:
                logger.error(f"Worker error: {e}")
                await asyncio.sleep(60)
    
    async def process_campaign(self, campaign: Dict):
        """Process campaign"""
        campaign_id = campaign['id']
        campaign_type = campaign['type']
        
        logger.info(f"Processing campaign {campaign_id} (type={campaign_type})")
        
        if campaign_type == 'parsing':
            await self.run_parsing_campaign(campaign)
        elif campaign_type == 'inviting':
            await self.run_inviting_campaign(campaign)
        elif campaign_type == 'combined':
            await self.run_parsing_campaign(campaign)
            await self.run_inviting_campaign(campaign)
    
    async def run_parsing_campaign(self, campaign: Dict):
        """Run parsing campaign"""
        campaign_id = campaign['id']
        target_groups = campaign.get('target_groups', [])
        
        if not target_groups:
            logger.warning(f"Campaign {campaign_id} has no target groups")
            return
        
        # Get available parser account
        account = self.db.get_available_account(role='parser')
        
        if not account:
            logger.warning("No available parser accounts")
            return
        
        # Get proxy
        proxy = self.db.get_proxy_for_account(account['id'])
        
        # Create bot engine
        bot = TelegramBotEngine(account, proxy)
        
        try:
            await bot.connect()
            
            for group_id in target_groups:
                group = self.db.fetchone("SELECT * FROM target_groups WHERE id = %s", (group_id,))
                
                if not group:
                    continue
                
                logger.info(f"Parsing group: {group['title']}")
                
                start_time = datetime.now()
                
                try:
                    # Parse members
                    members = await bot.parse_group_members(
                        group['username'] or group['telegram_id'],
                        limit=self.parsing_limit,
                        filters=campaign.get('filters', {})
                    )
                    
                    # Save to database
                    saved_count = 0
                    for member in members:
                        member['source_group_id'] = group_id
                        member['discovered_by_account_id'] = account['id']
                        
                        try:
                            self.db.save_parsed_user(member)
                            saved_count += 1
                        except Exception as e:
                            logger.error(f"Failed to save user: {e}")
                    
                    duration = (datetime.now() - start_time).total_seconds()
                    
                    # Log parsing
                    self.db.log_parsing(
                        account_id=account['id'],
                        group_id=group_id,
                        users_found=len(members),
                        users_saved=saved_count,
                        users_filtered=len(members) - saved_count,
                        duration_seconds=int(duration),
                        status='success'
                    )
                    
                    # Update group
                    self.db.update('target_groups', {
                        'last_parsed': datetime.now(),
                        'parse_count': group['parse_count'] + 1,
                        'total_users_parsed': group['total_users_parsed'] + saved_count
                    }, {'id': group_id})
                    
                    # Update account
                    self.db.increment_parse_count(account['id'])
                    
                    logger.info(f"✅ Parsed {saved_count} users from {group['title']}")
                    
                except Exception as e:
                    logger.error(f"Failed to parse group {group['title']}: {e}")
                    
                    self.db.log_parsing(
                        account_id=account['id'],
                        group_id=group_id,
                        users_found=0,
                        users_saved=0,
                        users_filtered=0,
                        duration_seconds=0,
                        status='failed',
                        error_type=type(e).__name__,
                        error_message=str(e)
                    )
                
                # Delay between groups
                await asyncio.sleep(random.uniform(30, 60))
        
        finally:
            await bot.disconnect()
    
    async def run_inviting_campaign(self, campaign: Dict):
        """Run inviting campaign"""
        campaign_id = campaign['id']
        target_channel = campaign.get('target_channel')
        
        if not target_channel:
            logger.warning(f"Campaign {campaign_id} has no target channel")
            return
        
        # Get users to invite
        min_activity_score = campaign.get('min_activity_score', 0.3)
        max_users = campaign.get('max_users', 100)
        
        users = self.db.get_users_to_invite(
            limit=max_users,
            min_activity_score=min_activity_score
        )
        
        if not users:
            logger.info("No users to invite")
            return
        
        logger.info(f"Found {len(users)} users to invite")
        
        # Get available inviter accounts
        accounts = self.db.fetchall("""
            SELECT * FROM telegram_accounts
            WHERE role IN ('inviter', 'universal')
            AND status = 'active'
            AND daily_invite_count < %s
            ORDER BY daily_invite_count ASC
        """, (self.daily_invite_limit,))
        
        if not accounts:
            logger.warning("No available inviter accounts")
            return
        
        # Distribute users across accounts
        account_index = 0
        
        for user in users:
            if account_index >= len(accounts):
                break
            
            account = accounts[account_index]
            
            # Check if account reached daily limit
            if account['daily_invite_count'] >= self.daily_invite_limit:
                account_index += 1
                if account_index >= len(accounts):
                    break
                account = accounts[account_index]
            
            # Get proxy
            proxy = self.db.get_proxy_for_account(account['id'])
            
            # Create bot engine
            bot = TelegramBotEngine(account, proxy)
            
            try:
                await bot.connect()
                
                # Generate invite message
                invite_message = None
                if self.db.get_setting('enable_llm_generation', True):
                    try:
                        invite_message = self.llm.generate_invite_message(
                            user_info=user,
                            channel_info={'name': target_channel, 'description': ''}
                        )
                    except Exception as e:
                        logger.error(f"LLM generation failed: {e}")
                
                if not invite_message:
                    invite_message = campaign.get('invite_message_template', '')
                
                # Invite user
                result = await bot.invite_user_to_channel(
                    user['username'] or user['telegram_id'],
                    target_channel,
                    message=invite_message
                )
                
                # Log invite
                self.db.log_invite(
                    account_id=account['id'],
                    user_id=user['id'],
                    target_channel=target_channel,
                    invite_message=invite_message,
                    status=result['status'],
                    error_code=result.get('error_code'),
                    error_message=result.get('error_message'),
                    flood_wait_seconds=result.get('flood_wait_seconds'),
                    response_time_ms=result.get('response_time_ms')
                )
                
                # Update user
                if result['status'] == 'success':
                    self.db.mark_user_invited(user['id'], invited=True)
                    self.db.increment_invite_count(account['id'])
                    
                    logger.info(f"✅ Invited {user['username'] or user['telegram_id']}")
                
                # Handle errors
                if result['status'] == 'flood_wait':
                    flood_wait = result.get('flood_wait_seconds', 3600)
                    self.db.update_account_status(account['id'], 'cooling', 
                                                 f"FloodWait: {flood_wait}s")
                    
                    # Create notification
                    self.db.create_notification(
                        level='WARNING',
                        title='FloodWait Error',
                        message=f"Account {account['phone']} in FloodWait for {flood_wait}s",
                        notification_type='flood_wait',
                        related_account_id=account['id']
                    )
                    
                    account_index += 1
                
                elif result['status'] == 'spam_ban':
                    self.db.update_account_status(account['id'], 'banned', 'Spam ban detected')
                    
                    # Create critical notification
                    self.db.create_notification(
                        level='CRITICAL',
                        title='Account Banned',
                        message=f"Account {account['phone']} has been banned (spam)",
                        notification_type='account_ban',
                        related_account_id=account['id']
                    )
                    
                    account_index += 1
                
                # Update campaign progress
                self.db.update_campaign_progress(
                    campaign_id,
                    users_processed=campaign['users_processed'] + 1,
                    users_invited=campaign['users_invited'] + (1 if result['status'] == 'success' else 0),
                    users_failed=campaign['users_failed'] + (1 if result['status'] != 'success' else 0)
                )
                
                # Random delay
                delay = random.uniform(self.min_delay, self.max_delay)
                logger.info(f"Waiting {int(delay)}s before next invite...")
                await asyncio.sleep(delay)
                
            except Exception as e:
                logger.error(f"Failed to invite user: {e}")
            finally:
                await bot.disconnect()
    
    def stop(self):
        """Stop worker"""
        self.running = False
        logger.info("Worker stopping...")

if __name__ == "__main__":
    worker = TelegramWorker()
    
    try:
        asyncio.run(worker.run())
    except KeyboardInterrupt:
        logger.info("Worker stopped by user")
    finally:
        worker.db.close()
