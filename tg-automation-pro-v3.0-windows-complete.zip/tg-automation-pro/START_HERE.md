# 🚀 НАЧНИТЕ ЗДЕСЬ - Telegram Automation Pro

## ⚡ Быстрый старт для Windows

### Шаг 1: Установите Docker Desktop

1. Скачайте Docker Desktop: https://www.docker.com/products/docker-desktop
2. Запустите установщик
3. Перезагрузите компьютер
4. Запустите Docker Desktop из меню Пуск
5. Дождитесь, пока иконка Docker в трее станет зелёной

### Шаг 2: Запустите установщик

1. Найдите файл **SETUP.bat** в папке проекта
2. Щёлкните правой кнопкой на **SETUP.bat**
3. Выберите **"Запуск от имени администратора"**
4. Следуйте инструкциям на экране

### Шаг 3: Откройте веб-панель

Откройте в браузере: **http://localhost:3000**

**Логин:** admin  
**Пароль:** admin123

---

## 📋 Если SETUP.bat не работает

### Вариант 1: Ручная установка

Откройте **PowerShell** в папке проекта и выполните:

```powershell
# 1. Создать директории
New-Item -ItemType Directory -Force logs, sessions, backups

# 2. Скопировать .env
Copy-Item .env.example .env

# 3. Собрать образы
docker compose build

# 4. Запустить сервисы
docker compose up -d

# 5. Подождать 15 секунд
Start-Sleep -Seconds 15

# 6. Создать администратора
docker exec tg_automation_db psql -U postgres -d telegram_automation -c "INSERT INTO admin_users (username, email, password_hash, is_active) VALUES ('admin', 'admin@example.com', '\`$2b\`$12\`$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5NU7TUQ9aqQ/i', TRUE);"

# 7. Открыть в браузере
Start-Process http://localhost:3000
```

### Вариант 2: Через Docker Desktop GUI

1. Откройте Docker Desktop
2. Перейдите в папку проекта в проводнике
3. Откройте PowerShell (Shift + правая кнопка → "Открыть окно PowerShell здесь")
4. Выполните: `docker compose up -d`
5. Откройте http://localhost:3000

---

## ⚙️ Настройка Telegram API

### Получение API credentials:

1. Откройте: https://my.telegram.org
2. Войдите с вашим номером телефона
3. Перейдите в "API development tools"
4. Создайте приложение
5. Скопируйте **API ID** и **API Hash**

### Добавление в проект:

1. Откройте файл **.env** в Блокноте
2. Найдите строки:
   ```
   TELEGRAM_API_ID=your_api_id_here
   TELEGRAM_API_HASH=your_api_hash_here
   ```
3. Замените на ваши значения:
   ```
   TELEGRAM_API_ID=12345678
   TELEGRAM_API_HASH=abcdef1234567890abcdef1234567890
   ```
4. Сохраните файл
5. Перезапустите сервисы:
   ```
   docker compose restart
   ```

---

## 🔧 Управление системой

### Просмотр логов
```powershell
docker compose logs -f
```

### Остановка
```powershell
docker compose down
```

### Запуск
```powershell
docker compose up -d
```

### Перезапуск
```powershell
docker compose restart
```

### Статус сервисов
```powershell
docker compose ps
```

---

## ❓ Решение проблем

### "Docker не найден"
**Решение:** Установите Docker Desktop (см. Шаг 1)

### "Docker Desktop не запущен"
**Решение:** 
1. Запустите Docker Desktop из меню Пуск
2. Дождитесь зелёной иконки в трее
3. Запустите SETUP.bat снова

### "Порт 3000 уже занят"
**Решение:** Измените порт в `docker-compose.yml`:
```yaml
frontend:
  ports:
    - "3001:80"  # Вместо 3000
```

### "Access denied"
**Решение:** Запустите SETUP.bat **от имени администратора**

### "Не могу войти в веб-панель"
**Решение:**
1. Проверьте что все сервисы запущены: `docker compose ps`
2. Проверьте логи: `docker compose logs backend`
3. Попробуйте пересоздать администратора (см. Вариант 1, шаг 6)

---

## 📚 Дополнительная документация

- **README.md** - Полное описание системы
- **WINDOWS_INSTALL.md** - Подробное руководство для Windows
- **INSTALLATION.md** - Руководство по установке
- **QUICKSTART.md** - Быстрый старт

---

## 🎯 Следующие шаги после установки

1. ✅ Войдите в веб-панель
2. ✅ Смените пароль администратора
3. ✅ Добавьте Telegram API credentials в .env
4. ✅ Создайте Telegram сессию
5. ✅ Добавьте целевые группы для парсинга
6. ✅ Создайте первую кампанию
7. ✅ Запустите парсинг
8. ✅ Запустите инвайтинг

---

## 💡 Полезные советы

### Где хранятся данные?
- **База данных:** Docker volume `postgres_data`
- **Логи:** `./logs/`
- **Сессии Telegram:** `./sessions/`
- **Бэкапы:** `./backups/`

### Как сделать бэкап?
```powershell
# Бэкап базы данных
docker exec tg_automation_db pg_dump -U postgres telegram_automation > backup.sql

# Бэкап сессий
Copy-Item -Recurse sessions backups\sessions_$(Get-Date -Format 'yyyyMMdd')
```

### Как обновить систему?
```powershell
docker compose down
docker compose pull
docker compose build
docker compose up -d
```

---

## 🆘 Нужна помощь?

1. Проверьте логи: `docker compose logs -f`
2. Проверьте статус: `docker compose ps`
3. Прочитайте документацию в папке проекта
4. Создайте issue на GitHub с описанием проблемы

---

## ✅ Чек-лист успешной установки

- [ ] Docker Desktop установлен и запущен
- [ ] SETUP.bat выполнен без ошибок
- [ ] Все сервисы запущены (проверить: `docker compose ps`)
- [ ] Веб-панель открывается (http://localhost:3000)
- [ ] Вход выполнен успешно
- [ ] Пароль администратора изменён
- [ ] Telegram API добавлены в .env
- [ ] Сервисы перезапущены после добавления API

---

**Версия:** 1.2.1  
**Дата:** 2024-11-20  
**Платформа:** Windows 10/11

🎉 **Готово! Теперь вы можете начать использовать Telegram Automation Pro!**
