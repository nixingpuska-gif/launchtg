"""Sentiment Analysis - анализ тональности сообщений"""
