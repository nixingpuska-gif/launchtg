"""
Database Module - Production-ready PostgreSQL integration
"""
import os
import logging
from datetime import datetime
from typing import List, Dict, Optional, Any
from contextlib import contextmanager

import psycopg2
from psycopg2.extras import RealDictCursor, execute_values
from psycopg2.pool import ThreadedConnectionPool

logger = logging.getLogger(__name__)

class Database:
    """Thread-safe PostgreSQL database manager with connection pooling"""
    
    def __init__(self, database_url: str = None, min_conn: int = 2, max_conn: int = 20):
        self.database_url = database_url or os.getenv('DATABASE_URL')
        if not self.database_url:
            raise ValueError("DATABASE_URL not provided")
        
        try:
            self.pool = ThreadedConnectionPool(
                min_conn,
                max_conn,
                self.database_url
            )
            logger.info(f"Database pool created (min={min_conn}, max={max_conn})")
        except Exception as e:
            logger.error(f"Failed to create database pool: {e}")
            raise
    
    @contextmanager
    def get_connection(self):
        """Get connection from pool"""
        conn = self.pool.getconn()
        try:
            yield conn
        finally:
            self.pool.putconn(conn)
    
    @contextmanager
    def get_cursor(self, cursor_factory=RealDictCursor):
        """Get cursor with automatic connection management"""
        with self.get_connection() as conn:
            cursor = conn.cursor(cursor_factory=cursor_factory)
            try:
                yield cursor
                conn.commit()
            except Exception as e:
                conn.rollback()
                logger.error(f"Database error: {e}")
                raise
            finally:
                cursor.close()
    
    def execute(self, query: str, params: tuple = None) -> None:
        """Execute query without returning results"""
        with self.get_cursor() as cursor:
            cursor.execute(query, params)
    
    def fetchone(self, query: str, params: tuple = None) -> Optional[Dict]:
        """Fetch single row"""
        with self.get_cursor() as cursor:
            cursor.execute(query, params)
            return cursor.fetchone()
    
    def fetchall(self, query: str, params: tuple = None) -> List[Dict]:
        """Fetch all rows"""
        with self.get_cursor() as cursor:
            cursor.execute(query, params)
            return cursor.fetchall()
    
    def insert(self, table: str, data: Dict) -> int:
        """Insert row and return ID"""
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['%s'] * len(data))
        query = f"INSERT INTO {table} ({columns}) VALUES ({placeholders}) RETURNING id"
        
        with self.get_cursor() as cursor:
            cursor.execute(query, tuple(data.values()))
            result = cursor.fetchone()
            return result['id'] if result else None
    
    def bulk_insert(self, table: str, data: List[Dict]) -> int:
        """Bulk insert rows"""
        if not data:
            return 0
        
        columns = data[0].keys()
        query = f"INSERT INTO {table} ({', '.join(columns)}) VALUES %s ON CONFLICT DO NOTHING"
        
        with self.get_cursor() as cursor:
            values = [tuple(row[col] for col in columns) for row in data]
            execute_values(cursor, query, values)
            return cursor.rowcount
    
    def update(self, table: str, data: Dict, where: Dict) -> int:
        """Update rows"""
        set_clause = ', '.join([f"{k} = %s" for k in data.keys()])
        where_clause = ' AND '.join([f"{k} = %s" for k in where.keys()])
        query = f"UPDATE {table} SET {set_clause} WHERE {where_clause}"
        
        with self.get_cursor() as cursor:
            cursor.execute(query, tuple(data.values()) + tuple(where.values()))
            return cursor.rowcount
    
    def delete(self, table: str, where: Dict) -> int:
        """Delete rows"""
        where_clause = ' AND '.join([f"{k} = %s" for k in where.keys()])
        query = f"DELETE FROM {table} WHERE {where_clause}"
        
        with self.get_cursor() as cursor:
            cursor.execute(query, tuple(where.values()))
            return cursor.rowcount
    
    # ============================================
    # TELEGRAM ACCOUNTS
    # ============================================
    
    def get_available_account(self, role: str = None) -> Optional[Dict]:
        """Get available account for work"""
        query = """
            SELECT * FROM telegram_accounts
            WHERE status = 'active'
            AND (daily_invite_count < (SELECT value::int FROM settings WHERE key = 'daily_invite_limit_per_account'))
        """
        
        if role:
            query += f" AND role = '{role}'"
        
        query += " ORDER BY daily_invite_count ASC, last_activity ASC NULLS FIRST LIMIT 1"
        
        return self.fetchone(query)
    
    def get_account_by_id(self, account_id: int) -> Optional[Dict]:
        """Get account by ID"""
        return self.fetchone("SELECT * FROM telegram_accounts WHERE id = %s", (account_id,))
    
    def get_account_by_phone(self, phone: str) -> Optional[Dict]:
        """Get account by phone"""
        return self.fetchone("SELECT * FROM telegram_accounts WHERE phone = %s", (phone,))
    
    def update_account_status(self, account_id: int, status: str, error_msg: str = None):
        """Update account status"""
        data = {'status': status, 'last_activity': datetime.now()}
        
        if error_msg:
            self.log_system('WARNING', 'account_manager', f"Account {account_id} status changed to {status}: {error_msg}", 
                          account_id=account_id)
        
        self.update('telegram_accounts', data, {'id': account_id})
    
    def increment_invite_count(self, account_id: int):
        """Increment daily invite counter"""
        query = """
            UPDATE telegram_accounts 
            SET daily_invite_count = daily_invite_count + 1,
                total_invites = total_invites + 1,
                last_invite_at = NOW(),
                last_activity = NOW()
            WHERE id = %s
        """
        self.execute(query, (account_id,))
    
    def increment_parse_count(self, account_id: int):
        """Increment daily parse counter"""
        query = """
            UPDATE telegram_accounts 
            SET daily_parse_count = daily_parse_count + 1,
                total_parses = total_parses + 1,
                last_parse_at = NOW(),
                last_activity = NOW()
            WHERE id = %s
        """
        self.execute(query, (account_id,))
    
    # ============================================
    # TARGET GROUPS
    # ============================================
    
    def get_target_groups(self, limit: int = 100, active_only: bool = True) -> List[Dict]:
        """Get target groups"""
        query = "SELECT * FROM target_groups"
        
        if active_only:
            query += " WHERE is_active = TRUE"
        
        query += " ORDER BY relevance_score DESC, quality_score DESC LIMIT %s"
        
        return self.fetchall(query, (limit,))
    
    def save_target_group(self, telegram_id: int, title: str, username: str = None, 
                         member_count: int = 0, relevance_score: float = 0.5) -> int:
        """Save or update target group"""
        existing = self.fetchone("SELECT id FROM target_groups WHERE telegram_id = %s", (telegram_id,))
        
        if existing:
            self.update('target_groups', {
                'title': title,
                'username': username,
                'member_count': member_count,
                'relevance_score': relevance_score
            }, {'id': existing['id']})
            return existing['id']
        else:
            return self.insert('target_groups', {
                'telegram_id': telegram_id,
                'title': title,
                'username': username,
                'member_count': member_count,
                'relevance_score': relevance_score
            })
    
    def update_group_metrics(self, group_id: int, member_count: int = None, 
                            messages_per_day: float = None, bot_percentage: float = None):
        """Update group metrics"""
        data = {}
        if member_count is not None:
            data['member_count'] = member_count
        if messages_per_day is not None:
            data['messages_per_day'] = messages_per_day
        if bot_percentage is not None:
            data['bot_percentage'] = bot_percentage
        
        if data:
            self.update('target_groups', data, {'id': group_id})
    
    # ============================================
    # PARSED USERS
    # ============================================
    
    def save_parsed_user(self, user_data: Dict) -> int:
        """Save or update parsed user"""
        telegram_id = user_data.get('telegram_id')
        
        existing = self.fetchone("SELECT id FROM parsed_users WHERE telegram_id = %s", (telegram_id,))
        
        if existing:
            # Update existing user
            update_data = {k: v for k, v in user_data.items() if k != 'telegram_id'}
            self.update('parsed_users', update_data, {'id': existing['id']})
            return existing['id']
        else:
            # Insert new user
            return self.insert('parsed_users', user_data)
    
    def get_users_to_invite(self, limit: int = 100, min_activity_score: float = 0.3) -> List[Dict]:
        """Get users ready for inviting"""
        query = """
            SELECT * FROM parsed_users
            WHERE is_invited = FALSE
            AND is_bot = FALSE
            AND is_banned = FALSE
            AND is_private = FALSE
            AND activity_score >= %s
            ORDER BY activity_score DESC, created_at DESC
            LIMIT %s
        """
        return self.fetchall(query, (min_activity_score, limit))
    
    def mark_user_invited(self, user_id: int, invited: bool = True):
        """Mark user as invited"""
        self.update('parsed_users', {
            'is_invited': invited,
            'invited_at': datetime.now() if invited else None
        }, {'id': user_id})
    
    # ============================================
    # INVITE LOGS
    # ============================================
    
    def log_invite(self, account_id: int, user_id: int, target_channel: str,
                   invite_message: str, status: str, error_code: str = None,
                   error_message: str = None, flood_wait_seconds: int = None,
                   response_time_ms: int = None) -> int:
        """Log invite attempt"""
        return self.insert('invite_logs', {
            'account_id': account_id,
            'user_id': user_id,
            'target_channel': target_channel,
            'invite_message': invite_message,
            'status': status,
            'error_code': error_code,
            'error_message': error_message,
            'flood_wait_seconds': flood_wait_seconds,
            'response_time_ms': response_time_ms
        })
    
    # ============================================
    # PARSING LOGS
    # ============================================
    
    def log_parsing(self, account_id: int, group_id: int, users_found: int,
                   users_saved: int, users_filtered: int, duration_seconds: int,
                   status: str, error_type: str = None, error_message: str = None) -> int:
        """Log parsing operation"""
        return self.insert('parsing_logs', {
            'account_id': account_id,
            'group_id': group_id,
            'users_found': users_found,
            'users_saved': users_saved,
            'users_filtered': users_filtered,
            'duration_seconds': duration_seconds,
            'status': status,
            'error_type': error_type,
            'error_message': error_message,
            'completed_at': datetime.now()
        })
    
    # ============================================
    # SYSTEM LOGS
    # ============================================
    
    def log_system(self, level: str, module: str, message: str, 
                   details: Dict = None, account_id: int = None, user_id: int = None):
        """Log system event"""
        import json
        
        self.insert('system_logs', {
            'level': level,
            'module': module,
            'message': message,
            'details': json.dumps(details) if details else None,
            'account_id': account_id,
            'user_id': user_id
        })
    
    # ============================================
    # NOTIFICATIONS
    # ============================================
    
    def create_notification(self, level: str, title: str, message: str,
                           notification_type: str = None, related_account_id: int = None,
                           related_campaign_id: int = None) -> int:
        """Create notification"""
        return self.insert('notifications', {
            'level': level,
            'title': title,
            'message': message,
            'type': notification_type,
            'related_account_id': related_account_id,
            'related_campaign_id': related_campaign_id
        })
    
    # ============================================
    # SETTINGS
    # ============================================
    
    def get_setting(self, key: str, default: Any = None) -> Any:
        """Get setting value"""
        result = self.fetchone("SELECT value, value_type FROM settings WHERE key = %s", (key,))
        
        if not result:
            return default
        
        value = result['value']
        value_type = result['value_type']
        
        # Type conversion
        if value_type == 'integer':
            return int(value)
        elif value_type == 'float':
            return float(value)
        elif value_type == 'boolean':
            return value.lower() in ('true', '1', 'yes')
        elif value_type == 'json':
            import json
            return json.loads(value)
        else:
            return value
    
    def set_setting(self, key: str, value: Any):
        """Set setting value"""
        self.update('settings', {
            'value': str(value),
            'updated_at': datetime.now()
        }, {'key': key})
    
    # ============================================
    # PROXIES
    # ============================================
    
    def get_proxy_for_account(self, account_id: int) -> Optional[Dict]:
        """Get proxy for account"""
        query = """
            SELECT p.* FROM proxies p
            JOIN telegram_accounts ta ON ta.proxy_id = p.id
            WHERE ta.id = %s AND p.status = 'active'
        """
        return self.fetchone(query, (account_id,))
    
    def get_available_proxy(self, country: str = None) -> Optional[Dict]:
        """Get available proxy"""
        query = "SELECT * FROM proxies WHERE status = 'active'"
        
        if country:
            query += f" AND country = '{country}'"
        
        query += " ORDER BY last_checked ASC NULLS FIRST LIMIT 1"
        
        return self.fetchone(query)
    
    # ============================================
    # CAMPAIGNS
    # ============================================
    
    def get_campaign(self, campaign_id: int) -> Optional[Dict]:
        """Get campaign by ID"""
        return self.fetchone("SELECT * FROM campaigns WHERE id = %s", (campaign_id,))
    
    def get_active_campaigns(self) -> List[Dict]:
        """Get active campaigns"""
        return self.fetchall("SELECT * FROM campaigns WHERE status IN ('running', 'scheduled') ORDER BY created_at DESC")
    
    def update_campaign_progress(self, campaign_id: int, users_processed: int = None,
                                 users_invited: int = None, users_failed: int = None):
        """Update campaign progress"""
        data = {}
        if users_processed is not None:
            data['users_processed'] = users_processed
        if users_invited is not None:
            data['users_invited'] = users_invited
        if users_failed is not None:
            data['users_failed'] = users_failed
        
        if data:
            self.update('campaigns', data, {'id': campaign_id})
    
    def close(self):
        """Close all connections"""
        if self.pool:
            self.pool.closeall()
            logger.info("Database pool closed")
