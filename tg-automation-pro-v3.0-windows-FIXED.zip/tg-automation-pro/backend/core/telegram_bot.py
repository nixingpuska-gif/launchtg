"""
Telegram Bot Engine - Multi-account manager with parsing and inviting
"""
import os
import logging
import asyncio
import random
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from pathlib import Path

from telethon import TelegramClient, errors, functions, types
from telethon.tl.functions.channels import InviteToChannelRequest, GetParticipantsRequest
from telethon.tl.types import ChannelParticipantsSearch, InputPeerChannel

logger = logging.getLogger(__name__)

class TelegramBotEngine:
    """Multi-account Telegram bot engine"""
    
    def __init__(self, account_data: Dict, proxy: Dict = None):
        self.account_id = account_data['id']
        self.phone = account_data['phone']
        self.api_id = account_data['api_id']
        self.api_hash = account_data['api_hash']
        self.session_file = account_data['session_file']
        
        # Setup proxy
        self.proxy = None
        if proxy:
            self.proxy = {
                'proxy_type': proxy['type'],
                'addr': proxy['host'],
                'port': proxy['port'],
                'username': proxy.get('username'),
                'password': proxy.get('password')
            }
        
        # Create client
        self.client = TelegramClient(
            self.session_file,
            self.api_id,
            self.api_hash,
            proxy=self.proxy
        )
        
        self.is_connected = False
        logger.info(f"Bot engine initialized for account {self.phone}")
    
    async def connect(self):
        """Connect to Telegram"""
        try:
            await self.client.connect()
            
            if not await self.client.is_user_authorized():
                logger.error(f"Account {self.phone} is not authorized")
                return False
            
            self.is_connected = True
            logger.info(f"Account {self.phone} connected successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect account {self.phone}: {e}")
            return False
    
    async def disconnect(self):
        """Disconnect from Telegram"""
        if self.is_connected:
            await self.client.disconnect()
            self.is_connected = False
            logger.info(f"Account {self.phone} disconnected")
    
    # ============================================
    # PARSING METHODS
    # ============================================
    
    async def parse_group_members(self, group_identifier: str, limit: int = 5000,
                                  filters: Dict = None) -> List[Dict]:
        """Parse members from group/channel"""
        
        if not self.is_connected:
            await self.connect()
        
        try:
            # Get group entity
            group = await self.client.get_entity(group_identifier)
            
            logger.info(f"Parsing group: {group.title} (ID: {group.id})")
            
            members = []
            offset = 0
            batch_size = 100
            
            while len(members) < limit:
                try:
                    # Fetch participants
                    participants = await self.client(GetParticipantsRequest(
                        channel=group,
                        filter=ChannelParticipantsSearch(''),
                        offset=offset,
                        limit=batch_size,
                        hash=0
                    ))
                    
                    if not participants.users:
                        break
                    
                    for user in participants.users:
                        # Apply filters
                        if self._should_include_user(user, filters):
                            user_data = self._extract_user_data(user)
                            members.append(user_data)
                    
                    offset += len(participants.users)
                    
                    # Random delay to avoid flood
                    await asyncio.sleep(random.uniform(1, 3))
                    
                    if len(participants.users) < batch_size:
                        break
                        
                except errors.FloodWaitError as e:
                    logger.warning(f"FloodWait: {e.seconds} seconds")
                    raise
                except Exception as e:
                    logger.error(f"Error fetching batch: {e}")
                    break
            
            logger.info(f"Parsed {len(members)} members from {group.title}")
            return members
            
        except errors.FloodWaitError:
            raise
        except Exception as e:
            logger.error(f"Failed to parse group {group_identifier}: {e}")
            raise
    
    def _should_include_user(self, user, filters: Dict = None) -> bool:
        """Check if user should be included based on filters"""
        
        # Default filters
        if user.bot:
            return False
        
        if user.deleted:
            return False
        
        # Custom filters
        if filters:
            if filters.get('exclude_bots', True) and user.bot:
                return False
            
            if filters.get('exclude_private', True) and not user.username:
                return False
            
            if filters.get('require_photo', False) and not user.photo:
                return False
        
        return True
    
    def _extract_user_data(self, user) -> Dict:
        """Extract user data from Telethon user object"""
        return {
            'telegram_id': user.id,
            'username': user.username,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'phone': user.phone if hasattr(user, 'phone') else None,
            'is_bot': user.bot,
            'is_premium': user.premium if hasattr(user, 'premium') else False,
            'is_verified': user.verified if hasattr(user, 'verified') else False,
            'is_scam': user.scam if hasattr(user, 'scam') else False,
            'is_fake': user.fake if hasattr(user, 'fake') else False,
            'has_photo': user.photo is not None,
            'last_seen': self._get_last_seen(user)
        }
    
    def _get_last_seen(self, user) -> Optional[datetime]:
        """Get user's last seen time"""
        if hasattr(user, 'status'):
            if isinstance(user.status, types.UserStatusOnline):
                return datetime.now()
            elif isinstance(user.status, types.UserStatusOffline):
                return user.status.was_online
            elif isinstance(user.status, types.UserStatusRecently):
                return datetime.now() - timedelta(days=1)
            elif isinstance(user.status, types.UserStatusLastWeek):
                return datetime.now() - timedelta(days=7)
            elif isinstance(user.status, types.UserStatusLastMonth):
                return datetime.now() - timedelta(days=30)
        
        return None
    
    # ============================================
    # INVITING METHODS
    # ============================================
    
    async def invite_user_to_channel(self, user_identifier: str, channel_identifier: str,
                                     message: str = None) -> Dict:
        """Invite user to channel"""
        
        if not self.is_connected:
            await self.connect()
        
        start_time = datetime.now()
        
        try:
            # Get entities
            user = await self.client.get_entity(user_identifier)
            channel = await self.client.get_entity(channel_identifier)
            
            # Send invite
            await self.client(InviteToChannelRequest(
                channel=channel,
                users=[user]
            ))
            
            # Send optional message
            if message:
                try:
                    await self.client.send_message(user, message)
                except Exception as e:
                    logger.warning(f"Failed to send message to {user_identifier}: {e}")
            
            response_time = (datetime.now() - start_time).total_seconds() * 1000
            
            logger.info(f"Successfully invited {user_identifier} to {channel_identifier}")
            
            return {
                'status': 'success',
                'response_time_ms': int(response_time)
            }
            
        except errors.FloodWaitError as e:
            logger.warning(f"FloodWait: {e.seconds} seconds")
            return {
                'status': 'flood_wait',
                'error_code': 'FLOOD_WAIT',
                'error_message': str(e),
                'flood_wait_seconds': e.seconds
            }
        
        except errors.UserPrivacyRestrictedError:
            return {
                'status': 'privacy_error',
                'error_code': 'USER_PRIVACY_RESTRICTED',
                'error_message': 'User privacy settings prevent invite'
            }
        
        except errors.PeerFloodError:
            logger.error(f"PeerFlood error for account {self.phone}")
            return {
                'status': 'spam_ban',
                'error_code': 'PEER_FLOOD',
                'error_message': 'Too many requests, account may be limited'
            }
        
        except errors.UserBannedInChannelError:
            return {
                'status': 'user_banned',
                'error_code': 'USER_BANNED_IN_CHANNEL',
                'error_message': 'User is banned in the channel'
            }
        
        except errors.UserChannelsTooMuchError:
            return {
                'status': 'user_channels_too_much',
                'error_code': 'USER_CHANNELS_TOO_MUCH',
                'error_message': 'User is in too many channels'
            }
        
        except errors.UserNotMutualContactError:
            return {
                'status': 'user_not_mutual',
                'error_code': 'USER_NOT_MUTUAL_CONTACT',
                'error_message': 'User is not a mutual contact'
            }
        
        except errors.BotGroupsBlockedError:
            return {
                'status': 'bot_groups_blocked',
                'error_code': 'BOT_GROUPS_BLOCKED',
                'error_message': 'User has blocked bots from adding to groups'
            }
        
        except Exception as e:
            logger.error(f"Failed to invite {user_identifier}: {e}")
            return {
                'status': 'failed',
                'error_code': type(e).__name__,
                'error_message': str(e)
            }
    
    # ============================================
    # COMMUNICATION METHODS
    # ============================================
    
    async def send_message(self, recipient: str, message: str) -> bool:
        """Send message to user/group"""
        
        if not self.is_connected:
            await self.connect()
        
        try:
            await self.client.send_message(recipient, message)
            logger.info(f"Message sent to {recipient}")
            return True
        except Exception as e:
            logger.error(f"Failed to send message to {recipient}: {e}")
            return False
    
    async def get_recent_messages(self, chat_identifier: str, limit: int = 100) -> List[Dict]:
        """Get recent messages from chat"""
        
        if not self.is_connected:
            await self.connect()
        
        try:
            messages = []
            async for message in self.client.iter_messages(chat_identifier, limit=limit):
                messages.append({
                    'id': message.id,
                    'text': message.text,
                    'sender_id': message.sender_id,
                    'date': message.date
                })
            
            return messages
        except Exception as e:
            logger.error(f"Failed to get messages from {chat_identifier}: {e}")
            return []
    
    # ============================================
    # UTILITY METHODS
    # ============================================
    
    async def get_me(self) -> Optional[Dict]:
        """Get current account info"""
        
        if not self.is_connected:
            await self.connect()
        
        try:
            me = await self.client.get_me()
            return {
                'id': me.id,
                'first_name': me.first_name,
                'last_name': me.last_name,
                'username': me.username,
                'phone': me.phone,
                'is_premium': me.premium if hasattr(me, 'premium') else False
            }
        except Exception as e:
            logger.error(f"Failed to get account info: {e}")
            return None
    
    async def check_flood_wait(self) -> Optional[int]:
        """Check if account is in flood wait"""
        # This is a placeholder - actual implementation would track flood waits
        return None
    
    @staticmethod
    async def create_session(phone: str, api_id: int, api_hash: str, 
                            session_path: str) -> bool:
        """Create new Telegram session"""
        
        client = TelegramClient(session_path, api_id, api_hash)
        
        try:
            await client.connect()
            
            if not await client.is_user_authorized():
                await client.send_code_request(phone)
                logger.info(f"Code sent to {phone}")
                
                # This would need to be handled interactively
                # For production, implement a callback mechanism
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to create session for {phone}: {e}")
            return False
        finally:
            await client.disconnect()
