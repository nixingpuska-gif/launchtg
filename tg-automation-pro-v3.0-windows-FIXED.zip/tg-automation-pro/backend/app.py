"""
Flask API Server - Web panel backend with REST API and WebSocket
"""
import os
import sys
import logging
from datetime import datetime, timedelta
from functools import wraps

from flask import Flask, request, jsonify, session
from flask_cors import CORS
from flask_socketio import SocketIO, emit
import bcrypt
import jwt

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))

from core.database import Database
from core.llm_client import LLMClient

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/app/logs/api.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your_secret_key_here')
app.config['SESSION_COOKIE_SECURE'] = os.getenv('SESSION_COOKIE_SECURE', 'false').lower() == 'true'
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

# CORS
CORS(app, origins=os.getenv('CORS_ORIGINS', 'http://localhost:3000').split(','))

# SocketIO
socketio = SocketIO(app, cors_allowed_origins="*")

# Database
db = Database()

# LLM
llm = LLMClient()

# ============================================
# AUTH UTILITIES
# ============================================

def generate_token(user_id: int, username: str) -> str:
    """Generate JWT token"""
    payload = {
        'user_id': user_id,
        'username': username,
        'exp': datetime.utcnow() + timedelta(days=7)
    }
    return jwt.encode(payload, app.config['SECRET_KEY'], algorithm='HS256')

def verify_token(token: str) -> dict:
    """Verify JWT token"""
    try:
        return jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

def token_required(f):
    """Decorator for protected routes"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({'error': 'Token is missing'}), 401
        
        if token.startswith('Bearer '):
            token = token[7:]
        
        payload = verify_token(token)
        
        if not payload:
            return jsonify({'error': 'Token is invalid or expired'}), 401
        
        request.user = payload
        return f(*args, **kwargs)
    
    return decorated

# ============================================
# AUTH ROUTES
# ============================================

@app.route('/api/auth/login', methods=['POST'])
def login():
    """Login endpoint"""
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    
    user = db.fetchone("SELECT * FROM admin_users WHERE username = %s AND is_active = TRUE", (username,))
    
    if not user:
        return jsonify({'error': 'Invalid credentials'}), 401
    
    # Verify password
    if not bcrypt.checkpw(password.encode('utf-8'), user['password_hash'].encode('utf-8')):
        return jsonify({'error': 'Invalid credentials'}), 401
    
    # Update last login
    db.execute("UPDATE admin_users SET last_login = NOW() WHERE id = %s", (user['id'],))
    
    # Generate token
    token = generate_token(user['id'], user['username'])
    
    return jsonify({
        'token': token,
        'user': {
            'id': user['id'],
            'username': user['username'],
            'email': user['email']
        }
    })

@app.route('/api/auth/me', methods=['GET'])
@token_required
def get_current_user():
    """Get current user info"""
    user = db.fetchone("SELECT id, username, email FROM admin_users WHERE id = %s", (request.user['user_id'],))
    return jsonify(user)

# ============================================
# DASHBOARD ROUTES
# ============================================

@app.route('/api/dashboard/stats', methods=['GET'])
@token_required
def get_dashboard_stats():
    """Get dashboard statistics"""
    
    # Total accounts
    total_accounts = db.fetchone("SELECT COUNT(*) as count FROM telegram_accounts")['count']
    active_accounts = db.fetchone("SELECT COUNT(*) as count FROM telegram_accounts WHERE status = 'active'")['count']
    
    # Total users
    total_users = db.fetchone("SELECT COUNT(*) as count FROM parsed_users")['count']
    invited_users = db.fetchone("SELECT COUNT(*) as count FROM parsed_users WHERE is_invited = TRUE")['count']
    
    # Today's stats
    today_invites = db.fetchone("""
        SELECT COUNT(*) as count FROM invite_logs 
        WHERE DATE(created_at) = CURRENT_DATE AND status = 'success'
    """)['count']
    
    today_parses = db.fetchone("""
        SELECT COALESCE(SUM(users_saved), 0) as count FROM parsing_logs 
        WHERE DATE(started_at) = CURRENT_DATE
    """)['count']
    
    # Active campaigns
    active_campaigns = db.fetchone("SELECT COUNT(*) as count FROM campaigns WHERE status = 'running'")['count']
    
    # Recent notifications
    unread_notifications = db.fetchone("SELECT COUNT(*) as count FROM notifications WHERE is_read = FALSE")['count']
    
    return jsonify({
        'accounts': {
            'total': total_accounts,
            'active': active_accounts
        },
        'users': {
            'total': total_users,
            'invited': invited_users,
            'pending': total_users - invited_users
        },
        'today': {
            'invites': today_invites,
            'parses': today_parses
        },
        'campaigns': {
            'active': active_campaigns
        },
        'notifications': {
            'unread': unread_notifications
        }
    })

@app.route('/api/dashboard/chart/daily', methods=['GET'])
@token_required
def get_daily_chart():
    """Get daily statistics for chart"""
    days = int(request.args.get('days', 7))
    
    stats = db.fetchall("""
        SELECT * FROM v_daily_stats
        ORDER BY date DESC
        LIMIT %s
    """, (days,))
    
    return jsonify(list(reversed(stats)))

# ============================================
# ACCOUNTS ROUTES
# ============================================

@app.route('/api/accounts', methods=['GET'])
@token_required
def get_accounts():
    """Get all accounts"""
    accounts = db.fetchall("SELECT * FROM v_account_performance ORDER BY id")
    return jsonify(accounts)

@app.route('/api/accounts/<int:account_id>', methods=['GET'])
@token_required
def get_account(account_id):
    """Get account by ID"""
    account = db.get_account_by_id(account_id)
    
    if not account:
        return jsonify({'error': 'Account not found'}), 404
    
    return jsonify(account)

@app.route('/api/accounts', methods=['POST'])
@token_required
def create_account():
    """Create new account"""
    data = request.json
    
    required_fields = ['phone', 'api_id', 'api_hash', 'session_file']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Missing field: {field}'}), 400
    
    try:
        account_id = db.insert('telegram_accounts', {
            'phone': data['phone'],
            'api_id': data['api_id'],
            'api_hash': data['api_hash'],
            'session_file': data['session_file'],
            'role': data.get('role', 'parser'),
            'proxy_id': data.get('proxy_id')
        })
        
        return jsonify({'id': account_id, 'message': 'Account created successfully'}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/accounts/<int:account_id>', methods=['PUT'])
@token_required
def update_account(account_id):
    """Update account"""
    data = request.json
    
    try:
        db.update('telegram_accounts', data, {'id': account_id})
        return jsonify({'message': 'Account updated successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/accounts/<int:account_id>', methods=['DELETE'])
@token_required
def delete_account(account_id):
    """Delete account"""
    try:
        db.delete('telegram_accounts', {'id': account_id})
        return jsonify({'message': 'Account deleted successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================
# GROUPS ROUTES
# ============================================

@app.route('/api/groups', methods=['GET'])
@token_required
def get_groups():
    """Get target groups"""
    limit = int(request.args.get('limit', 100))
    groups = db.get_target_groups(limit=limit)
    return jsonify(groups)

@app.route('/api/groups', methods=['POST'])
@token_required
def create_group():
    """Create target group"""
    data = request.json
    
    try:
        group_id = db.save_target_group(
            telegram_id=data['telegram_id'],
            title=data['title'],
            username=data.get('username'),
            member_count=data.get('member_count', 0),
            relevance_score=data.get('relevance_score', 0.5)
        )
        
        return jsonify({'id': group_id, 'message': 'Group added successfully'}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================
# USERS ROUTES
# ============================================

@app.route('/api/users', methods=['GET'])
@token_required
def get_users():
    """Get parsed users"""
    limit = int(request.args.get('limit', 100))
    invited_only = request.args.get('invited') == 'true'
    
    query = "SELECT * FROM parsed_users"
    
    if invited_only:
        query += " WHERE is_invited = TRUE"
    
    query += " ORDER BY created_at DESC LIMIT %s"
    
    users = db.fetchall(query, (limit,))
    return jsonify(users)

@app.route('/api/users/to-invite', methods=['GET'])
@token_required
def get_users_to_invite():
    """Get users ready for inviting"""
    limit = int(request.args.get('limit', 100))
    min_score = float(request.args.get('min_score', 0.3))
    
    users = db.get_users_to_invite(limit=limit, min_activity_score=min_score)
    return jsonify(users)

# ============================================
# CAMPAIGNS ROUTES
# ============================================

@app.route('/api/campaigns', methods=['GET'])
@token_required
def get_campaigns():
    """Get all campaigns"""
    campaigns = db.fetchall("SELECT * FROM campaigns ORDER BY created_at DESC")
    return jsonify(campaigns)

@app.route('/api/campaigns/<int:campaign_id>', methods=['GET'])
@token_required
def get_campaign(campaign_id):
    """Get campaign by ID"""
    campaign = db.get_campaign(campaign_id)
    
    if not campaign:
        return jsonify({'error': 'Campaign not found'}), 404
    
    return jsonify(campaign)

@app.route('/api/campaigns', methods=['POST'])
@token_required
def create_campaign():
    """Create new campaign"""
    data = request.json
    
    try:
        campaign_id = db.insert('campaigns', {
            'name': data['name'],
            'description': data.get('description'),
            'type': data['type'],
            'target_groups': data.get('target_groups', []),
            'target_channel': data.get('target_channel'),
            'invite_message_template': data.get('invite_message_template'),
            'min_activity_score': data.get('min_activity_score', 0.3),
            'max_users': data.get('max_users', 100),
            'exclude_bots': data.get('exclude_bots', True),
            'exclude_private': data.get('exclude_private', True),
            'status': 'draft',
            'created_by_user_id': request.user['user_id']
        })
        
        return jsonify({'id': campaign_id, 'message': 'Campaign created successfully'}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/campaigns/<int:campaign_id>/start', methods=['POST'])
@token_required
def start_campaign(campaign_id):
    """Start campaign"""
    try:
        db.update('campaigns', {
            'status': 'running',
            'started_at': datetime.now()
        }, {'id': campaign_id})
        
        # Emit socket event
        socketio.emit('campaign_started', {'campaign_id': campaign_id})
        
        return jsonify({'message': 'Campaign started'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/campaigns/<int:campaign_id>/pause', methods=['POST'])
@token_required
def pause_campaign(campaign_id):
    """Pause campaign"""
    try:
        db.update('campaigns', {'status': 'paused'}, {'id': campaign_id})
        
        socketio.emit('campaign_paused', {'campaign_id': campaign_id})
        
        return jsonify({'message': 'Campaign paused'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/campaigns/<int:campaign_id>/stop', methods=['POST'])
@token_required
def stop_campaign(campaign_id):
    """Stop campaign"""
    try:
        db.update('campaigns', {
            'status': 'cancelled',
            'completed_at': datetime.now()
        }, {'id': campaign_id})
        
        socketio.emit('campaign_stopped', {'campaign_id': campaign_id})
        
        return jsonify({'message': 'Campaign stopped'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================
# LOGS ROUTES
# ============================================

@app.route('/api/logs/invites', methods=['GET'])
@token_required
def get_invite_logs():
    """Get invite logs"""
    limit = int(request.args.get('limit', 100))
    
    logs = db.fetchall("""
        SELECT il.*, ta.phone, pu.username as user_username
        FROM invite_logs il
        LEFT JOIN telegram_accounts ta ON ta.id = il.account_id
        LEFT JOIN parsed_users pu ON pu.id = il.user_id
        ORDER BY il.created_at DESC
        LIMIT %s
    """, (limit,))
    
    return jsonify(logs)

@app.route('/api/logs/parsing', methods=['GET'])
@token_required
def get_parsing_logs():
    """Get parsing logs"""
    limit = int(request.args.get('limit', 100))
    
    logs = db.fetchall("""
        SELECT pl.*, ta.phone, tg.title as group_title
        FROM parsing_logs pl
        LEFT JOIN telegram_accounts ta ON ta.id = pl.account_id
        LEFT JOIN target_groups tg ON tg.id = pl.group_id
        ORDER BY pl.started_at DESC
        LIMIT %s
    """, (limit,))
    
    return jsonify(logs)

@app.route('/api/logs/system', methods=['GET'])
@token_required
def get_system_logs():
    """Get system logs"""
    limit = int(request.args.get('limit', 100))
    level = request.args.get('level')
    
    query = "SELECT * FROM system_logs"
    params = []
    
    if level:
        query += " WHERE level = %s"
        params.append(level)
    
    query += " ORDER BY created_at DESC LIMIT %s"
    params.append(limit)
    
    logs = db.fetchall(query, tuple(params))
    return jsonify(logs)

# ============================================
# NOTIFICATIONS ROUTES
# ============================================

@app.route('/api/notifications', methods=['GET'])
@token_required
def get_notifications():
    """Get notifications"""
    unread_only = request.args.get('unread') == 'true'
    
    query = "SELECT * FROM notifications"
    
    if unread_only:
        query += " WHERE is_read = FALSE"
    
    query += " ORDER BY created_at DESC LIMIT 50"
    
    notifications = db.fetchall(query)
    return jsonify(notifications)

@app.route('/api/notifications/<int:notification_id>/read', methods=['PUT'])
@token_required
def mark_notification_read(notification_id):
    """Mark notification as read"""
    db.update('notifications', {'is_read': True}, {'id': notification_id})
    return jsonify({'message': 'Notification marked as read'})

# ============================================
# SETTINGS ROUTES
# ============================================

@app.route('/api/settings', methods=['GET'])
@token_required
def get_settings():
    """Get all settings"""
    settings = db.fetchall("SELECT * FROM settings WHERE is_public = TRUE")
    return jsonify({s['key']: {'value': s['value'], 'type': s['value_type'], 'description': s['description']} for s in settings})

@app.route('/api/settings/<key>', methods=['PUT'])
@token_required
def update_setting(key):
    """Update setting"""
    data = request.json
    value = data.get('value')
    
    db.set_setting(key, value)
    
    return jsonify({'message': 'Setting updated'})

# ============================================
# LLM ROUTES
# ============================================

@app.route('/api/llm/generate', methods=['POST'])
@token_required
def generate_text():
    """Generate text using LLM"""
    data = request.json
    prompt = data.get('prompt')
    
    if not prompt:
        return jsonify({'error': 'Prompt required'}), 400
    
    try:
        result = llm.generate(prompt)
        return jsonify({'text': result})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/llm/health', methods=['GET'])
@token_required
def llm_health():
    """Check LLM health"""
    is_healthy = llm.check_health()
    return jsonify({'healthy': is_healthy})

# ============================================
# WEBSOCKET EVENTS
# ============================================

@socketio.on('connect')
def handle_connect():
    """Handle WebSocket connection"""
    logger.info("Client connected")
    emit('connected', {'message': 'Connected to server'})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle WebSocket disconnection"""
    logger.info("Client disconnected")

# ============================================
# ERROR HANDLERS
# ============================================

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

# ============================================
# MAIN
# ============================================

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('DEBUG', 'False').lower() == 'true'
    
    logger.info(f"Starting API server on port {port}")
    
    socketio.run(app, host='0.0.0.0', port=port, debug=debug)
